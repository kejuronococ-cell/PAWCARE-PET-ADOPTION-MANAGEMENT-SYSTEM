-- PAWCARE audit timestamp migration (NON-DESTRUCTIVE)
-- Back up the pawcare database first, then run this against the existing database.
-- Existing rows are preserved. Legacy DATE values are converted to DATETIME at midnight;
-- true event times are recorded from this migration onward in audit_events.
USE pawcare;

CREATE TABLE IF NOT EXISTS audit_events (
  event_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  entity_type VARCHAR(30) NOT NULL,
  entity_id VARCHAR(30) NOT NULL,
  event_type VARCHAR(50) NOT NULL,
  event_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  details VARCHAR(500) NULL,
  INDEX idx_audit_entity (entity_type, entity_id, event_at),
  INDEX idx_audit_event_at (event_at)
) ENGINE=InnoDB;

-- Add missing columns safely, and upgrade existing date-only fields without deleting records.
SET @db := DATABASE();
SET @sql := IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=@db AND table_name='users' AND column_name='created_at')=0, 'ALTER TABLE users ADD COLUMN created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP', 'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql := IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=@db AND table_name='pets' AND column_name='archived_at')=0, 'ALTER TABLE pets ADD COLUMN archived_at DATETIME NULL', 'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql := IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=@db AND table_name='pets' AND column_name='restored_at')=0, 'ALTER TABLE pets ADD COLUMN restored_at DATETIME NULL', 'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql := IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=@db AND table_name='pet_submissions' AND column_name='reviewed_at')=0, 'ALTER TABLE pet_submissions ADD COLUMN reviewed_at DATETIME NULL', 'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql := IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=@db AND table_name='pet_submissions' AND column_name='archived_at')=0, 'ALTER TABLE pet_submissions ADD COLUMN archived_at DATETIME NULL', 'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql := IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=@db AND table_name='pet_submissions' AND column_name='restored_at')=0, 'ALTER TABLE pet_submissions ADD COLUMN restored_at DATETIME NULL', 'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql := IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=@db AND table_name='adoptions' AND column_name='fulfillment_selected_at')=0, 'ALTER TABLE adoptions ADD COLUMN fulfillment_selected_at DATETIME NULL', 'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql := IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=@db AND table_name='adoptions' AND column_name='fulfilled_at')=0, 'ALTER TABLE adoptions ADD COLUMN fulfilled_at DATETIME NULL', 'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

ALTER TABLE pets MODIFY date_added DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE pet_submissions MODIFY submission_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE adoptions MODIFY adoption_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE archive MODIFY archive_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;

DROP TRIGGER IF EXISTS pawcare_audit_user_insert;
DROP TRIGGER IF EXISTS pawcare_audit_user_archive_insert;
DROP TRIGGER IF EXISTS pawcare_audit_user_archive_delete;
DROP TRIGGER IF EXISTS pawcare_audit_submission_insert;
DROP TRIGGER IF EXISTS pawcare_audit_submission_update;
DROP TRIGGER IF EXISTS pawcare_audit_pet_update;
DROP TRIGGER IF EXISTS pawcare_audit_adoption_insert;
DROP TRIGGER IF EXISTS pawcare_audit_adoption_update;

DELIMITER $$
CREATE TRIGGER pawcare_audit_user_insert AFTER INSERT ON users FOR EACH ROW
BEGIN
  IF NEW.role_type = 'CUSTOMER' THEN
    INSERT INTO audit_events(entity_type,entity_id,event_type,details) VALUES('USER',NEW.user_id,'ACCOUNT_CREATED','Customer account created');
  END IF;
END$$
CREATE TRIGGER pawcare_audit_user_archive_insert AFTER INSERT ON archive FOR EACH ROW
BEGIN
  INSERT INTO audit_events(entity_type,entity_id,event_type,details) VALUES('USER',NEW.user_id,'ACCOUNT_ARCHIVED',COALESCE(NEW.reason,'Account archived'));
END$$
CREATE TRIGGER pawcare_audit_user_archive_delete BEFORE DELETE ON archive FOR EACH ROW
BEGIN
  INSERT INTO audit_events(entity_type,entity_id,event_type,details) VALUES('USER',OLD.user_id,'ACCOUNT_RESTORED','Account restored');
END$$
CREATE TRIGGER pawcare_audit_submission_insert AFTER INSERT ON pet_submissions FOR EACH ROW
BEGIN
  INSERT INTO audit_events(entity_type,entity_id,event_type,details) VALUES('SUBMISSION',NEW.submission_id,'PET_SUBMITTED',CONCAT('Pet ID: ',NEW.pet_id));
END$$
CREATE TRIGGER pawcare_audit_submission_update AFTER UPDATE ON pet_submissions FOR EACH ROW
BEGIN
  IF NOT (OLD.status <=> NEW.status) THEN
    IF NEW.status = 'Approved' THEN
      INSERT INTO audit_events(entity_type,entity_id,event_type,details) VALUES('SUBMISSION',NEW.submission_id,'PET_APPROVED','Submission approved');
    ELSEIF NEW.status = 'Rejected' THEN
      INSERT INTO audit_events(entity_type,entity_id,event_type,details) VALUES('SUBMISSION',NEW.submission_id,'PET_REJECTED','Submission rejected');
    ELSEIF NEW.status = 'Archived' THEN
      INSERT INTO audit_events(entity_type,entity_id,event_type,details) VALUES('SUBMISSION',NEW.submission_id,'SUBMISSION_ARCHIVED','Submission archived');
    ELSEIF OLD.status = 'Archived' AND NEW.status <> 'Archived' THEN
      INSERT INTO audit_events(entity_type,entity_id,event_type,details) VALUES('SUBMISSION',NEW.submission_id,'SUBMISSION_RESTORED','Submission restored');
    END IF;
  END IF;
END$$
CREATE TRIGGER pawcare_audit_pet_update AFTER UPDATE ON pets FOR EACH ROW
BEGIN
  IF OLD.status_id <> NEW.status_id AND NEW.status_id = 5 THEN
    INSERT INTO audit_events(entity_type,entity_id,event_type,details) VALUES('PET',NEW.pet_id,'PET_ARCHIVED','Pet archived');
  ELSEIF OLD.status_id = 5 AND NEW.status_id <> 5 THEN
    INSERT INTO audit_events(entity_type,entity_id,event_type,details) VALUES('PET',NEW.pet_id,'PET_RESTORED','Pet restored');
  END IF;
END$$
CREATE TRIGGER pawcare_audit_adoption_insert AFTER INSERT ON adoptions FOR EACH ROW
BEGIN
  INSERT INTO audit_events(entity_type,entity_id,event_type,details) VALUES('ADOPTION',NEW.adoption_id,'ADOPTION_REQUESTED',CONCAT('Pet ID: ',NEW.pet_id));
END$$
CREATE TRIGGER pawcare_audit_adoption_update AFTER UPDATE ON adoptions FOR EACH ROW
BEGIN
  IF (OLD.fulfillment_method IS NULL OR OLD.fulfillment_method = 'Not selected') AND NEW.fulfillment_method <> 'Not selected' THEN
    INSERT INTO audit_events(entity_type,entity_id,event_type,details) VALUES('ADOPTION',NEW.adoption_id,'FULFILLMENT_SELECTED',NEW.fulfillment_method);
  END IF;
  IF NOT (OLD.fulfillment_status <=> NEW.fulfillment_status) AND NEW.fulfillment_status IN ('Picked Up','Delivered') THEN
    INSERT INTO audit_events(entity_type,entity_id,event_type,details) VALUES('ADOPTION',NEW.adoption_id,IF(NEW.fulfillment_status='Delivered','PET_DELIVERED','PET_PICKED_UP'),NEW.fulfillment_status);
  END IF;
END$$
DELIMITER ;

-- This migration records events from now on. It deliberately does not invent times for past events.

-- Allow multiple selected vaccinations and a custom vaccination name.
ALTER TABLE pets MODIFY vaccination VARCHAR(255);
