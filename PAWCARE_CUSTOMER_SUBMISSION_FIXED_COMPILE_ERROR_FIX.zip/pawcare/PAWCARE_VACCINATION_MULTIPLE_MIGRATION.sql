-- PAWCARE: vaccination multi-select compatibility migration
-- For the existing database used with PAWCARE_CUSTOMER_SUBMISSION_FIXED.zip.
-- Back up the pawcare database before running this script.
-- The current Java form saves selected vaccination names as a comma-separated
-- string (including "Others: <custom text>") in pets.vaccination.
-- This migration preserves existing values and does not drop or recreate tables.

USE pawcare;

ALTER TABLE pets
    MODIFY COLUMN vaccination VARCHAR(255) NULL;

-- No separate pet_submissions vaccination column is required by this ZIP:
-- pet_submissions references pets.pet_id, and the submitted care details
-- (including vaccination and disability) are stored on the associated pets row.
