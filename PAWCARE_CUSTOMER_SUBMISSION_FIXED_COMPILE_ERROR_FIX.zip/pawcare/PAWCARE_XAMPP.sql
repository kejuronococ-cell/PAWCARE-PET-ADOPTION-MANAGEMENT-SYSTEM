-- WARNING: FRESH INSTALL ONLY. This script DROPS the existing pawcare database and deletes its data.
-- For an existing installation, back up the database and run migration.sql instead.
-- PAWCARE XAMPP DATABASE - FINAL ERD VERSION
-- Tables: users, pet_status, pets, pet_submissions, adoptions, archive
--   * users.role_type ('ADMIN' / 'CUSTOMER') replaces the old admins and pet_owners tables.
--   * pets.type and pets.breed stay as attributes of pets (no PetType / Breed tables).
--   * archive is its own table (users.archived column removed).
-- Clean start: NO customers, NO adoptions, NO pet submissions, NO archived users.
-- The six original PAWCARE catalog pets are included and ALL are Available.
-- Default admin account (a row in users with role_type = 'ADMIN'):
--   Username (user_id): admin      Password: admin123

DROP DATABASE IF EXISTS pawcare;
CREATE DATABASE pawcare
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE pawcare;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS archive;
DROP TABLE IF EXISTS pet_submissions;
DROP TABLE IF EXISTS adoptions;
DROP TABLE IF EXISTS pets;
DROP TABLE IF EXISTS pet_owners;
DROP TABLE IF EXISTS admins;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS pet_status;
SET FOREIGN_KEY_CHECKS = 1;

-- PetStatus
CREATE TABLE pet_status (
    status_id INT PRIMARY KEY,
    status_name VARCHAR(50) NOT NULL UNIQUE
) ENGINE=InnoDB;

INSERT INTO pet_status (status_id, status_name) VALUES
(1, 'Available'),
(2, 'Adopted'),
(3, 'Pending'),
(4, 'Rejected'),
(5, 'Archived');

-- User (combines the old User + PetOwner + Admin)
CREATE TABLE users (
    user_id VARCHAR(10) PRIMARY KEY,
    password VARCHAR(255) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    contact VARCHAR(20) NOT NULL UNIQUE,
    address VARCHAR(255) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    age VARCHAR(10) NOT NULL,
    role_type VARCHAR(20) NOT NULL DEFAULT 'CUSTOMER',
    CONSTRAINT chk_users_role CHECK (role_type IN ('ADMIN', 'CUSTOMER'))
) ENGINE=InnoDB;

-- Pet
CREATE TABLE pets (
    pet_id VARCHAR(10) PRIMARY KEY,
    user_id VARCHAR(10) NULL,            -- customer who submitted the pet (NULL for catalog pets)
    status_id INT NOT NULL DEFAULT 1,
    name VARCHAR(100) NOT NULL,
    type VARCHAR(50) NOT NULL,
    breed VARCHAR(100) NOT NULL,
    age VARCHAR(40) NOT NULL,
    gender VARCHAR(30) NOT NULL,
    health VARCHAR(255),
    vaccination VARCHAR(255),
    dewormed VARCHAR(100),
    disability VARCHAR(255),
    personality VARCHAR(255),
    special_care VARCHAR(255),
    image_resource VARCHAR(255),
    spayed_neutered VARCHAR(20) NOT NULL DEFAULT 'Unknown',
    good_with_kids VARCHAR(20) NOT NULL DEFAULT 'Unknown',
    medical_history TEXT,
    date_added DATE NOT NULL DEFAULT (CURRENT_DATE),
    CONSTRAINT fk_pet_user FOREIGN KEY (user_id)
        REFERENCES users(user_id)
        ON UPDATE CASCADE ON DELETE SET NULL,
    CONSTRAINT fk_pet_status FOREIGN KEY (status_id)
        REFERENCES pet_status(status_id)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

-- PetSubmission
CREATE TABLE pet_submissions (
    submission_id VARCHAR(10) PRIMARY KEY,
    user_id VARCHAR(10) NOT NULL,
    pet_id VARCHAR(10) NOT NULL,
    submission_date DATE NOT NULL,
    status VARCHAR(50) NOT NULL,
    CONSTRAINT fk_submission_user FOREIGN KEY (user_id)
        REFERENCES users(user_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_submission_pet FOREIGN KEY (pet_id)
        REFERENCES pets(pet_id)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

-- Adoption
CREATE TABLE adoptions (
    adoption_id VARCHAR(10) PRIMARY KEY,
    pet_id VARCHAR(10) NOT NULL,
    user_id VARCHAR(10) NOT NULL,
    adoption_date DATE NOT NULL,
    pet_name VARCHAR(100) NOT NULL,
    status VARCHAR(50) NOT NULL,
    fulfillment_method VARCHAR(50) NOT NULL DEFAULT 'Not selected',
    fulfillment_status VARCHAR(50) NOT NULL DEFAULT 'Pending',
    delivery_address VARCHAR(255),
    delivery_name VARCHAR(150),
    delivery_contact VARCHAR(20),
    CONSTRAINT fk_adoption_pet FOREIGN KEY (pet_id)
        REFERENCES pets(pet_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_adoption_user FOREIGN KEY (user_id)
        REFERENCES users(user_id)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

-- Archive (a user is archived while a row exists here; restoring deletes the row)
CREATE TABLE archive (
    archive_id VARCHAR(10) PRIMARY KEY,
    user_id VARCHAR(10) NOT NULL,
    archive_date DATE NOT NULL,
    reason VARCHAR(255),
    archived_by VARCHAR(50),
    CONSTRAINT fk_archive_user FOREIGN KEY (user_id)
        REFERENCES users(user_id)
        ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

-- Default admin (role_type = 'ADMIN'). Password is stored as SHA-256 hash.
INSERT INTO users (user_id, password, first_name, last_name, contact, address, email, age, role_type)
VALUES ('admin', SHA2('admin123', 256), 'System', 'Admin', '0000000000',
        'PawCare Adoption Center', 'admin@pawcare.local', 'N/A', 'ADMIN');

-- Original PAWCARE catalog pets. All start as Available (status_id = 1).
INSERT INTO pets
(pet_id, user_id, status_id, name, type, breed, age, gender, health, vaccination, dewormed,
 disability, personality, special_care, image_resource)
VALUES
('P001', NULL, 1, 'Ming', 'Cat', 'Puspin', '2', 'Female', 'Healthy', 'Up to date', 'Yes',
 'None', 'Friendly and curious', 'Flea prevention', '/com/mycompany/pawcare/images/ming.jfif'),
('P002', NULL, 1, 'Buddy', 'Dog', 'Labrador Retriever', '1', 'Male', 'Healthy', 'Up to date', 'Yes',
 'None', 'Energetic and friendly', 'Daily exercise', '/com/mycompany/pawcare/images/buddy.jfif'),
('P003', NULL, 1, 'Bantay', 'Dog', 'Aspin', '3', 'Male', 'Healthy', 'Up to date', 'Yes',
 'None', 'Loyal and protective', 'Regular exercise', '/com/mycompany/pawcare/images/bantay.jfif'),
('P004', NULL, 1, 'Oreo', 'Cat', 'Domestic Shorthair', '2', 'Male', 'Healthy', 'Up to date', 'Yes',
 'None', 'Calm and affectionate', 'Indoor care', '/com/mycompany/pawcare/images/oreo.jfif'),
('P005', NULL, 1, 'Ash', 'Cat', 'Russian Blue', '3', 'Male', 'Mild skin sensitivity', 'Up to date', 'Yes',
 'None', 'Quiet and affectionate', 'Gentle grooming and skin checks', '/com/mycompany/pawcare/images/ash.jfif'),
('P006', NULL, 1, 'Lucky', 'Dog', 'Mixed Breed', '4', 'Male', 'Healthy; previous minor injury', 'Up to date', 'Yes',
 'Slight limp', 'Friendly and active', 'Avoid excessive running or jumping', '/com/mycompany/pawcare/images/lucky.jfif');

CREATE INDEX idx_pets_status ON pets(status_id);
CREATE INDEX idx_pets_user ON pets(user_id);
CREATE INDEX idx_adoptions_user ON adoptions(user_id);
CREATE INDEX idx_adoptions_pet ON adoptions(pet_id);
CREATE INDEX idx_submissions_status ON pet_submissions(status);
CREATE INDEX idx_submissions_user ON pet_submissions(user_id);
CREATE INDEX idx_archive_user ON archive(user_id);

-- Timestamp/audit additions for the current ERD. This section preserves all rows above.
-- It can also be applied independently to an existing database using the migration file.
-- PAWCARE audit timestamp migration (NON-DESTRUCTIVE)
-- Back up the pawcare database first, then run this against the existing database.
-- Existing rows are preserved. Legacy DATE values are converted to DATETIME at midnight;
-- true event times are recorded from this migration onward in audit_events.
USE pawcare;

CREATE TABLE IF NOT EXISTS audit_events (
  event_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  entity_type VARCHAR(30) NOT NULL,
  entity_id VARCHAR(30) NOT NULL,
  event_type VARCHAR(50) NOT NULL,
  event_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  details VARCHAR(500) NULL,
  INDEX idx_audit_entity (entity_type, entity_id, event_at),
  INDEX idx_audit_event_at (event_at)
) ENGINE=InnoDB;

-- Add missing columns safely, and upgrade existing date-only fields without deleting records.
SET @db := DATABASE();
SET @sql := IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=@db AND table_name='users' AND column_name='created_at')=0, 'ALTER TABLE users ADD COLUMN created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP', 'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql := IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=@db AND table_name='pets' AND column_name='archived_at')=0, 'ALTER TABLE pets ADD COLUMN archived_at DATETIME NULL', 'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql := IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=@db AND table_name='pets' AND column_name='restored_at')=0, 'ALTER TABLE pets ADD COLUMN restored_at DATETIME NULL', 'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql := IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=@db AND table_name='pet_submissions' AND column_name='reviewed_at')=0, 'ALTER TABLE pet_submissions ADD COLUMN reviewed_at DATETIME NULL', 'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql := IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=@db AND table_name='pet_submissions' AND column_name='archived_at')=0, 'ALTER TABLE pet_submissions ADD COLUMN archived_at DATETIME NULL', 'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql := IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=@db AND table_name='pet_submissions' AND column_name='restored_at')=0, 'ALTER TABLE pet_submissions ADD COLUMN restored_at DATETIME NULL', 'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql := IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=@db AND table_name='adoptions' AND column_name='fulfillment_selected_at')=0, 'ALTER TABLE adoptions ADD COLUMN fulfillment_selected_at DATETIME NULL', 'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql := IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=@db AND table_name='adoptions' AND column_name='fulfilled_at')=0, 'ALTER TABLE adoptions ADD COLUMN fulfilled_at DATETIME NULL', 'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

ALTER TABLE pets MODIFY date_added DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE pet_submissions MODIFY submission_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE adoptions MODIFY adoption_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE archive MODIFY archive_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;

DROP TRIGGER IF EXISTS pawcare_audit_user_insert;
DROP TRIGGER IF EXISTS pawcare_audit_user_archive_insert;
DROP TRIGGER IF EXISTS pawcare_audit_user_archive_delete;
DROP TRIGGER IF EXISTS pawcare_audit_submission_insert;
DROP TRIGGER IF EXISTS pawcare_audit_submission_update;
DROP TRIGGER IF EXISTS pawcare_audit_pet_update;
DROP TRIGGER IF EXISTS pawcare_audit_adoption_insert;
DROP TRIGGER IF EXISTS pawcare_audit_adoption_update;

DELIMITER $$
CREATE TRIGGER pawcare_audit_user_insert AFTER INSERT ON users FOR EACH ROW
BEGIN
  IF NEW.role_type = 'CUSTOMER' THEN
    INSERT INTO audit_events(entity_type,entity_id,event_type,details) VALUES('USER',NEW.user_id,'ACCOUNT_CREATED','Customer account created');
  END IF;
END$$
CREATE TRIGGER pawcare_audit_user_archive_insert AFTER INSERT ON archive FOR EACH ROW
BEGIN
  INSERT INTO audit_events(entity_type,entity_id,event_type,details) VALUES('USER',NEW.user_id,'ACCOUNT_ARCHIVED',COALESCE(NEW.reason,'Account archived'));
END$$
CREATE TRIGGER pawcare_audit_user_archive_delete BEFORE DELETE ON archive FOR EACH ROW
BEGIN
  INSERT INTO audit_events(entity_type,entity_id,event_type,details) VALUES('USER',OLD.user_id,'ACCOUNT_RESTORED','Account restored');
END$$
CREATE TRIGGER pawcare_audit_submission_insert AFTER INSERT ON pet_submissions FOR EACH ROW
BEGIN
  INSERT INTO audit_events(entity_type,entity_id,event_type,details) VALUES('SUBMISSION',NEW.submission_id,'PET_SUBMITTED',CONCAT('Pet ID: ',NEW.pet_id));
END$$
CREATE TRIGGER pawcare_audit_submission_update AFTER UPDATE ON pet_submissions FOR EACH ROW
BEGIN
  IF NOT (OLD.status <=> NEW.status) THEN
    IF NEW.status = 'Approved' THEN
      INSERT INTO audit_events(entity_type,entity_id,event_type,details) VALUES('SUBMISSION',NEW.submission_id,'PET_APPROVED','Submission approved');
    ELSEIF NEW.status = 'Rejected' THEN
      INSERT INTO audit_events(entity_type,entity_id,event_type,details) VALUES('SUBMISSION',NEW.submission_id,'PET_REJECTED','Submission rejected');
    ELSEIF NEW.status = 'Archived' THEN
      INSERT INTO audit_events(entity_type,entity_id,event_type,details) VALUES('SUBMISSION',NEW.submission_id,'SUBMISSION_ARCHIVED','Submission archived');
    ELSEIF OLD.status = 'Archived' AND NEW.status <> 'Archived' THEN
      INSERT INTO audit_events(entity_type,entity_id,event_type,details) VALUES('SUBMISSION',NEW.submission_id,'SUBMISSION_RESTORED','Submission restored');
    END IF;
  END IF;
END$$
CREATE TRIGGER pawcare_audit_pet_update AFTER UPDATE ON pets FOR EACH ROW
BEGIN
  IF OLD.status_id <> NEW.status_id AND NEW.status_id = 5 THEN
    INSERT INTO audit_events(entity_type,entity_id,event_type,details) VALUES('PET',NEW.pet_id,'PET_ARCHIVED','Pet archived');
  ELSEIF OLD.status_id = 5 AND NEW.status_id <> 5 THEN
    INSERT INTO audit_events(entity_type,entity_id,event_type,details) VALUES('PET',NEW.pet_id,'PET_RESTORED','Pet restored');
  END IF;
END$$
CREATE TRIGGER pawcare_audit_adoption_insert AFTER INSERT ON adoptions FOR EACH ROW
BEGIN
  INSERT INTO audit_events(entity_type,entity_id,event_type,details) VALUES('ADOPTION',NEW.adoption_id,'ADOPTION_REQUESTED',CONCAT('Pet ID: ',NEW.pet_id));
END$$
CREATE TRIGGER pawcare_audit_adoption_update AFTER UPDATE ON adoptions FOR EACH ROW
BEGIN
  IF (OLD.fulfillment_method IS NULL OR OLD.fulfillment_method = 'Not selected') AND NEW.fulfillment_method <> 'Not selected' THEN
    INSERT INTO audit_events(entity_type,entity_id,event_type,details) VALUES('ADOPTION',NEW.adoption_id,'FULFILLMENT_SELECTED',NEW.fulfillment_method);
  END IF;
  IF NOT (OLD.fulfillment_status <=> NEW.fulfillment_status) AND NEW.fulfillment_status IN ('Picked Up','Delivered') THEN
    INSERT INTO audit_events(entity_type,entity_id,event_type,details) VALUES('ADOPTION',NEW.adoption_id,IF(NEW.fulfillment_status='Delivered','PET_DELIVERED','PET_PICKED_UP'),NEW.fulfillment_status);
  END IF;
END$$
DELIMITER ;

-- This migration records events from now on. It deliberately does not invent times for past events.
