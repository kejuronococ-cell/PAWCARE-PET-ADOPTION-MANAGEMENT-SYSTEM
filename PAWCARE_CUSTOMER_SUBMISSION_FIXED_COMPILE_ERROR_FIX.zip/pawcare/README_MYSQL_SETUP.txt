PAWCARE - UPDATED SYSTEM / XAMPP SETUP
=====================================

This project preserves the existing PawCare Java Swing / NetBeans project and adds only the requested changes:
- Pet Submission now keeps vaccination multi-select, vaccination Other text, disability Other text, spayed/neutered, good-with-kids, and medical history on the form instead of opening a separate Additional Details dialog.
- Admin adoption cards no longer show customer-only Manage Fulfillment actions.
- Customer pickup/delivery confirmation wording is corrected.
- Database-backed audit timestamps are recorded for account creation/archive/restore, pet submission/review/archive/restore, adoption requests, fulfillment selection, and receipt/delivery confirmation.
- Relevant View Info screens show audit timelines.

DATABASE FILES
--------------
PAWCARE_XAMPP.sql
  Fresh install only. It drops and recreates the `pawcare` database, then creates the tables and audit triggers.
  Do not import this into an existing database if you need to keep your current records.

PAWCARE_AUDIT_TIMESTAMPS_MIGRATION.sql
  Non-destructive timestamp/audit migration for an existing database that already has the PawCare tables.
  Back up the database first, select `pawcare`, then run this file. It preserves existing rows and does not invent exact times for past events; older DATE values become DATETIME at midnight.

migration.sql
  Earlier field migration for installations missing the pet care/adoption fields. If your database predates those fields, back it up and apply the required legacy field migration before the audit migration. Do not run PAWCARE_XAMPP.sql on an existing database.

XAMPP / NETBEANS
----------------
1. Start MySQL in XAMPP.
2. For a fresh database only, import PAWCARE_XAMPP.sql in phpMyAdmin.
3. For an existing database, back it up and run the appropriate non-destructive migration file(s), not the fresh-install SQL.
4. Open the project folder in NetBeans and run Main.java.
5. Maven project uses MySQL Connector/J from pom.xml.

Default fresh-install admin:
  Username: admin
  Password: admin123

Important: database triggers capture true event timestamps from the moment the audit migration is installed. Historical actions cannot be assigned exact times retroactively.
