package com.mycompany.pawcare;

import com.mycompany.pawcare.screens.Homeform;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/**
 * PAWCARE application entry point.
 * This is the only runnable entry point in the project.
 * The JFrame classes are screens used by the application and are kept
 * available for NetBeans Design view; they do not have their own main methods.
 */
public final class Main {
    private Main() { }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
            } catch (Exception ignored) {
                // Use the default Swing look and feel if the requested one is unavailable.
            }
            new Homeform().setVisible(true);
        });
    }
}
