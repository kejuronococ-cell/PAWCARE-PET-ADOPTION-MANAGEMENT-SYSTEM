/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package com.mycompany.pawcare.cards;

import com.mycompany.pawcare.screens.*;
import com.mycompany.pawcare.popups.*;
import com.mycompany.pawcare.helpers.*;

/**
 *
 * @author Student
 */
public class AdoptionCardPanel extends javax.swing.JPanel {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(AdoptionCardPanel.class.getName());

    public AdoptionCardPanel() {
        initComponents();

        // Rebuild the runtime card layout without changing the NetBeans .form file.
        // The generated layout fixed pnlActions to 38px, clipping additional rows.
        setLayout(new javax.swing.BoxLayout(this, javax.swing.BoxLayout.Y_AXIS));
        setBackground(java.awt.Color.WHITE);
        setBorder(javax.swing.BorderFactory.createCompoundBorder(
                javax.swing.BorderFactory.createLineBorder(new java.awt.Color(225, 215, 235), 2, true),
                javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        removeAll();

        picPet.setPreferredSize(new java.awt.Dimension(250, 190));
        picPet.setMinimumSize(new java.awt.Dimension(250, 190));
        picPet.setMaximumSize(new java.awt.Dimension(250, 190));
        picPet.setAlignmentX(java.awt.Component.CENTER_ALIGNMENT);
        add(picPet);
        add(javax.swing.Box.createVerticalStrut(5));

        javax.swing.JLabel[] labels = {lblName, lblType, lblIds, lblDate, lblStatus, lblMethod, lblFulfil, lblAdopter};
        for (int i = 0; i < labels.length; i++) {
            labels[i].setAlignmentX(java.awt.Component.CENTER_ALIGNMENT);
            // Text is bound later; allow the label height to update with real content.
            labels[i].setMaximumSize(new java.awt.Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
            add(labels[i]);
            if (i == 1 || i == 6) add(javax.swing.Box.createVerticalStrut(2));
        }
        add(javax.swing.Box.createVerticalStrut(6));

        pnlActions.setLayout(new javax.swing.BoxLayout(pnlActions, javax.swing.BoxLayout.Y_AXIS));
        pnlActions.setAlignmentX(java.awt.Component.CENTER_ALIGNMENT);
        pnlActions.setMaximumSize(new java.awt.Dimension(Integer.MAX_VALUE, 150));
        add(pnlActions);

        btnView.setPreferredSize(new java.awt.Dimension(135, 36));
        btnView.setMinimumSize(new java.awt.Dimension(135, 36));
        btnCancel.setPreferredSize(new java.awt.Dimension(170, 36));
        btnCancel.setMinimumSize(new java.awt.Dimension(170, 36));
        btnUpdate.setPreferredSize(new java.awt.Dimension(205, 36));
        btnUpdate.setMinimumSize(new java.awt.Dimension(205, 36));
        btnConfirmReceipt.setText("I RECEIVED THE PET");
        btnConfirmReceipt.setBackground(Session.GREEN);
        btnConfirmReceipt.setForeground(java.awt.Color.WHITE);
        btnConfirmReceipt.setPreferredSize(new java.awt.Dimension(205, 36));
        btnConfirmReceipt.setMinimumSize(new java.awt.Dimension(205, 36));
        btnConfirmReceipt.addActionListener(e -> confirmReceipt());
        btnChoose.setVisible(false);
        showSample();
    }

    private Adoption adoption;
    private javax.swing.JFrame owner;
    private boolean admin;
    private final com.mycompany.pawcare.helpers.RoundedButton btnConfirmReceipt = new com.mycompany.pawcare.helpers.RoundedButton();

    private void cancelAdoption() {
        if (Ui.confirm(owner, "Cancel this adoption? The pet will become Available again. This canceled card will be hidden from My Adoptions.")) {
            Session.manager().cancelAdoption(adoption);
            Nav.show(owner, new MyAdoptionsForm());
        }
    }

    /** Customer picks (or changes) Pick Up / Delivery after choosing "Choose later". */
    private void chooseFulfillment() {
        new FulfillmentDialog(owner, true, adoption).setVisible(true);
        Nav.show(owner, new MyAdoptionsForm());
    }

    private void updateFulfillment() {
        if (adoption == null || !"Pending".equalsIgnoreCase(adoption.getStatus())) return;
        new FulfillmentDialog(owner, true, adoption).setVisible(true);
        Nav.show(owner, admin ? new AdoptionRecordsForm() : new MyAdoptionsForm());
    }

    private void confirmReceipt() {
        if (adoption == null || !"Pending".equalsIgnoreCase(adoption.getStatus())) return;
        String method = adoption.getFulfillmentMethod();
        if (!"Pick Up".equalsIgnoreCase(method) && !"Delivery".equalsIgnoreCase(method)) {
            Ui.msg(owner, "Choose Pick Up or Delivery first.", "Fulfillment Required", javax.swing.JOptionPane.WARNING_MESSAGE);
            return;
        }
        String message = "Delivery".equalsIgnoreCase(method) ? "Has the owner received the pet yet?" : "Has the owner picked up the pet yet?";
        if (Ui.confirm(owner, message)) {
            if (Session.manager().confirmAdoption(adoption)) Nav.show(owner, admin ? new AdoptionRecordsForm() : new MyAdoptionsForm());
        }
    }

    /** Creates one card for a record (the design is the same for every card). */
    public static AdoptionCardPanel of(Adoption adoption, boolean admin, javax.swing.JFrame owner) {
        AdoptionCardPanel c = new AdoptionCardPanel();
        c.bind(adoption, admin, owner);
        return c;
    }

    private void showSample() {
        btnView.setText("VIEW INFO");
        btnChoose.setText("MANAGE FULFILLMENT");
        btnUpdate.setText("MANAGE FULFILLMENT");
        btnCancel.setVisible(false);
        btnUpdate.setVisible(false);
        btnChoose.setVisible(false);
        bind(null, false, null);
    }

    private void bind(Adoption adoption, boolean admin, javax.swing.JFrame owner) {
        this.adoption = adoption;
        this.admin = admin;
        this.owner = owner;
        if (adoption == null) {
            btnCancel.setVisible(false);
            btnUpdate.setVisible(false);
            btnConfirmReceipt.setVisible(false);
            refreshActionRows(false, false, false);
            return;
        }

        Pet pet = Session.manager().findPet(adoption.getPetId());
        User u = Session.manager().findUser(adoption.getUserId());
        picPet.setImagePath(pet == null ? "" : pet.getImageResource());
        lblName.setText(adoption.getPetName());
        lblType.setText(pet == null ? "Pet" : pet.getType() + " \u2022 " + pet.getBreed());
        lblIds.setText("Pet ID: " + adoption.getPetId() + "  \u2022  Adoption ID: " + adoption.getAdoptionId());
        lblDate.setText("Date: " + adoption.getDate());
        lblStatus.setText("Status: " + ("Pending".equalsIgnoreCase(adoption.getStatus()) ? "Pending Adoption" : adoption.getStatus()));
        lblStatus.setForeground(statusColor(adoption));
        lblMethod.setText("Fulfillment: " + adoption.getFulfillmentMethod());
        lblFulfil.setText("Fulfillment Status: " + adoption.getFulfillmentStatus());
        // Contact details remain in VIEW INFO; avoid duplicating personal data on the card.
        lblAdopter.setVisible(admin && u != null);
        lblAdopter.setText(u == null ? "" : "<html><b>Adopter:</b> " + esc(u.getFullName()) + "</html>");

        boolean pending = "Pending".equalsIgnoreCase(adoption.getStatus());
        boolean adopted = "Adopted".equalsIgnoreCase(adoption.getStatus());
        boolean completed = adopted || isFulfillmentComplete(adoption.getFulfillmentStatus());
        applyCardStatusStyle(completed);
        updateLabelMaximumSizes();

        btnCancel.setVisible(!admin && pending);
        btnUpdate.setVisible(!admin && pending);
        btnChoose.setVisible(false);
        boolean hasFulfillment = "Delivery".equalsIgnoreCase(adoption.getFulfillmentMethod())
                || "Pick Up".equalsIgnoreCase(adoption.getFulfillmentMethod());
        btnConfirmReceipt.setText(admin
                ? ("Delivery".equalsIgnoreCase(adoption.getFulfillmentMethod()) ? "CONFIRM DELIVERY" : "CONFIRM PICKUP")
                : ("Delivery".equalsIgnoreCase(adoption.getFulfillmentMethod()) ? "I RECEIVED THE PET" : "I PICKED UP THE PET"));
        btnConfirmReceipt.setVisible(pending && hasFulfillment);
        refreshActionRows(pending, !admin && pending, pending && hasFulfillment);

        // The layout's preferred height grows with the action rows, so the list scrolls
        // instead of cutting off the bottom buttons.
        revalidate();
        repaint();
    }

    private void updateLabelMaximumSizes() {
        javax.swing.JLabel[] labels = {lblName, lblType, lblIds, lblDate, lblStatus, lblMethod, lblFulfil, lblAdopter};
        for (javax.swing.JLabel label : labels) {
            java.awt.Dimension preferred = label.getPreferredSize();
            label.setMaximumSize(new java.awt.Dimension(Integer.MAX_VALUE,
                    Math.max(20, preferred.height + 3)));
        }
    }

    private void refreshActionRows(boolean pending, boolean allowCancel, boolean showConfirm) {
        pnlActions.removeAll();
        javax.swing.JPanel primaryRow = new javax.swing.JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 6, 2));
        primaryRow.setOpaque(false);
        btnView.setVisible(true);
        primaryRow.add(btnView);
        if (allowCancel) primaryRow.add(btnCancel);
        primaryRow.setAlignmentX(java.awt.Component.CENTER_ALIGNMENT);
        primaryRow.setMaximumSize(new java.awt.Dimension(Integer.MAX_VALUE, 42));
        pnlActions.add(primaryRow);

        if (pending && !admin) {
            javax.swing.JPanel fulfillmentRow = new javax.swing.JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 6, 2));
            fulfillmentRow.setOpaque(false);
            btnUpdate.setVisible(true);
            fulfillmentRow.add(btnUpdate);
            fulfillmentRow.setAlignmentX(java.awt.Component.CENTER_ALIGNMENT);
            fulfillmentRow.setMaximumSize(new java.awt.Dimension(Integer.MAX_VALUE, 42));
            pnlActions.add(fulfillmentRow);

            if (showConfirm) {
                javax.swing.JPanel confirmRow = new javax.swing.JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 6, 2));
                confirmRow.setOpaque(false);
                btnConfirmReceipt.setVisible(true);
                confirmRow.add(btnConfirmReceipt);
                confirmRow.setAlignmentX(java.awt.Component.CENTER_ALIGNMENT);
                confirmRow.setMaximumSize(new java.awt.Dimension(Integer.MAX_VALUE, 42));
                pnlActions.add(confirmRow);
            }
        }
        pnlActions.invalidate();
        if (pnlActions.getLayout() instanceof javax.swing.BoxLayout) {
            ((javax.swing.BoxLayout) pnlActions.getLayout()).invalidateLayout(pnlActions);
        }
        pnlActions.revalidate();
        pnlActions.repaint();
        invalidate();
        if (getLayout() instanceof javax.swing.BoxLayout) {
            ((javax.swing.BoxLayout) getLayout()).invalidateLayout(this);
        }
        revalidate();
    }

    private static String esc(String text) {
        if (text == null) return "";
        return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    private boolean isFulfillmentComplete(String status) {
        return "Picked Up".equalsIgnoreCase(status) || "Delivered".equalsIgnoreCase(status);
    }

    /** Visual-only runtime styling; the NetBeans-designed layout is left untouched. */
    private java.awt.Color statusColor(Adoption a) { return "Cancelled".equalsIgnoreCase(a.getStatus()) ? Session.RED : "Adopted".equalsIgnoreCase(a.getStatus()) ? Session.GREEN : Session.ORANGE; }

    private void applyCardStatusStyle(boolean completed) {
        java.awt.Color green = Session.GREEN;
        java.awt.Color normal = adoption != null && "Cancelled".equalsIgnoreCase(adoption.getStatus()) ? Session.RED : adoption != null && "Pending".equalsIgnoreCase(adoption.getStatus()) ? Session.ORANGE : new java.awt.Color(225, 215, 235);
        setBorder(javax.swing.BorderFactory.createCompoundBorder(
                javax.swing.BorderFactory.createLineBorder(completed ? green : normal, completed ? 3 : 2, true),
                javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        lblName.setFont(new java.awt.Font("SansSerif", java.awt.Font.BOLD, 24));
        lblType.setFont(new java.awt.Font("SansSerif", java.awt.Font.BOLD, 16));
        lblIds.setFont(new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 14));
        lblDate.setFont(new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 14));
        lblStatus.setFont(new java.awt.Font("SansSerif", java.awt.Font.BOLD, 15));
        lblMethod.setFont(new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 14));
        lblFulfil.setFont(new java.awt.Font("SansSerif", java.awt.Font.BOLD, 15));
        lblAdopter.setFont(new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 14));
        if (completed) {
            lblFulfil.setForeground(green);
            lblStatus.setForeground(green);
        } else {
            lblFulfil.setForeground(new java.awt.Color(38, 48, 80));
            lblStatus.setForeground(statusColor(adoption));
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        picPet = new com.mycompany.pawcare.helpers.PetPhoto();
        lblName = new javax.swing.JLabel();
        lblType = new javax.swing.JLabel();
        lblIds = new javax.swing.JLabel();
        lblDate = new javax.swing.JLabel();
        lblStatus = new javax.swing.JLabel();
        lblMethod = new javax.swing.JLabel();
        lblFulfil = new javax.swing.JLabel();
        lblAdopter = new javax.swing.JLabel();
        pnlActions = new javax.swing.JPanel();
        btnView = new com.mycompany.pawcare.helpers.RoundedButton();
        btnCancel = new com.mycompany.pawcare.helpers.RoundedButton();
        btnUpdate = new com.mycompany.pawcare.helpers.RoundedButton();
        btnChoose = new com.mycompany.pawcare.helpers.RoundedButton();

        this.setBackground(new java.awt.Color(255, 255, 255));
        this.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(225, 215, 235), 2, true), javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10)));

        picPet.setImagePath("/com/mycompany/pawcare/images/buddy.jfif");

        lblName.setFont(new java.awt.Font("SansSerif", 1, 22)); // NOI18N
        lblName.setForeground(new java.awt.Color(38, 48, 80));
        lblName.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblName.setText("");

        lblType.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        lblType.setForeground(new java.awt.Color(126, 79, 195));
        lblType.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblType.setText("");

        lblIds.setFont(new java.awt.Font("SansSerif", 0, 13)); // NOI18N
        lblIds.setForeground(new java.awt.Color(90, 90, 90));
        lblIds.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblIds.setText("");

        lblDate.setFont(new java.awt.Font("SansSerif", 0, 13)); // NOI18N
        lblDate.setForeground(new java.awt.Color(90, 90, 90));
        lblDate.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDate.setText("");

        lblStatus.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        lblStatus.setForeground(new java.awt.Color(231, 65, 108));
        lblStatus.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblStatus.setText("");

        lblMethod.setFont(new java.awt.Font("SansSerif", 0, 13)); // NOI18N
        lblMethod.setForeground(new java.awt.Color(38, 48, 80));
        lblMethod.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblMethod.setText("");

        lblFulfil.setFont(new java.awt.Font("SansSerif", 0, 13)); // NOI18N
        lblFulfil.setForeground(new java.awt.Color(38, 48, 80));
        lblFulfil.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFulfil.setText("");

        lblAdopter.setFont(new java.awt.Font("SansSerif", 0, 13)); // NOI18N
        lblAdopter.setForeground(new java.awt.Color(90, 90, 90));
        lblAdopter.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAdopter.setText("");

        pnlActions.setOpaque(false);

        btnView.setBackground(new java.awt.Color(126, 79, 195));
        btnView.setForeground(new java.awt.Color(255, 255, 255));
        btnView.setText("VIEW INFO");
        btnView.addActionListener(this::btnViewActionPerformed);

        btnCancel.setBackground(new java.awt.Color(214, 65, 55));
        btnCancel.setForeground(new java.awt.Color(255, 255, 255));
        btnCancel.setText("CANCEL ADOPTION");
        btnCancel.addActionListener(this::btnCancelActionPerformed);

        btnUpdate.setBackground(new java.awt.Color(43, 126, 224));
        btnUpdate.setForeground(new java.awt.Color(255, 255, 255));
        btnUpdate.setText("MANAGE FULFILLMENT");
        btnUpdate.addActionListener(this::btnUpdateActionPerformed);

        btnChoose.setBackground(new java.awt.Color(52, 171, 83));
        btnChoose.setForeground(new java.awt.Color(255, 255, 255));
        btnChoose.setText("MANAGE FULFILLMENT");
        btnChoose.addActionListener(this::btnChooseActionPerformed);

        javax.swing.GroupLayout pnlActionsLayout = new javax.swing.GroupLayout(pnlActions);
        pnlActions.setLayout(pnlActionsLayout);
        pnlActionsLayout.setHorizontalGroup(
            pnlActionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlActionsLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(btnView, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(5, 5, 5)
                    .addComponent(btnCancel, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(5, 5, 5)
                    .addComponent(btnUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE))
        );
        pnlActionsLayout.setVerticalGroup(
            pnlActionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(btnView, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(btnCancel, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(btnUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(picPet, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE))
                .addComponent(lblName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblType, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblIds, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblDate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblStatus, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblMethod, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblFulfil, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblAdopter, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(pnlActions, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(btnChoose, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(picPet, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(8, 8, 8)
                    .addComponent(lblName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(3, 3, 3)
                    .addComponent(lblIds, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(4, 4, 4)
                    .addComponent(lblStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblMethod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblFulfil, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblAdopter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(8, 8, 8)
                    .addComponent(pnlActions, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(6, 6, 6)
                    .addComponent(btnChoose, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnViewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewActionPerformed
        new AdoptionInfoDialog(owner, true, adoption).setVisible(true);
    }//GEN-LAST:event_btnViewActionPerformed

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelActionPerformed
        cancelAdoption();
    }//GEN-LAST:event_btnCancelActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        updateFulfillment();
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnChooseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChooseActionPerformed
        chooseFulfillment();
    }//GEN-LAST:event_btnChooseActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.mycompany.pawcare.helpers.RoundedButton btnCancel;
    private com.mycompany.pawcare.helpers.RoundedButton btnChoose;
    private com.mycompany.pawcare.helpers.RoundedButton btnUpdate;
    private com.mycompany.pawcare.helpers.RoundedButton btnView;
    private javax.swing.JLabel lblAdopter;
    private javax.swing.JLabel lblDate;
    private javax.swing.JLabel lblFulfil;
    private javax.swing.JLabel lblIds;
    private javax.swing.JLabel lblMethod;
    private javax.swing.JLabel lblName;
    private javax.swing.JLabel lblStatus;
    private javax.swing.JLabel lblType;
    private com.mycompany.pawcare.helpers.PetPhoto picPet;
    private javax.swing.JPanel pnlActions;
    // End of variables declaration//GEN-END:variables
}
