package com.mycompany.pawcare.helpers;

import java.io.Serializable;

public class Adoption implements Serializable {
    private static final long serialVersionUID = 1L;
    private final String adoptionId, petId, userId, date;
    private String petName, status;
    private String fulfillmentMethod = "Not selected";
    private String fulfillmentStatus = "Pending";
    /** Address selected for this specific delivery.  Kept separate from the user profile. */
    private String deliveryAddress = "";
    private String deliveryName = "";
    private String deliveryContact = "";

    public Adoption(String adoptionId, String petId, String userId, String date, String petName, String status) {
        this.adoptionId = adoptionId; this.petId = petId; this.userId = userId;
        this.date = date; this.petName = petName; this.status = status;
    }
    public String getAdoptionId(){return adoptionId;} public String getPetId(){return petId;} public String getUserId(){return userId;}
    public String getDate(){return date;} public String getPetName(){return petName;} public String getStatus(){return status;}
    public String getFulfillmentMethod(){return fulfillmentMethod==null?"Not selected":fulfillmentMethod;}
    public String getFulfillmentStatus(){return fulfillmentStatus==null?"Pending":fulfillmentStatus;}
    public String getDeliveryAddress(){return deliveryAddress==null?"":deliveryAddress;}
    public String getDeliveryName(){return deliveryName==null?"":deliveryName;}
    public String getDeliveryContact(){return deliveryContact==null?"":deliveryContact;}
    public void setPetName(String v){petName=v;} public void setStatus(String v){status=v;}
    public void setFulfillmentMethod(String v){fulfillmentMethod=v;} public void setFulfillmentStatus(String v){fulfillmentStatus=v;}
    public void setDeliveryAddress(String v){deliveryAddress=v==null?"":v.trim();}
    public void setDeliveryName(String v){deliveryName=v==null?"":v.trim();}
    public void setDeliveryContact(String v){deliveryContact=v==null?"":v.trim();}
}
