package com.mycompany.pawcare.helpers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Central JDBC connection for PAWCARE.
 * Based on the JDBC connection tutorial supplied for the project.
 */
public final class Database {
    private static final String URL = "jdbc:mysql://localhost:3306/pawcare?useSSL=false&serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    private Database() {}

    /** Tutorial-style connection method. */
    private static Connection connectDB() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // loads MySQL driver
        } catch (ClassNotFoundException e) {
            throw new SQLException("MySQL Connector/J was not found. Add the mysql-connector-j JAR to NetBeans Libraries.", e);
        }
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public static Connection getConnection() throws SQLException {
        return connectDB();
    }

    public static void testConnection() throws SQLException {
        try (Connection conn = connectDB()) {
            System.out.println("Database connected!");
        }
    }
}
