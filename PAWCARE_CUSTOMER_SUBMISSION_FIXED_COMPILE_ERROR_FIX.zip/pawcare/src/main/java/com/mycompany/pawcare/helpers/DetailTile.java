package com.mycompany.pawcare.helpers;

import com.mycompany.pawcare.screens.*;
import com.mycompany.pawcare.popups.*;
import com.mycompany.pawcare.cards.*;

import java.awt.Color;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;

/** Light-purple tile with a small title and a value (used on the PET DETAILS page). */
public class DetailTile extends JPanel {

    private final JLabel lblTitle = new JLabel("Title");
    private final JLabel lblValue = new JLabel("Value");

    public DetailTile() {
        setBackground(new Color(246, 239, 252));
        setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
        setLayout(new java.awt.BorderLayout(3, 3));
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 12));
        lblTitle.setForeground(new Color(126, 79, 195));
        lblValue.setFont(new Font("SansSerif", Font.PLAIN, 14));
        lblValue.setForeground(new Color(38, 48, 80));
        add(lblTitle, java.awt.BorderLayout.NORTH);
        add(lblValue, java.awt.BorderLayout.CENTER);
    }

    public String getTitle() {
        return lblTitle.getText();
    }

    public void setTitle(String t) {
        lblTitle.setText(t);
    }

    public String getValue() {
        return lblValue.getText();
    }

    public void setValue(String v) {
        lblValue.setText("<html>" + (v == null ? "" : v) + "</html>");
    }
}
