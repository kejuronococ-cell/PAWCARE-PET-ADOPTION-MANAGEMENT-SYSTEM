package com.mycompany.pawcare.helpers;

import com.mycompany.pawcare.screens.*;
import com.mycompany.pawcare.popups.*;
import com.mycompany.pawcare.cards.*;

import java.awt.Graphics;
import java.awt.Image;
import java.net.URL;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

/**
 * Panel that paints a background picture scaled to cover the whole panel.
 * The picture comes from the "icon" property (so it shows in Design view);
 * if no icon is set it uses the PAWCARE home background.
 */
public class ImagePanel extends JPanel {

    private static final String HOME_BACKGROUND = "/com/mycompany/pawcare/images/home_background.jpg";

    private Icon icon;
    private Image fallback;

    public ImagePanel() {
    }

    public Icon getIcon() {
        return icon;
    }

    public void setIcon(Icon icon) {
        this.icon = icon;
        repaint();
    }

    private Image image() {
        if (icon instanceof ImageIcon) {
            return ((ImageIcon) icon).getImage();
        }
        if (fallback == null) {
            URL u = ImagePanel.class.getResource(HOME_BACKGROUND);
            if (u != null) {
                fallback = new ImageIcon(u).getImage();
            }
        }
        return fallback;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Image image = image();
        if (image != null) {
            int iw = image.getWidth(null), ih = image.getHeight(null);
            if (iw > 0 && ih > 0) {
                double s = Math.max((double) getWidth() / iw, (double) getHeight() / ih);
                int w = (int) (iw * s), h = (int) (ih * s);
                g.drawImage(image, (getWidth() - w) / 2, (getHeight() - h) / 2, w, h, null);
            }
        }
    }
}
