package com.mycompany.pawcare.helpers;

import java.awt.Component;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JPopupMenu;

/** Compact multi-select control for selecting more than one vaccination. */
public final class MultiSelectCheckCombo extends JButton {
    private final List<String> options;
    private final List<String> selected = new ArrayList<>();
    private final JPopupMenu popup = new JPopupMenu();
    private Runnable selectionChanged = () -> {};
    public MultiSelectCheckCombo(String[] values) {
        super("Select vaccinations");
        options = java.util.Arrays.asList(values);
        for (String value : options) {
            JCheckBoxMenuItem item = new JCheckBoxMenuItem(value);
            item.addActionListener(e -> {
                if (item.isSelected()) {
                    if ("Not vaccinated".equals(value)) {
                        for (Component c : popup.getComponents()) if (c instanceof JCheckBoxMenuItem other && other != item) other.setSelected(false);
                        selected.clear();
                    } else {
                        for (Component c : popup.getComponents()) if (c instanceof JCheckBoxMenuItem other && "Not vaccinated".equals(other.getText())) other.setSelected(false);
                        selected.remove("Not vaccinated");
                    }
                    if (!selected.contains(value)) selected.add(value);
                } else selected.remove(value);
                updateCaption();
                selectionChanged.run();
            });
            popup.add(item);
        }
        setHorizontalAlignment(LEFT);
        addActionListener(e -> popup.show(this, 0, getHeight()));
        setText("Select vaccinations");
    }
    public List<String> getSelectedValues() { return new ArrayList<>(selected); }
    public void setSelectionChanged(Runnable callback) { selectionChanged = callback == null ? () -> {} : callback; }
    public void setSelectedValues(List<String> values) {
        selected.clear();
        for (Component c : popup.getComponents()) if (c instanceof JCheckBoxMenuItem item) item.setSelected(false);
        if (values != null) for (String value : values) {
            if (options.contains(value)) {
                selected.add(value);
                for (Component c : popup.getComponents()) if (c instanceof JCheckBoxMenuItem item && item.getText().equals(value)) item.setSelected(true);
            }
        }
        updateCaption();
    }
    private void updateCaption() {
        if (selected.isEmpty()) setText("Select vaccinations");
        else setText(String.join(", ", selected));
    }
}
