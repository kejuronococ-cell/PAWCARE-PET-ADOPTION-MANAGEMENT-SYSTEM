package com.mycompany.pawcare.helpers;

import com.mycompany.pawcare.screens.*;
import com.mycompany.pawcare.popups.*;
import com.mycompany.pawcare.cards.*;

import javax.swing.JFrame;

/** Moves from one screen (JFrame) to the next, keeping the same window size and position. */
public final class Nav {

    private Nav() {
    }

    public static void show(JFrame from, JFrame to) {
        if (from != null) {
            to.setBounds(from.getBounds());
            to.setExtendedState(from.getExtendedState());
        }
        to.setVisible(true);
        if (from != null) {
            from.dispose();
        }
    }

    public static void home(JFrame from) {
        show(from, new Homeform());
    }

    /** After a successful login / account creation: continue the adoption or open the dashboard. */
    public static void afterLogin(JFrame from, Pet target, boolean newlyCreated) {
        String name = Session.currentUser == null ? "Customer" : Session.currentUser.getFullName();
        if (newlyCreated) {
            Ui.msg(from, "Welcome to PawCare, " + name + "!\nYour account has been created successfully.",
                    "Welcome to PawCare", javax.swing.JOptionPane.INFORMATION_MESSAGE);
        }
        Session.pendingAdoptionPet = target;
        if (target != null && target.getStatusId() == 1) {
            new AdoptionConfirmDialog(from, true, target).setVisible(true);
        } else {
            show(from, new CustomerDashboardForm());
        }
    }

    public static void adoptPet(JFrame from, Pet pet) {
        if (Session.currentUser == null) {
            show(from, new CustomerLoginForm(pet));
        } else {
            new AdoptionConfirmDialog(from, true, pet).setVisible(true);
        }
    }
}
