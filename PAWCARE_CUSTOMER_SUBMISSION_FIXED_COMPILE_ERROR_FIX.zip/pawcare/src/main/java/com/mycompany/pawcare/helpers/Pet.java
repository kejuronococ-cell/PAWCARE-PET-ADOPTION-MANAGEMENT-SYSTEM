package com.mycompany.pawcare.helpers;

public class Pet implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
    private String petId, name, type, breed, age, gender;
    private String health, vaccination, dewormed, disability, personality, specialCare, imageResource;
    private String spayedNeutered = "Unknown", goodWithKids = "Unknown", medicalHistory = "";
    private String dateAdded = "";
    private int statusId; // 1 Available, 2 Adopted, 3 Pending, 4 Rejected, 5 Archived (PetStatus table)
    private String userId; // FK -> User.userId (customer who submitted the pet; blank for catalog pets)

    public Pet(String petId, String name, String type, String breed, String age, String gender,
               String health, String vaccination, String dewormed, String disability,
               String personality, String specialCare, String imageResource, int statusId, String userId) {
        this.petId=petId; this.name=name; this.type=type; this.breed=breed; this.age=age; this.gender=gender;
        this.health=health; this.vaccination=vaccination; this.dewormed=dewormed; this.disability=disability;
        this.personality=personality; this.specialCare=specialCare; this.imageResource=imageResource;
        this.statusId=statusId; this.userId=userId;
    }

    public Pet(String petId, String name, String type, String breed, String age, String gender,
               String health, String vaccination, String dewormed, String disability, String personality,
               String specialCare, String imageResource, int statusId, String userId, String spayedNeutered,
               String goodWithKids, String medicalHistory, String dateAdded) {
        this(petId,name,type,breed,age,gender,health,vaccination,dewormed,disability,personality,specialCare,imageResource,statusId,userId);
        this.spayedNeutered = blankDefault(spayedNeutered, "Unknown");
        this.goodWithKids = blankDefault(goodWithKids, "Unknown");
        this.medicalHistory = blankDefault(medicalHistory, "");
        this.dateAdded = blankDefault(dateAdded, "");
    }
    private static String blankDefault(String value, String fallback) { return value == null || value.isBlank() ? fallback : value; }
    public String getPetId(){return petId;} public String getName(){return name;} public String getType(){return type;}
    public String getBreed(){return breed;} public String getAge(){return age;} public String getGender(){return gender;}
    public String getHealth(){return health;} public String getVaccination(){return vaccination;} public String getDewormed(){return dewormed;}
    public String getDisability(){return disability;} public String getPersonality(){return personality;} public String getSpecialCare(){return specialCare;}
    public String getImageResource(){return imageResource;} public String getSpayedNeutered(){return spayedNeutered;} public String getGoodWithKids(){return goodWithKids;} public String getMedicalHistory(){return medicalHistory;} public String getDateAdded(){return dateAdded;} public int getStatusId(){return statusId;} public String getUserId(){return userId;}
    public void setName(String v){name=v;} public void setType(String v){type=v;} public void setBreed(String v){breed=v;} public void setAge(String v){age=v;}
    public void setGender(String v){gender=v;} public void setHealth(String v){health=v;} public void setVaccination(String v){vaccination=v;}
    public void setDewormed(String v){dewormed=v;} public void setDisability(String v){disability=v;} public void setPersonality(String v){personality=v;}
    public void setSpecialCare(String v){specialCare=v;} public void setImageResource(String v){imageResource=v;} public void setStatusId(int v){statusId=v;} public void setSpayedNeutered(String v){spayedNeutered=blankDefault(v,"Unknown");} public void setGoodWithKids(String v){goodWithKids=blankDefault(v,"Unknown");} public void setMedicalHistory(String v){medicalHistory=v==null?"":v;} public void setDateAdded(String v){dateAdded=v==null?"":v;}
    public String getStatus(){return statusId==1?"Available":statusId==2?"Adopted":statusId==4?"Rejected":statusId==5?"Archived":"Pending";}
}
