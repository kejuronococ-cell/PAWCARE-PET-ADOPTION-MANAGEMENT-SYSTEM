package com.mycompany.pawcare.helpers;

import java.awt.Component;
import java.awt.GridLayout;
import javax.swing.*;

/** Additional structured pet health/behavior details shared by pet-entry screens. */
public final class PetAdditionalDetailsDialog {
    public static final class Details {
        public final String vaccination, disability, spayedNeutered, goodWithKids, medicalHistory;
        private Details(String v, String d, String s, String k, String m) { vaccination=v; disability=d; spayedNeutered=s; goodWithKids=k; medicalHistory=m; }
    }
    private PetAdditionalDetailsDialog() {}

    public static Details show(Component parent, Pet pet, String vaccination, String disability) {
        String[] vaccines = {"Anti-Rabies", "5-in-1 / DHPP", "Parvovirus", "Distemper", "Bordetella", "FVRCP", "Feline Leukemia", "Not vaccinated", "Others"};
        JComboBox<String> vaccine = new JComboBox<>(vaccines);
        String savedVaccine = vaccination == null ? "Not vaccinated" : vaccination;
        String otherVaccine = "";
        if (savedVaccine.startsWith("Others:")) { otherVaccine=savedVaccine.substring(7).trim(); savedVaccine="Others"; }
        if (java.util.Arrays.asList(vaccines).contains(savedVaccine)) vaccine.setSelectedItem(savedVaccine); else { otherVaccine=savedVaccine; vaccine.setSelectedItem("Others"); }
        JTextField vaccineOther = new JTextField(otherVaccine, 20);
        String[] disabilities = {"None", "Mobility issue", "Vision issue", "Hearing issue", "Other"};
        JComboBox<String> dis = new JComboBox<>(disabilities);
        String savedDis = disability == null ? "None" : disability;
        String otherDis = "";
        if (!java.util.Arrays.asList(disabilities).contains(savedDis) && !savedDis.isBlank()) { otherDis=savedDis.startsWith("Other:")?savedDis.substring(6).trim():savedDis; savedDis="Other"; }
        dis.setSelectedItem(savedDis);
        JTextField disOther = new JTextField(otherDis, 20);
        JComboBox<String> spayed = new JComboBox<>(new String[]{"Yes", "No", "Unknown"});
        JComboBox<String> kids = new JComboBox<>(new String[]{"Yes", "No", "Unknown"});
        JTextArea medical = new JTextArea(3, 20); medical.setLineWrap(true); medical.setWrapStyleWord(true);
        if (pet != null) { spayed.setSelectedItem(pet.getSpayedNeutered()); kids.setSelectedItem(pet.getGoodWithKids()); medical.setText(pet.getMedicalHistory()); }
        JPanel panel = new JPanel(new GridLayout(0, 2, 7, 7));
        panel.add(new JLabel("Vaccination")); panel.add(vaccine);
        panel.add(new JLabel("Vaccine name (Others)")); panel.add(vaccineOther);
        panel.add(new JLabel("Disability")); panel.add(dis);
        panel.add(new JLabel("Describe disability (Other)")); panel.add(disOther);
        panel.add(new JLabel("Spayed / Neutered")); panel.add(spayed);
        panel.add(new JLabel("Good with kids")); panel.add(kids);
        panel.add(new JLabel("Medical history")); panel.add(new JScrollPane(medical));
        Runnable toggle = () -> { vaccineOther.setEnabled("Others".equals(vaccine.getSelectedItem())); disOther.setEnabled("Other".equals(dis.getSelectedItem())); };
        vaccine.addActionListener(e -> toggle.run()); dis.addActionListener(e -> toggle.run()); toggle.run();
        int result = JOptionPane.showConfirmDialog(parent, panel, "Additional Pet Details", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result != JOptionPane.OK_OPTION) return null;
        String v = String.valueOf(vaccine.getSelectedItem());
        if ("Others".equals(v)) { if (vaccineOther.getText().trim().isEmpty()) { JOptionPane.showMessageDialog(parent,"Enter the vaccine name for Others."); return null; } v="Others: " + vaccineOther.getText().trim(); }
        String d = String.valueOf(dis.getSelectedItem());
        if ("Other".equals(d)) { if (disOther.getText().trim().isEmpty()) { JOptionPane.showMessageDialog(parent,"Describe the disability selected as Other."); return null; } d="Other: " + disOther.getText().trim(); }
        return new Details(v,d,String.valueOf(spayed.getSelectedItem()),String.valueOf(kids.getSelectedItem()),medical.getText().trim());
    }
}
