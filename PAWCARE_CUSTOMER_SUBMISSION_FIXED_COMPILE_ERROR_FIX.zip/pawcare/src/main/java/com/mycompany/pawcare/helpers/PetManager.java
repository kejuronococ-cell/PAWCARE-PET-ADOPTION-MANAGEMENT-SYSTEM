package com.mycompany.pawcare.helpers;

import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * PAWCARE business/data manager.
 * The GUI still talks to PetManager, but persistent data is now stored in MySQL.
 */
public class PetManager {
    public static final String PAWCARE_PICKUP_LOCATION = "PawCare Pet Store";

    private final List<Pet> pets = new ArrayList<>();
    private final List<User> users = new ArrayList<>();
    private final List<Adoption> adoptions = new ArrayList<>();
    private final List<PetSubmission> submissions = new ArrayList<>();

    public PetManager() {
        try {
            loadFromDatabase();
        } catch (SQLException e) {
            throw new IllegalStateException("Cannot connect to PawCare MySQL database. Start MySQL in XAMPP and add MySQL Connector/J.", e);
        }
    }

    private void loadFromDatabase() throws SQLException {
        pets.clear(); users.clear(); adoptions.clear(); submissions.clear();
        try (Connection c = Database.getConnection()) {
            loadUsers(c);
            loadPets(c);
            loadAdoptions(c);
            loadSubmissions(c);
        }
    }

    private void loadUsers(Connection c) throws SQLException {
        String sql = "SELECT u.user_id,u.password,u.first_name,u.last_name,u.contact,u.address,u.email,u.age,"
                + "EXISTS(SELECT 1 FROM archive a WHERE a.user_id=u.user_id) AS archived "
                + "FROM users u WHERE u.role_type='CUSTOMER' ORDER BY u.user_id";
        try (PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                User u = new User(rs.getString("user_id"), rs.getString("password"), rs.getString("first_name"),
                        rs.getString("last_name"), rs.getString("contact"), rs.getString("address"),
                        rs.getString("email"), rs.getString("age"));
                u.setArchived(rs.getBoolean("archived"));
                users.add(u);
            }
        }
    }

    private void loadPets(Connection c) throws SQLException {
        String sql = "SELECT pet_id,name,type,breed,age,gender,health,vaccination,dewormed,disability,personality,special_care,image_resource,status_id,user_id,spayed_neutered,good_with_kids,medical_history,date_added FROM pets ORDER BY date_added DESC, pet_id";
        try (PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) pets.add(new Pet(rs.getString("pet_id"), rs.getString("name"), rs.getString("type"),
                    rs.getString("breed"), rs.getString("age"), rs.getString("gender"), rs.getString("health"),
                    rs.getString("vaccination"), rs.getString("dewormed"), rs.getString("disability"),
                    rs.getString("personality"), rs.getString("special_care"), rs.getString("image_resource"),
                    rs.getInt("status_id"), nvl(rs.getString("user_id")), rs.getString("spayed_neutered"), rs.getString("good_with_kids"), rs.getString("medical_history"), rs.getString("date_added")));
        }
    }

    private void loadAdoptions(Connection c) throws SQLException {
        String sql = "SELECT adoption_id,pet_id,user_id,adoption_date,pet_name,status,fulfillment_method,fulfillment_status,delivery_address,delivery_name,delivery_contact FROM adoptions ORDER BY adoption_id";
        try (PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Adoption a = new Adoption(rs.getString("adoption_id"), rs.getString("pet_id"), rs.getString("user_id"),
                        rs.getString("adoption_date"), rs.getString("pet_name"), rs.getString("status"));
                a.setFulfillmentMethod(nvl(rs.getString("fulfillment_method"), "Not selected"));
                a.setFulfillmentStatus(nvl(rs.getString("fulfillment_status"), "Pending"));
                a.setDeliveryAddress(nvl(rs.getString("delivery_address")));
                a.setDeliveryName(nvl(rs.getString("delivery_name")));
                a.setDeliveryContact(nvl(rs.getString("delivery_contact")));
                adoptions.add(a);
            }
        }
    }

    private void loadSubmissions(Connection c) throws SQLException {
        String sql = "SELECT submission_id,user_id,pet_id,submission_date,status FROM pet_submissions ORDER BY submission_id";
        try (PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) submissions.add(new PetSubmission(rs.getString("submission_id"), rs.getString("user_id"),
                    rs.getString("pet_id"), rs.getString("submission_date"), rs.getString("status")));
        }
    }

    public List<Pet> getPets(){return Collections.unmodifiableList(pets);}
    public List<User> getUsers(){return Collections.unmodifiableList(users);}
    public List<Adoption> getAdoptions(){return Collections.unmodifiableList(adoptions);}
    public List<PetSubmission> getSubmissions(){return Collections.unmodifiableList(submissions);}

    public Pet findPet(String id){if(id==null)return null;for(Pet p:pets)if(p.getPetId().equalsIgnoreCase(id))return p;return null;}
    public User findUser(String id){if(id==null)return null;for(User u:users)if(u.getUserId().equalsIgnoreCase(id))return u;return null;}

    public User login(String first,String last,String pass){
        String sql="SELECT u.user_id,u.password,u.first_name,u.last_name,u.contact,u.address,u.email,u.age,FALSE AS archived FROM users u WHERE LOWER(u.first_name)=LOWER(?) AND LOWER(u.last_name)=LOWER(?) AND u.password=? AND u.role_type='CUSTOMER' AND NOT EXISTS(SELECT 1 FROM archive a WHERE a.user_id=u.user_id) LIMIT 1";
        try(Connection c=Database.getConnection();PreparedStatement ps=c.prepareStatement(sql)){
            ps.setString(1,first.trim());ps.setString(2,last.trim());ps.setString(3,hash(pass));
            try(ResultSet rs=ps.executeQuery()){if(rs.next())return userFrom(rs);}
            return null;
        }catch(SQLException e){throw db(e);}
    }

    public boolean adminOk(String username,String pass){
        String sql="SELECT 1 FROM users WHERE user_id=? AND password=? AND role_type='ADMIN' LIMIT 1";
        try(Connection c=Database.getConnection();PreparedStatement ps=c.prepareStatement(sql)){
            ps.setString(1,username.trim());ps.setString(2,hash(pass));
            try(ResultSet rs=ps.executeQuery()){return rs.next();}
        }catch(SQLException e){throw db(e);}
    }

    public boolean emailExists(String email,String exceptUserId){
        String sql="SELECT 1 FROM users u WHERE LOWER(u.email)=LOWER(?) AND NOT EXISTS(SELECT 1 FROM archive a WHERE a.user_id=u.user_id) AND u.user_id<>? LIMIT 1";
        try(Connection c=Database.getConnection();PreparedStatement ps=c.prepareStatement(sql)){
            ps.setString(1,email.trim());ps.setString(2,exceptUserId==null?"":exceptUserId);
            try(ResultSet rs=ps.executeQuery()){return rs.next();}
        }catch(SQLException e){throw db(e);}
    }
    public boolean contactExists(String contact,String exceptUserId){
        String sql="SELECT 1 FROM users u WHERE u.contact=? AND NOT EXISTS(SELECT 1 FROM archive a WHERE a.user_id=u.user_id) AND u.user_id<>? LIMIT 1";
        try(Connection c=Database.getConnection();PreparedStatement ps=c.prepareStatement(sql)){
            ps.setString(1,contact.trim());ps.setString(2,exceptUserId==null?"":exceptUserId);
            try(ResultSet rs=ps.executeQuery()){return rs.next();}
        }catch(SQLException e){throw db(e);}
    }

    public User createUser(String first,String last,String pass,String age,String address,String contact,String email){
        if(emailExists(email,null)||contactExists(contact,null))return null;
        String id=nextId("users","user_id","U");
        User u=new User(id,hash(pass),first,last,contact,address,email,age);
        try(Connection c=Database.getConnection()){insertUser(c,u);users.add(u);return u;}catch(SQLException e){throw db(e);}
    }

    public Pet addPet(String name,String type,String breed,String age,String gender,String health,String vacc,String dew,String disability,String personality,String care,String image,int status,String userId){
        return addPet(name,type,breed,age,gender,health,vacc,dew,disability,personality,care,image,status,userId,"Unknown","Unknown","");
    }
    public Pet addPet(String name,String type,String breed,String age,String gender,String health,String vacc,String dew,String disability,String personality,String care,String image,int status,String userId,String spayed,String kids,String medical){
        Pet p=new Pet(nextId("pets","pet_id","P"),name,type,breed,age,gender,health,vacc,dew,disability,personality,care,image,status,userId,spayed,kids,medical,today());pets.add(p);save();return p;
    }

    public Adoption adopt(Pet p,User u,String date,String chosenName){
        if(p==null||u==null||u.isArchived()||p.getStatusId()!=1)return null;
        Adoption a=new Adoption(nextId("adoptions","adoption_id","A"),p.getPetId(),u.getUserId(),date,chosenName,"Pending");
        p.setStatusId(3);
        adoptions.add(a);save();return a;
    }
    public boolean cancelAdoption(Adoption a){if(a==null||!("Pending".equalsIgnoreCase(a.getStatus())))return false;a.setStatus("Cancelled");a.setFulfillmentStatus("Cancelled");Pet p=findPet(a.getPetId());if(p!=null&&p.getStatusId()==3)p.setStatusId(1);save();return true;}
    public Adoption findAdoption(String id){if(id==null)return null;for(Adoption a:adoptions)if(a.getAdoptionId().equalsIgnoreCase(id))return a;return null;}

    public boolean setFulfillment(Adoption a,String method){
        if(a==null)return false;
        User u=findUser(a.getUserId());
        String address=a.getDeliveryAddress();
        if(address.isBlank()&&u!=null)address=u.getAddress();
        return setFulfillment(a,method,a.getDeliveryName().isBlank()&&u!=null?u.getFullName():a.getDeliveryName(),
                a.getDeliveryContact().isBlank()&&u!=null?u.getContact():a.getDeliveryContact(),address);
    }
    public boolean setFulfillment(Adoption a,String method,String deliveryAddress){
        User u=a==null?null:findUser(a.getUserId());
        return setFulfillment(a,method,a!=null?a.getDeliveryName():"",a!=null?a.getDeliveryContact():"",deliveryAddress);
    }
    public boolean setFulfillment(Adoption a,String method,String deliveryName,String deliveryContact,String deliveryAddress){
        if(a==null||method==null||!"Pending".equalsIgnoreCase(a.getStatus()))return false;
        if(!"Pick Up".equals(method)&&!"Delivery".equals(method))return false;
        if("Delivery".equals(method)&&(deliveryName==null||deliveryName.isBlank()||deliveryContact==null||deliveryContact.isBlank()||deliveryAddress==null||deliveryAddress.isBlank()))return false;
        a.setFulfillmentMethod(method);
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement("UPDATE adoptions SET fulfillment_selected_at=CURRENT_TIMESTAMP WHERE adoption_id=?")) { ps.setString(1, a.getAdoptionId()); ps.executeUpdate(); } catch (SQLException e) { throw db(e); }
        a.setFulfillmentStatus("Pick Up".equals(method)?"Ready for Pickup":"Pending Delivery");
        a.setDeliveryName("Delivery".equals(method)?deliveryName:"");
        a.setDeliveryContact("Delivery".equals(method)?deliveryContact:"");
        a.setDeliveryAddress("Delivery".equals(method)?deliveryAddress:"");
        save();return true;
    }
    public boolean confirmAdoption(Adoption a){
        if(a==null||!"Pending".equalsIgnoreCase(a.getStatus()))return false;
        String method=a.getFulfillmentMethod();
        if("Pick Up".equalsIgnoreCase(method))a.setFulfillmentStatus("Picked Up");
        else if("Delivery".equalsIgnoreCase(method))a.setFulfillmentStatus("Delivered");
        else return false;
        a.setStatus("Adopted");
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement("UPDATE adoptions SET fulfilled_at=CURRENT_TIMESTAMP WHERE adoption_id=?")) { ps.setString(1, a.getAdoptionId()); ps.executeUpdate(); } catch (SQLException e) { throw db(e); }
        Pet p=findPet(a.getPetId());if(p!=null)p.setStatusId(2);
        save();return true;
    }
    public void updateFulfillmentStatus(Adoption a,String status){
        if(a==null||status==null||!"Pending".equalsIgnoreCase(a.getStatus()))return;
        if("Picked Up".equals(status)||"Delivered".equals(status)){confirmAdoption(a);return;}
        if(java.util.Arrays.asList("Ready for Pickup","Pending Delivery","Out for Delivery").contains(status)){a.setFulfillmentStatus(status);save();}
    }
    public PetSubmission submitPet(User u,String name,String type,String breed,String age,String gender,String health,String vacc,String dew,String disability,String personality,String care,String image){
        return submitPet(u,name,type,breed,age,gender,health,vacc,dew,disability,personality,care,image,"Unknown","Unknown","");
    }
    private String nextSubmissionSamplePhoto(String type) {
        String key = type == null ? "other" : type.trim().toLowerCase(java.util.Locale.ROOT);
        String[] dogs = {"buddy.jfif", "bantay.jfif", "lucky.jfif"};
        String[] cats = {"oreo.jfif", "ming.jfif", "ash.jfif"};
        String[] choices = key.equals("dog") ? dogs : key.equals("cat") ? cats : null;
        if (choices == null) return "";
        int index = 0;
        for (PetSubmission submission : submissions) {
            Pet existing = findPet(submission.getPetId());
            if (existing != null && key.equalsIgnoreCase(existing.getType())) index++;
        }
        return "/com/mycompany/pawcare/images/" + choices[index % choices.length];
    }

    public PetSubmission submitPet(User u,String name,String type,String breed,String age,String gender,String health,String vacc,String dew,String disability,String personality,String care,String image,String spayed,String kids,String medical){
        String assignedImage = (image == null || image.isBlank()) ? nextSubmissionSamplePhoto(type) : image;
        Pet p=addPet(name,type,breed,age,gender,health,vacc,dew,disability,personality,care,assignedImage,3,u.getUserId(),spayed,kids,medical);
        PetSubmission s=new PetSubmission(nextId("pet_submissions","submission_id","S"),u.getUserId(),p.getPetId(),today(),"Pending");submissions.add(s);save();return s;
    }
    public void approveSubmission(PetSubmission s){if(s==null)return;Pet p=findPet(s.getPetId());if(p!=null&&p.getStatusId()==3){p.setStatusId(1);p.setDateAdded(today());s.setStatus("Approved");}else s.setStatus("Rejected");save();markSubmissionReviewed(s.getSubmissionId());}
    public void declineSubmission(PetSubmission s){if(s==null)return;Pet p=findPet(s.getPetId());if(p!=null)p.setStatusId(4);s.setStatus("Rejected");save();markSubmissionReviewed(s.getSubmissionId());}
    private void markSubmissionReviewed(String id){try(Connection c=Database.getConnection();PreparedStatement ps=c.prepareStatement("UPDATE pet_submissions SET reviewed_at=CURRENT_TIMESTAMP WHERE submission_id=?")){ps.setString(1,id);ps.executeUpdate();}catch(SQLException e){throw db(e);}}
    public boolean archivePet(Pet p){if(p==null||p.getStatusId()==2||p.getStatusId()==3||p.getStatusId()==5)return false;p.setStatusId(5);save();setPetArchiveTime(p.getPetId(),false);return true;}
    public boolean restorePet(Pet p){if(p==null||p.getStatusId()!=5)return false;p.setStatusId(1);save();setPetArchiveTime(p.getPetId(),true);return true;}
    private void setPetArchiveTime(String id,boolean restored){String sql=restored?"UPDATE pets SET archived_at=NULL,restored_at=CURRENT_TIMESTAMP WHERE pet_id=?":"UPDATE pets SET archived_at=CURRENT_TIMESTAMP WHERE pet_id=?";try(Connection c=Database.getConnection();PreparedStatement ps=c.prepareStatement(sql)){ps.setString(1,id);ps.executeUpdate();}catch(SQLException e){throw db(e);}}
    public boolean archiveUser(User u){
        if(u==null||u.isArchived())return false;
        boolean self=Session.currentUser!=null&&Session.currentUser.getUserId().equalsIgnoreCase(u.getUserId());
        String by=self?u.getUserId():"admin";
        String reason=self?"Account archived by the user":"Account archived by admin";
        try(Connection c=Database.getConnection();PreparedStatement ps=c.prepareStatement("INSERT INTO archive(archive_id,user_id,archive_date,reason,archived_by) VALUES(?,?,?,?,?)")){
            ps.setString(1,nextId("archive","archive_id","R"));ps.setString(2,u.getUserId());ps.setString(3,today());ps.setString(4,reason);ps.setString(5,by);ps.executeUpdate();
        }catch(SQLException e){throw db(e);}
        u.setArchived(true);return true;
    }
    public boolean restoreUser(User u){
        if(u==null||!u.isArchived())return false;
        try(Connection c=Database.getConnection();PreparedStatement ps=c.prepareStatement("DELETE FROM archive WHERE user_id=?")){
            ps.setString(1,u.getUserId());ps.executeUpdate();
        }catch(SQLException e){throw db(e);}
        u.setArchived(false);return true;
    }
    public boolean archiveSubmission(PetSubmission s){if(s==null)return false;s.setStatus("Archived");Pet p=findPet(s.getPetId());if(p!=null&&p.getStatusId()!=2)p.setStatusId(5);save();updateSubmissionArchiveTime(s.getSubmissionId(),false);return true;}
    public boolean restoreSubmission(PetSubmission s){if(s==null||!"Archived".equalsIgnoreCase(s.getStatus()))return false;s.setStatus("Pending");Pet p=findPet(s.getPetId());if(p!=null&&p.getStatusId()==5)p.setStatusId(3);save();updateSubmissionArchiveTime(s.getSubmissionId(),true);return true;}
    private void updateSubmissionArchiveTime(String id,boolean restored){String sql=restored?"UPDATE pet_submissions SET archived_at=NULL,restored_at=CURRENT_TIMESTAMP WHERE submission_id=?":"UPDATE pet_submissions SET archived_at=CURRENT_TIMESTAMP WHERE submission_id=?";try(Connection c=Database.getConnection();PreparedStatement ps=c.prepareStatement(sql)){ps.setString(1,id);ps.executeUpdate();}catch(SQLException e){throw db(e);}}
    public void updateUser(User u,String first,String last,String age,String address,String contact,String email){if(u==null)return;u.setFirstName(first);u.setLastName(last);u.setAge(age);u.setAddress(address);u.setContact(contact);u.setEmail(email);save();}
    public void updatePassword(User u,String newPassword){if(u!=null){u.setPassword(hash(newPassword));save();}}

    /** Reads database-stored audit events for a record. */
    public String getAuditTimeline(String entityType, String entityId) {
        StringBuilder out = new StringBuilder();
        String sql = "SELECT event_type,event_at,details FROM audit_events WHERE entity_type=? AND entity_id=? ORDER BY event_at,event_id";
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, entityType); ps.setString(2, entityId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    if (out.length() > 0) out.append("\n");
                    out.append(rs.getString("event_type").replace('_', ' ')).append(": ").append(rs.getString("event_at"));
                    String details = rs.getString("details");
                    if (details != null && !details.isBlank()) out.append(" — ").append(details);
                }
            }
        } catch (SQLException ex) {
            return "Audit timeline requires PAWCARE_AUDIT_TIMESTAMPS_MIGRATION.sql.";
        }
        return out.length() == 0 ? "No audit events recorded yet." : out.toString();
    }

    /**
     * Persists the current Java model to MySQL. This replaces pawcare_data.dat.
     * The GUI can keep calling save() exactly as before.
     */
    public void save(){
        try(Connection c=Database.getConnection()){
            c.setAutoCommit(false);
            try {
                for(User u:users) upsertUser(c,u);
                for(Pet p:pets) upsertPet(c,p);
                for(Adoption a:adoptions) upsertAdoption(c,a);
                for(PetSubmission s:submissions) upsertSubmission(c,s);
                c.commit();
            } catch(SQLException e){c.rollback();throw e;}
            finally{c.setAutoCommit(true);}
        }catch(SQLException e){throw db(e);}
    }

    private void insertUser(Connection c,User u)throws SQLException{try(PreparedStatement ps=c.prepareStatement("INSERT INTO users(user_id,password,first_name,last_name,contact,address,email,age,role_type) VALUES(?,?,?,?,?,?,?,?,?)")){bindUser(ps,u);ps.executeUpdate();}}
    private void upsertUser(Connection c,User u)throws SQLException{try(PreparedStatement ps=c.prepareStatement("INSERT INTO users(user_id,password,first_name,last_name,contact,address,email,age,role_type) VALUES(?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE password=VALUES(password),first_name=VALUES(first_name),last_name=VALUES(last_name),contact=VALUES(contact),address=VALUES(address),email=VALUES(email),age=VALUES(age)")){bindUser(ps,u);ps.executeUpdate();}}
    private void bindUser(PreparedStatement ps,User u)throws SQLException{ps.setString(1,u.getUserId());ps.setString(2,u.getPassword());ps.setString(3,u.getFirstName());ps.setString(4,u.getLastName());ps.setString(5,u.getContact());ps.setString(6,u.getAddress());ps.setString(7,u.getEmail());ps.setString(8,u.getAge());ps.setString(9,u.getRoleType());}
    private void insertPet(Connection c,Pet p)throws SQLException{try(PreparedStatement ps=c.prepareStatement("INSERT INTO pets(pet_id,name,type,breed,age,gender,health,vaccination,dewormed,disability,personality,special_care,image_resource,status_id,user_id,spayed_neutered,good_with_kids,medical_history,date_added) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")){bindPet(ps,p);ps.executeUpdate();}}
    private void upsertPet(Connection c,Pet p)throws SQLException{try(PreparedStatement ps=c.prepareStatement("INSERT INTO pets(pet_id,name,type,breed,age,gender,health,vaccination,dewormed,disability,personality,special_care,image_resource,status_id,user_id,spayed_neutered,good_with_kids,medical_history,date_added) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE name=VALUES(name),type=VALUES(type),breed=VALUES(breed),age=VALUES(age),gender=VALUES(gender),health=VALUES(health),vaccination=VALUES(vaccination),dewormed=VALUES(dewormed),disability=VALUES(disability),personality=VALUES(personality),special_care=VALUES(special_care),image_resource=VALUES(image_resource),status_id=VALUES(status_id),user_id=VALUES(user_id),spayed_neutered=VALUES(spayed_neutered),good_with_kids=VALUES(good_with_kids),medical_history=VALUES(medical_history),date_added=VALUES(date_added)")){bindPet(ps,p);ps.executeUpdate();}}
    private void bindPet(PreparedStatement ps,Pet p)throws SQLException{ps.setString(1,p.getPetId());ps.setString(2,p.getName());ps.setString(3,p.getType());ps.setString(4,p.getBreed());ps.setString(5,p.getAge());ps.setString(6,p.getGender());ps.setString(7,p.getHealth());ps.setString(8,p.getVaccination());ps.setString(9,p.getDewormed());ps.setString(10,p.getDisability());ps.setString(11,p.getPersonality());ps.setString(12,p.getSpecialCare());ps.setString(13,p.getImageResource());ps.setInt(14,p.getStatusId());if(p.getUserId()==null||p.getUserId().isBlank())ps.setNull(15,Types.VARCHAR);else ps.setString(15,p.getUserId());ps.setString(16,p.getSpayedNeutered());ps.setString(17,p.getGoodWithKids());ps.setString(18,p.getMedicalHistory());ps.setString(19,p.getDateAdded()==null||p.getDateAdded().isBlank()?today():p.getDateAdded());}
    private void upsertAdoption(Connection c,Adoption a)throws SQLException{try(PreparedStatement ps=c.prepareStatement("INSERT INTO adoptions(adoption_id,pet_id,user_id,adoption_date,pet_name,status,fulfillment_method,fulfillment_status,delivery_address,delivery_name,delivery_contact) VALUES(?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE pet_id=VALUES(pet_id),user_id=VALUES(user_id),adoption_date=VALUES(adoption_date),pet_name=VALUES(pet_name),status=VALUES(status),fulfillment_method=VALUES(fulfillment_method),fulfillment_status=VALUES(fulfillment_status),delivery_address=VALUES(delivery_address),delivery_name=VALUES(delivery_name),delivery_contact=VALUES(delivery_contact)")){ps.setString(1,a.getAdoptionId());ps.setString(2,a.getPetId());ps.setString(3,a.getUserId());ps.setString(4,a.getDate());ps.setString(5,a.getPetName());ps.setString(6,a.getStatus());ps.setString(7,a.getFulfillmentMethod());ps.setString(8,a.getFulfillmentStatus());ps.setString(9,a.getDeliveryAddress());ps.setString(10,a.getDeliveryName());ps.setString(11,a.getDeliveryContact());ps.executeUpdate();}}
    private void upsertSubmission(Connection c,PetSubmission s)throws SQLException{try(PreparedStatement ps=c.prepareStatement("INSERT INTO pet_submissions(submission_id,user_id,pet_id,submission_date,status) VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE user_id=VALUES(user_id),pet_id=VALUES(pet_id),submission_date=VALUES(submission_date),status=VALUES(status)")){ps.setString(1,s.getSubmissionId());ps.setString(2,s.getUserId());ps.setString(3,s.getPetId());ps.setString(4,s.getDate());ps.setString(5,s.getStatus());ps.executeUpdate();}}

    private User userFrom(ResultSet rs)throws SQLException{User u=new User(rs.getString("user_id"),rs.getString("password"),rs.getString("first_name"),rs.getString("last_name"),rs.getString("contact"),rs.getString("address"),rs.getString("email"),rs.getString("age"));u.setArchived(rs.getBoolean("archived"));return u;}
    private String nextId(String table,String column,String prefix){
        String sql="SELECT " + column + " FROM " + table + " WHERE " + column + " LIKE ? ORDER BY CAST(SUBSTRING(" + column + ",2) AS UNSIGNED) DESC LIMIT 1";
        try(Connection c=Database.getConnection();PreparedStatement ps=c.prepareStatement(sql)){ps.setString(1,prefix+"%");try(ResultSet rs=ps.executeQuery()){int n=rs.next()?Integer.parseInt(rs.getString(1).substring(1))+1:1;return String.format(prefix+"%03d",n);}}catch(Exception e){throw new IllegalStateException("Could not generate the next PawCare ID.", e);}
    }
    private static String nvl(String s){return s==null?"":s;}
    private static String nvl(String s,String fallback){return s==null||s.isBlank()?fallback:s;}
    private static RuntimeException db(SQLException e){return new IllegalStateException("PawCare database error: "+e.getMessage(),e);}
    private static String hash(String value){try{MessageDigest md=MessageDigest.getInstance("SHA-256");byte[] b=md.digest(value.getBytes(StandardCharsets.UTF_8));StringBuilder s=new StringBuilder();for(byte x:b)s.append(String.format("%02x",x));return s.toString();}catch(Exception e){throw new IllegalStateException(e);}}
    public static String passwordHash(String value){return hash(value);}
    public String today(){return new SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date());}
}
