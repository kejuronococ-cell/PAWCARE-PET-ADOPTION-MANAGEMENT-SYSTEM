package com.mycompany.pawcare.helpers;

import com.mycompany.pawcare.screens.*;
import com.mycompany.pawcare.popups.*;
import com.mycompany.pawcare.cards.*;

import java.awt.Dimension;
import java.awt.Image;
import java.net.URL;
import java.io.File;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

/**
 * Label that shows a pet picture scaled to fit a box (boxWidth x boxHeight).
 * The picture comes from the "imagePath" property, so it also shows in
 * NetBeans Design view. Example: /com/mycompany/pawcare/images/buddy.jfif
 */
public class PetPhoto extends JLabel {

    private String imagePath;
    private int boxWidth = 250;
    private int boxHeight = 190;

    public PetPhoto() {
        setHorizontalAlignment(SwingConstants.CENTER);
        setPreferredSize(new Dimension(boxWidth, boxHeight));
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
        update();
    }

    public int getBoxWidth() {
        return boxWidth;
    }

    public void setBoxWidth(int w) {
        boxWidth = w;
        setPreferredSize(new Dimension(boxWidth, boxHeight));
        update();
    }

    public int getBoxHeight() {
        return boxHeight;
    }

    public void setBoxHeight(int h) {
        boxHeight = h;
        setPreferredSize(new Dimension(boxWidth, boxHeight));
        update();
    }

    private void update() {
        Image im = null;
        if (imagePath != null && !imagePath.isBlank()) {
            try {
                if (imagePath.startsWith("/com/mycompany/pawcare/images/")) {
                    URL u = PetPhoto.class.getResource(imagePath);
                    if (u != null) im = new ImageIcon(u).getImage();
                } else {
                    File file = new File(imagePath);
                    if (file.isFile()) im = new ImageIcon(file.getAbsolutePath()).getImage();
                }
            } catch (Exception ignored) { im = null; }
        }
        if (im == null || im.getWidth(null) <= 0 || im.getHeight(null) <= 0) {
            setIcon(null);
            setText("No photo");
            setForeground(new java.awt.Color(125, 125, 125));
            setOpaque(true);
            setBackground(new java.awt.Color(245, 245, 245));
            return;
        }
        int iw = im.getWidth(null), ih = im.getHeight(null);
        double sc = Math.min((double) boxWidth / iw, (double) boxHeight / ih);
        int nw = Math.max(1, (int) (iw * sc));
        int nh = Math.max(1, (int) (ih * sc));
        setText("");
        setOpaque(false);
        setIcon(new ImageIcon(im.getScaledInstance(nw, nh, Image.SCALE_SMOOTH)));
    }
}
