package com.mycompany.pawcare.helpers;

import java.awt.Component;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

/** Stores customer/admin-selected pet photos outside the application JAR. */
public final class PetPhotoStorage {
    private static final long MAX_BYTES = 2L * 1024L * 1024L;
    private PetPhotoStorage() {}

    public static String chooseAndCopy(Component parent) {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Choose Pet Photo");
        chooser.setFileFilter(new FileNameExtensionFilter("Pet photos (*.jpg, *.jpeg, *.png, *.jfif)", "jpg", "jpeg", "png", "jfif"));
        if (chooser.showOpenDialog(parent) != JFileChooser.APPROVE_OPTION) return null;
        File selected = chooser.getSelectedFile();
        String name = selected.getName();
        int dot = name.lastIndexOf('.');
        String ext = dot < 0 ? "" : name.substring(dot + 1).toLowerCase(java.util.Locale.ROOT);
        if (!java.util.Arrays.asList("jpg", "jpeg", "png", "jfif").contains(ext)) {
            JOptionPane.showMessageDialog(parent, "Choose a JPG, JPEG, PNG, or JFIF image.", "Unsupported Photo", JOptionPane.WARNING_MESSAGE);
            return null;
        }
        if (!selected.isFile() || selected.length() > MAX_BYTES) {
            JOptionPane.showMessageDialog(parent, "The photo must exist and be no larger than 2 MB.", "Photo Too Large or Missing", JOptionPane.WARNING_MESSAGE);
            return null;
        }
        try {
            Path folder = Path.of(System.getProperty("user.home"), ".pawcare", "pet_images");
            Files.createDirectories(folder);
            String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss_SSS"));
            Path target = folder.resolve(stamp + "_" + UUID.randomUUID().toString().substring(0, 8) + "." + ext);
            Files.copy(selected.toPath(), target, StandardCopyOption.COPY_ATTRIBUTES);
            return target.toAbsolutePath().toString();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(parent, "Could not save the selected photo: " + ex.getMessage(), "Photo Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }
}
