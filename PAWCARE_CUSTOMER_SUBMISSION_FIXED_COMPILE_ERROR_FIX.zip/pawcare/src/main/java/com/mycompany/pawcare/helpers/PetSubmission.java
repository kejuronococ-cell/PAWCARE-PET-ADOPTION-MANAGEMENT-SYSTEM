package com.mycompany.pawcare.helpers;

public class PetSubmission implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
    private final String submissionId,userId,petId,date;
    private String status;
    public PetSubmission(String submissionId,String userId,String petId,String date,String status){this.submissionId=submissionId;this.userId=userId;this.petId=petId;this.date=date;this.status=status;}
    public String getSubmissionId(){return submissionId;} public String getUserId(){return userId;} public String getPetId(){return petId;} public String getDate(){return date;} public String getStatus(){return status;} public void setStatus(String v){status=v;}
}
