package com.mycompany.pawcare.helpers;

import com.mycompany.pawcare.screens.*;
import com.mycompany.pawcare.popups.*;
import com.mycompany.pawcare.cards.*;

import java.awt.Color;

/** Shared state for all PAWCARE screens (one data manager, who is logged in, colours). */
public final class Session {

    private Session() {
    }

    public static final Color BLUE = new Color(43, 126, 224), GREEN = new Color(52, 171, 83), PINK = new Color(231, 65, 108),
            PURPLE = new Color(126, 79, 195), ORANGE = new Color(235, 154, 32), RED = new Color(214, 65, 55),
            NAVY = new Color(38, 48, 80), CREAM = new Color(255, 249, 241), GRAY = new Color(90, 90, 90);

    private static PetManager manager;
    public static User currentUser;
    public static Pet pendingAdoptionPet;

    /** The one PetManager used by every screen (created the first time it is needed). */
    public static synchronized PetManager manager() {
        if (manager == null) {
            manager = new PetManager();
        }
        return manager;
    }

    public static void logout() {
        currentUser = null;
        pendingAdoptionPet = null;
    }

    public static boolean adminOk(String user, String pass) {
        return manager().adminOk(user, pass);
    }
}
