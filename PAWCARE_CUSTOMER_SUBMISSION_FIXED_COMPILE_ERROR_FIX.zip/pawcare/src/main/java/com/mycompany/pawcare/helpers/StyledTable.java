package com.mycompany.pawcare.helpers;

import com.mycompany.pawcare.screens.*;
import com.mycompany.pawcare.popups.*;
import com.mycompany.pawcare.cards.*;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 * JTable with the PAWCARE look (navy header, 34px rows). Column names come from
 * the "columnTitles" property (comma separated) so Design view shows the header.
 */
public class StyledTable extends JTable {

    private String columnTitles = "";

    public StyledTable() {
        setRowHeight(34);
        setFont(new Font("SansSerif", Font.PLAIN, 14));
        getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 14));
        getTableHeader().setBackground(new Color(38, 48, 80));
        getTableHeader().setForeground(Color.WHITE);
        setSelectionBackground(new Color(226, 214, 246));
        setSelectionForeground(new Color(38, 48, 80));
    }

    public String getColumnTitles() {
        return columnTitles;
    }

    public void setColumnTitles(String titles) {
        this.columnTitles = titles;
        setRows(new Object[0][]);
    }

    /** Replace all rows (cells cannot be edited). */
    public void setRows(Object[][] data) {
        String[] cols = columnTitles.isEmpty() ? new String[0] : columnTitles.split(",");
        setModel(new DefaultTableModel(data, cols) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        });
    }

    /** Text in the first column of the selected row, or null. */
    public String selectedId() {
        int r = getSelectedRow();
        return r < 0 ? null : String.valueOf(getValueAt(r, 0));
    }
}
