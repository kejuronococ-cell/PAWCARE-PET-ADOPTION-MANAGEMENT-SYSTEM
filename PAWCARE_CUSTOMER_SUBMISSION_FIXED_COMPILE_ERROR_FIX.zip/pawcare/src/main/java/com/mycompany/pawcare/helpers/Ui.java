package com.mycompany.pawcare.helpers;

import com.mycompany.pawcare.screens.*;
import com.mycompany.pawcare.popups.*;
import com.mycompany.pawcare.cards.*;

import java.awt.Color;
import java.awt.Component;
import java.awt.Image;
import java.util.regex.Pattern;
import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/** Small helpers shared by all PAWCARE screens: message boxes, validation, colours. */
public final class Ui {

    private Ui() {
    }

    // ---------- message boxes ----------
    public static void msg(Component parent, String text, String title, int type) {
        JOptionPane.showMessageDialog(parent, text, title, type);
    }

    public static boolean confirm(Component parent, String text) {
        return JOptionPane.showConfirmDialog(parent, text, "Confirm", JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE) == JOptionPane.YES_OPTION;
    }

    public static Color statusColor(Pet p) {
        return p.getStatusId() == 1 ? Session.GREEN : p.getStatusId() == 2 ? Session.PINK
                : p.getStatusId() == 5 ? Session.GRAY : Session.ORANGE;
    }

    // ---------- validation (same rules as the original PawcareGUI) ----------
    private static final Pattern NAME = Pattern.compile("[A-Za-z][A-Za-z .'-]*");
    private static final Pattern DIGITS = Pattern.compile("\\d+");

    public static boolean validName(String s) {
        return s != null && !s.isBlank() && s.length() <= 50 && NAME.matcher(s.trim()).matches();
    }

    public static boolean validAge(String s) {
        try {
            int n = Integer.parseInt(s.trim());
            return DIGITS.matcher(s.trim()).matches() && n >= 1 && n <= 120;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean validPetAge(String s) {
        if (s == null || s.trim().isEmpty()) return false;
        String value = s.trim().toLowerCase(java.util.Locale.ROOT);
        if (value.matches("\\d+")) {
            try { return Integer.parseInt(value) <= 30; } catch (NumberFormatException ex) { return false; }
        }
        java.util.regex.Pattern part = java.util.regex.Pattern.compile("(?i)(\\d+)\\s*(years?|yrs?|months?|mos?|days?|d)");
        java.util.regex.Matcher matcher = part.matcher(value);
        StringBuffer remainder = new StringBuffer();
        boolean found = false;
        while (matcher.find()) {
            found = true;
            try { if (Integer.parseInt(matcher.group(1)) > 120) return false; }
            catch (NumberFormatException ex) { return false; }
            matcher.appendReplacement(remainder, "");
        }
        matcher.appendTail(remainder);
        return found && remainder.toString().replaceAll("[,\\s]", "").isEmpty();
    }

    public static boolean validContact(String s) {
        return s != null && s.matches("\\d{11}");
    }

    public static boolean validEmail(String s) {
        return s != null && s.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    }

    public static boolean validAddress(String s) {
        return s != null && !s.trim().isBlank() && s.length() <= 150 && s.matches("[A-Za-z0-9 .,#'/ -]+");
    }

    public static String validateAccount(String first, String last, String pass, String confirm, String age,
            String address, String contact, String email) {
        if (!validName(first) || !validName(last)) {
            return "First name and last name must contain letters only (spaces, apostrophes, and hyphens are allowed).";
        }
        if (pass.length() < 6) {
            return "Password must be at least 6 characters.";
        }
        if (!pass.equals(confirm)) {
            return "Passwords do not match.";
        }
        if (!validAge(age)) {
            return "Age must contain numbers only and must be between 1 and 120.";
        }
        if (!validAddress(address)) {
            return "Please enter a valid address.";
        }
        if (!validContact(contact)) {
            return "Contact number must contain exactly 11 digits.";
        }
        if (!validEmail(email)) {
            return "Please enter a valid email address.";
        }
        return null;
    }

    public static String validateProfile(String first, String last, String age, String address, String contact,
            String email) {
        if (!validName(first) || !validName(last)) {
            return "First name and last name must contain letters only.";
        }
        if (!validAge(age)) {
            return "Age must contain numbers only and be between 1 and 120.";
        }
        if (!validAddress(address)) {
            return "Please enter a valid address.";
        }
        if (!validContact(contact)) {
            return "Contact number must contain exactly 11 digits.";
        }
        if (!validEmail(email)) {
            return "Please enter a valid email address.";
        }
        return null;
    }

    public static String validatePet(String name, String type, String breed, String age, String gender,
            String health, String personality, String care) {
        if (!validName(name)) {
            return "Pet name must contain letters only (spaces, apostrophes, and hyphens allowed).";
        }
        if (!validName(breed)) {
            return "Breed must contain letters, spaces, apostrophes, or hyphens only.";
        }
        if (!validPetAge(age)) {
            return "Enter an age such as 1 year, 1 month, 2 days.";
        }
        if (health.isBlank() || personality.isBlank() || care.isBlank()) {
            return "Health, personality, and special care are required.";
        }
        return null;
    }

    // ---------- red border on invalid fields ----------
    public static void markInvalid(JComponent c, boolean bad) {
        c.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(bad ? Session.RED : new Color(210, 205, 215), bad ? 2 : 1, true),
                BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        c.repaint();
    }

    public static boolean fieldValid(JTextField f, boolean valid) {
        markInvalid(f, !valid);
        return valid;
    }

    private static class Doc implements DocumentListener {

        private final Runnable r;

        Doc(Runnable r) {
            this.r = r;
        }

        public void insertUpdate(DocumentEvent e) {
            r.run();
        }

        public void removeUpdate(DocumentEvent e) {
            r.run();
        }

        public void changedUpdate(DocumentEvent e) {
            r.run();
        }
    }

    public static void onChange(JTextField f, Runnable r) {
        f.getDocument().addDocumentListener(new Doc(r));
    }

    public static void attachBasicValidation(JTextField first, JTextField last, JTextField age, JTextField address,
            JTextField contact, JTextField email) {
        Runnable run = () -> {
            fieldValid(first, first.getText().isBlank() || validName(first.getText()));
            fieldValid(last, last.getText().isBlank() || validName(last.getText()));
            fieldValid(age, age.getText().isBlank() || validAge(age.getText()));
            fieldValid(address, address.getText().isBlank() || validAddress(address.getText()));
            fieldValid(contact, contact.getText().isBlank() || validContact(contact.getText()));
            fieldValid(email, email.getText().isBlank() || validEmail(email.getText()));
        };
        for (JTextField f : new JTextField[]{first, last, age, address, contact, email}) {
            onChange(f, run);
        }
    }

    public static void attachPasswordValidation(JPasswordField pass, JPasswordField confirm) {
        Runnable run = () -> {
            String a = new String(pass.getPassword()), b = new String(confirm.getPassword());
            // Keep the Password field neutral while typing. The confirmation field
            // is the visual mismatch indicator requested by the PawCare UI.
            markInvalid(pass, false);
            fieldValid(confirm, (a.isBlank() && b.isBlank()) || a.equals(b));
        };
        onChange(pass, run);
        onChange(confirm, run);
    }

    public static void attachPetValidation(JTextField name, JTextField breed, JTextField age, JTextField health,
            JTextField personality, JTextField care) {
        Runnable run = () -> {
            fieldValid(name, name.getText().isBlank() || validName(name.getText()));
            fieldValid(breed, breed.getText().isBlank() || validName(breed.getText()));
            fieldValid(age, age.getText().isBlank() || validPetAge(age.getText()));
            fieldValid(health, true);
            fieldValid(personality, true);
            fieldValid(care, true);
        };
        for (JTextField f : new JTextField[]{name, breed, age, health, personality, care}) {
            onChange(f, run);
        }
    }
}
