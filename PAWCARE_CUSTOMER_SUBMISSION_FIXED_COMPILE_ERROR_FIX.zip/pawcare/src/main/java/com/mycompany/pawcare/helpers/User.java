package com.mycompany.pawcare.helpers;

public class User implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
    private final String userId;
    private String firstName,lastName,password,contact,address,email,age;
    private boolean archived; // derived from the Archive table (a row exists for this user)
    private String roleType="CUSTOMER"; // ADMIN or CUSTOMER
    public User(String userId,String password,String firstName,String lastName,String contact,String address,String email,String age){
        this.userId=userId; this.password=password; this.firstName=firstName; this.lastName=lastName; this.contact=contact; this.address=address; this.email=email; this.age=age;
    }
    public String getUserId(){return userId;} public String getPassword(){return password;} public String getFirstName(){return firstName;} public String getLastName(){return lastName;}
    public String getFullName(){return (firstName+" "+lastName).trim();} public String getContact(){return contact;} public String getAddress(){return address;} public String getEmail(){return email;} public String getAge(){return age;}
    public String getRoleType(){return roleType;} public void setRoleType(String v){roleType=v;}
    public boolean isArchived(){return archived;} public void setArchived(boolean v){archived=v;}
    public void setPassword(String v){password=v;} public void setFirstName(String v){firstName=v;} public void setLastName(String v){lastName=v;} public void setContact(String v){contact=v;} public void setAddress(String v){address=v;} public void setEmail(String v){email=v;} public void setAge(String v){age=v;}
}
