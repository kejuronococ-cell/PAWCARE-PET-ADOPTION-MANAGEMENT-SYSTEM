/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package com.mycompany.pawcare.popups;

import com.mycompany.pawcare.screens.*;
import com.mycompany.pawcare.cards.*;
import com.mycompany.pawcare.helpers.*;

/**
 *
 * @author Student
 */
public class AdoptionInfoDialog extends javax.swing.JDialog {

    private final javax.swing.JLabel lblFulfillment = new javax.swing.JLabel("Fulfillment");
    private final javax.swing.JLabel lblFulfillmentDetails = new javax.swing.JLabel("Pickup / Delivery Details");
    private final javax.swing.JTextField txtFulfillmentMethod = new javax.swing.JTextField();
    private final javax.swing.JTextArea txtFulfillmentDetails = new javax.swing.JTextArea(3, 28);
    private final javax.swing.JScrollPane detailsScroll = new javax.swing.JScrollPane(txtFulfillmentDetails);

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(AdoptionInfoDialog.class.getName());

    public AdoptionInfoDialog(java.awt.Frame parent, boolean modal, Adoption a) {
        super(parent, modal);
        initComponents();
        getContentPane().setBackground(new java.awt.Color(255, 249, 241));
        setSize(620, 560);
        setMinimumSize(new java.awt.Dimension(590, 520));
        setLocationRelativeTo(parent);

        Pet p = Session.manager().findPet(a.getPetId());
        User u = Session.manager().findUser(a.getUserId());
        txtAdoptionId.setText(a.getAdoptionId());
        txtPetId.setText(a.getPetId());
        txtPet.setText(a.getPetName());
        txtOfficial.setText(p == null ? "" : p.getName());
        txtCustomerId.setText(a.getUserId());
        txtCustomer.setText(u == null ? "" : u.getFullName());
        txtDate.setText(a.getDate());
        // Keep this field short. Long concatenated fulfillment details previously
        // forced the entire form to scroll horizontally and clipped its labels.
        txtStatus.setText(a.getStatus());

        String method = a.getFulfillmentMethod();
        txtFulfillmentMethod.setText(method + "  |  " + a.getFulfillmentStatus());
        StringBuilder detail = new StringBuilder();
        if ("Pick Up".equalsIgnoreCase(method)) {
            detail.append("Pickup location: ").append(PetManager.PAWCARE_PICKUP_LOCATION);
        } else if ("Delivery".equalsIgnoreCase(method)) {
            String deliveryName = a.getDeliveryName();
            String deliveryContact = a.getDeliveryContact();
            String address = a.getDeliveryAddress();
            if (u != null) {
                if (deliveryName == null || deliveryName.isBlank()) deliveryName = u.getFullName();
                if (deliveryContact == null || deliveryContact.isBlank()) deliveryContact = u.getContact();
                if (address == null || address.isBlank()) address = u.getAddress();
            }
            // The Customer row already shows the adopter. Only show a different recipient.
            if (deliveryName != null && !deliveryName.isBlank()
                    && (u == null || !deliveryName.trim().equalsIgnoreCase(u.getFullName().trim()))) {
                detail.append("Recipient: ").append(deliveryName.trim()).append('\n');
            }
            detail.append("Contact: ").append(val(deliveryContact)).append('\n');
            detail.append("Address: ").append(val(address));
        } else {
            detail.append("Fulfillment has not been selected yet.");
        }
        txtFulfillmentDetails.setFont(new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 14));
        txtFulfillmentDetails.setLineWrap(true);
        txtFulfillmentDetails.setWrapStyleWord(true);
        txtFulfillmentDetails.setEditable(false);
        txtFulfillmentDetails.setOpaque(true);
        txtFulfillmentDetails.setBackground(new java.awt.Color(245, 245, 245));
        txtFulfillmentDetails.setBorder(javax.swing.BorderFactory.createCompoundBorder(
                javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true),
                javax.swing.BorderFactory.createEmptyBorder(5, 8, 5, 8)));
        detailsScroll.setBorder(null);
        detailsScroll.setPreferredSize(new java.awt.Dimension(350, 66));
        detailsScroll.setHorizontalScrollBarPolicy(javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        detailsScroll.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_NEVER);
        detail.append("\n\nADOPTION AUDIT TIMELINE\n").append(Session.manager().getAuditTimeline("ADOPTION", a.getAdoptionId()));
        detailsScroll.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        detailsScroll.setPreferredSize(new java.awt.Dimension(350, 130));
        txtFulfillmentDetails.setText(detail.toString());
        txtFulfillmentDetails.setCaretPosition(0);

        // Runtime-only compact form. GridBagLayout uses each row's natural height
        // rather than stretching every row to fill the full dialog.
        pnlForm.removeAll();
        pnlForm.setBorder(javax.swing.BorderFactory.createEmptyBorder(6, 10, 6, 10));
        pnlForm.setLayout(new java.awt.GridBagLayout());
        pnlForm.setBackground(new java.awt.Color(255, 249, 241));
        addInfoRow(0, lblAdoptionId, txtAdoptionId);
        addInfoRow(1, lblPetId, txtPetId);
        addInfoRow(2, lblPet, txtPet);
        addInfoRow(3, lblOfficial, txtOfficial);
        addInfoRow(4, lblCustomerId, txtCustomerId);
        addInfoRow(5, lblCustomer, txtCustomer);
        addInfoRow(6, lblDate, txtDate);
        addInfoRow(7, lblStatus, txtStatus);
        addInfoRow(8, lblFulfillment, txtFulfillmentMethod);
        java.awt.GridBagConstraints detailsLabel = new java.awt.GridBagConstraints();
        detailsLabel.gridx = 0; detailsLabel.gridy = 9;
        detailsLabel.insets = new java.awt.Insets(2, 4, 2, 12);
        detailsLabel.anchor = java.awt.GridBagConstraints.NORTHWEST;
        detailsLabel.fill = java.awt.GridBagConstraints.NONE;
        pnlForm.add(lblFulfillmentDetails, detailsLabel);
        java.awt.GridBagConstraints detailsValue = new java.awt.GridBagConstraints();
        detailsValue.gridx = 1; detailsValue.gridy = 9;
        detailsValue.insets = new java.awt.Insets(2, 4, 2, 4);
        detailsValue.anchor = java.awt.GridBagConstraints.NORTHWEST;
        detailsValue.fill = java.awt.GridBagConstraints.HORIZONTAL;
        detailsValue.weightx = 1.0;
        pnlForm.add(detailsScroll, detailsValue);

        scrollForm.setViewportView(pnlForm);
        scrollForm.setBorder(null);
        scrollForm.setHorizontalScrollBarPolicy(javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollForm.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollForm.getVerticalScrollBar().setUnitIncrement(18);
        scrollForm.getViewport().setBackground(new java.awt.Color(255, 249, 241));
        revalidate();
    }

    private void addInfoRow(int row, javax.swing.JLabel label, javax.swing.JTextField field) {
        label.setFont(new java.awt.Font("SansSerif", java.awt.Font.BOLD, 14));
        label.setForeground(new java.awt.Color(38, 48, 80));
        field.setFont(new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 14));
        field.setEditable(false);
        field.setToolTipText(field.getText());
        field.setPreferredSize(new java.awt.Dimension(350, 29));
        java.awt.GridBagConstraints left = new java.awt.GridBagConstraints();
        left.gridx = 0; left.gridy = row;
        left.insets = new java.awt.Insets(2, 4, 2, 12);
        left.anchor = java.awt.GridBagConstraints.WEST;
        left.fill = java.awt.GridBagConstraints.NONE;
        pnlForm.add(label, left);
        java.awt.GridBagConstraints right = new java.awt.GridBagConstraints();
        right.gridx = 1; right.gridy = row;
        right.insets = new java.awt.Insets(2, 4, 2, 4);
        right.anchor = java.awt.GridBagConstraints.WEST;
        right.fill = java.awt.GridBagConstraints.HORIZONTAL;
        right.weightx = 1.0;
        pnlForm.add(field, right);
    }

    private static String val(String value) { return value == null || value.isBlank() ? "None" : value; }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainPanel = new javax.swing.JPanel();
        lblTitle = new javax.swing.JLabel();
        scrollForm = new javax.swing.JScrollPane();
        pnlForm = new javax.swing.JPanel();
        lblAdoptionId = new javax.swing.JLabel();
        txtAdoptionId = new javax.swing.JTextField();
        lblPetId = new javax.swing.JLabel();
        txtPetId = new javax.swing.JTextField();
        lblPet = new javax.swing.JLabel();
        txtPet = new javax.swing.JTextField();
        lblOfficial = new javax.swing.JLabel();
        txtOfficial = new javax.swing.JTextField();
        lblCustomerId = new javax.swing.JLabel();
        txtCustomerId = new javax.swing.JTextField();
        lblCustomer = new javax.swing.JLabel();
        txtCustomer = new javax.swing.JTextField();
        lblDate = new javax.swing.JLabel();
        txtDate = new javax.swing.JTextField();
        lblStatus = new javax.swing.JLabel();
        txtStatus = new javax.swing.JTextField();
        pnlButtons = new javax.swing.JPanel();
        btnClose = new com.mycompany.pawcare.helpers.RoundedButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("ADOPTION INFORMATION");

        mainPanel.setBackground(new java.awt.Color(255, 249, 241));
        mainPanel.setPreferredSize(new java.awt.Dimension(600, 560));

        lblTitle.setFont(new java.awt.Font("SansSerif", 1, 25)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(231, 65, 108));
        lblTitle.setText("ADOPTION INFORMATION");

        pnlForm.setBackground(new java.awt.Color(255, 249, 241));
        pnlForm.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));

        lblAdoptionId.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblAdoptionId.setForeground(new java.awt.Color(38, 48, 80));
        lblAdoptionId.setText("Adoption ID");

        txtAdoptionId.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtAdoptionId.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtAdoptionId.setBackground(new java.awt.Color(245, 245, 245));
        txtAdoptionId.setEditable(false);

        lblPetId.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblPetId.setForeground(new java.awt.Color(38, 48, 80));
        lblPetId.setText("Pet ID");

        txtPetId.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtPetId.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtPetId.setBackground(new java.awt.Color(245, 245, 245));
        txtPetId.setEditable(false);

        lblPet.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblPet.setForeground(new java.awt.Color(38, 48, 80));
        lblPet.setText("Pet");

        txtPet.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtPet.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtPet.setBackground(new java.awt.Color(245, 245, 245));
        txtPet.setEditable(false);

        lblOfficial.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblOfficial.setForeground(new java.awt.Color(38, 48, 80));
        lblOfficial.setText("Official Pet Name");

        txtOfficial.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtOfficial.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtOfficial.setBackground(new java.awt.Color(245, 245, 245));
        txtOfficial.setEditable(false);

        lblCustomerId.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblCustomerId.setForeground(new java.awt.Color(38, 48, 80));
        lblCustomerId.setText("Customer ID");

        txtCustomerId.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtCustomerId.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtCustomerId.setBackground(new java.awt.Color(245, 245, 245));
        txtCustomerId.setEditable(false);

        lblCustomer.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblCustomer.setForeground(new java.awt.Color(38, 48, 80));
        lblCustomer.setText("Customer");

        txtCustomer.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtCustomer.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtCustomer.setBackground(new java.awt.Color(245, 245, 245));
        txtCustomer.setEditable(false);

        lblDate.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblDate.setForeground(new java.awt.Color(38, 48, 80));
        lblDate.setText("Date");

        txtDate.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtDate.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtDate.setBackground(new java.awt.Color(245, 245, 245));
        txtDate.setEditable(false);

        lblStatus.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblStatus.setForeground(new java.awt.Color(38, 48, 80));
        lblStatus.setText("Status");

        txtStatus.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtStatus.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtStatus.setBackground(new java.awt.Color(245, 245, 245));
        txtStatus.setEditable(false);

        pnlButtons.setOpaque(false);

        btnClose.setBackground(new java.awt.Color(38, 48, 80));
        btnClose.setForeground(new java.awt.Color(255, 255, 255));
        btnClose.setText("CLOSE");
        btnClose.addActionListener(this::btnCloseActionPerformed);

        javax.swing.GroupLayout pnlButtonsLayout = new javax.swing.GroupLayout(pnlButtons);
        pnlButtons.setLayout(pnlButtonsLayout);
        pnlButtonsLayout.setHorizontalGroup(
            pnlButtonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlButtonsLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(btnClose, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE))
        );
        pnlButtonsLayout.setVerticalGroup(
            pnlButtonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(btnClose, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pnlForm.setLayout(new java.awt.GridLayout(0, 2, 12, 12));
        pnlForm.add(lblAdoptionId);
        pnlForm.add(txtAdoptionId);
        pnlForm.add(lblPetId);
        pnlForm.add(txtPetId);
        pnlForm.add(lblPet);
        pnlForm.add(txtPet);
        pnlForm.add(lblOfficial);
        pnlForm.add(txtOfficial);
        pnlForm.add(lblCustomerId);
        pnlForm.add(txtCustomerId);
        pnlForm.add(lblCustomer);
        pnlForm.add(txtCustomer);
        pnlForm.add(lblDate);
        pnlForm.add(txtDate);
        pnlForm.add(lblStatus);
        pnlForm.add(txtStatus);

        scrollForm.setViewportView(pnlForm);

        javax.swing.GroupLayout mainPanelLayout = new javax.swing.GroupLayout(mainPanel);
        mainPanel.setLayout(mainPanelLayout);
        mainPanelLayout.setHorizontalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(mainPanelLayout.createSequentialGroup()
                    .addGap(18, 18, 18)
                    .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(lblTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(scrollForm, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(pnlButtons, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGap(18, 18, 18))
        );
        mainPanelLayout.setVerticalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(mainPanelLayout.createSequentialGroup()
                    .addGap(16, 16, 16)
                    .addComponent(lblTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(10, 10, 10)
                    .addComponent(scrollForm, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGap(10, 10, 10)
                    .addComponent(pnlButtons, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(16, 16, 16))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCloseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCloseActionPerformed
        dispose();
    }//GEN-LAST:event_btnCloseActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.mycompany.pawcare.helpers.RoundedButton btnClose;
    private javax.swing.JLabel lblAdoptionId;
    private javax.swing.JLabel lblCustomer;
    private javax.swing.JLabel lblCustomerId;
    private javax.swing.JLabel lblDate;
    private javax.swing.JLabel lblOfficial;
    private javax.swing.JLabel lblPet;
    private javax.swing.JLabel lblPetId;
    private javax.swing.JLabel lblStatus;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JPanel pnlButtons;
    private javax.swing.JPanel pnlForm;
    private javax.swing.JScrollPane scrollForm;
    private javax.swing.JTextField txtAdoptionId;
    private javax.swing.JTextField txtCustomer;
    private javax.swing.JTextField txtCustomerId;
    private javax.swing.JTextField txtDate;
    private javax.swing.JTextField txtOfficial;
    private javax.swing.JTextField txtPet;
    private javax.swing.JTextField txtPetId;
    private javax.swing.JTextField txtStatus;
    // End of variables declaration//GEN-END:variables
}
