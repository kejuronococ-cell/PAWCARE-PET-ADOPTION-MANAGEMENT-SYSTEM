/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package com.mycompany.pawcare.popups;

import com.mycompany.pawcare.screens.*;
import com.mycompany.pawcare.cards.*;
import com.mycompany.pawcare.helpers.*;

/**
 *
 * @author Student
 */
public class PetEditDialog extends javax.swing.JDialog {
    private final com.mycompany.pawcare.helpers.RoundedButton btnChoosePhoto = new com.mycompany.pawcare.helpers.RoundedButton();
    private final com.mycompany.pawcare.helpers.PetPhoto previewPhoto = new com.mycompany.pawcare.helpers.PetPhoto();

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(PetEditDialog.class.getName());

    public PetEditDialog(java.awt.Frame parent, boolean modal, Pet pet) {
        super(parent, modal);
        initComponents();
        cmbVacc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Anti-Rabies", "5-in-1 / DHPP", "Parvovirus", "Distemper", "Bordetella", "FVRCP", "Feline Leukemia", "Not vaccinated", "Others" }));
        getContentPane().setBackground(new java.awt.Color(255, 249, 241));
        // Keep the pet editing popup compact like the other PawCare information dialogs.
        pnlForm.setBorder(javax.swing.BorderFactory.createEmptyBorder(6, 8, 6, 8));
        pnlForm.setLayout(new java.awt.GridLayout(0, 2, 6, 6));
        setSize(650, 700);
        setLocationRelativeTo(parent);
        this.pet = pet;
        Ui.attachPetValidation(txtName, txtBreed, txtAge, txtHealth, txtPersonality, txtCare);
        scrollForm.getVerticalScrollBar().setUnitIncrement(16);
        txtImage.setVisible(false); lblImage.setVisible(false); lblStatus.setVisible(false); cmbStatus.setVisible(false);
        btnChoosePhoto.setText("Choose Photo"); btnChoosePhoto.setBackground(Session.PURPLE); btnChoosePhoto.setForeground(java.awt.Color.WHITE);
        btnChoosePhoto.addActionListener(e -> choosePhoto());
        previewPhoto.setBoxWidth(130); previewPhoto.setBoxHeight(85);
        pnlButtons.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 8, 4)); pnlButtons.removeAll();
        pnlButtons.add(previewPhoto); pnlButtons.add(btnChoosePhoto); pnlButtons.add(btnSave); pnlButtons.add(btnCancel);
        if (pet == null) {
            setTitle("ADD PET");
            lblTitle.setText("ADD PET");
            lblTitle.setForeground(Session.GREEN);
            btnSave.setText("ADD PET");
            btnSave.setBackground(Session.GREEN);
            txtImage.setText("");
        } else {
            setTitle("UPDATE PET");
            txtName.setText(pet.getName());
            cmbType.setSelectedItem(pet.getType());
            txtBreed.setText(pet.getBreed());
            txtAge.setText(pet.getAge());
            cmbGender.setSelectedItem(pet.getGender());
            txtHealth.setText(pet.getHealth());
            cmbVacc.setSelectedItem(pet.getVaccination() != null && pet.getVaccination().startsWith("Others:") ? "Others" : pet.getVaccination());
            cmbDew.setSelectedItem(pet.getDewormed());
            cmbDis.setSelectedItem(pet.getDisability() != null && !java.util.Arrays.asList("None", "Mobility issue", "Vision issue", "Hearing issue", "Other").contains(pet.getDisability()) ? "Other" : pet.getDisability());
            txtPersonality.setText(pet.getPersonality());
            txtCare.setText(pet.getSpecialCare());
            txtImage.setText(pet.getImageResource()); previewPhoto.setImagePath(pet.getImageResource()); btnChoosePhoto.setText("Change Photo");
            cmbStatus.setSelectedItem(pet.getStatus());
            if (pet.getStatusId() == 2 || pet.getStatusId() == 3) { btnSave.setEnabled(false); txtName.setEditable(false); txtBreed.setEditable(false); txtAge.setEditable(false); }
        }
    }

    private final Pet pet;

    private void choosePhoto() {
        String path = PetPhotoStorage.chooseAndCopy(this);
        if (path != null) { txtImage.setText(path); previewPhoto.setImagePath(path); btnChoosePhoto.setText("Change Photo"); }
    }

    private void deleteUploadedPhoto(String value) {
        try {
            java.nio.file.Path root = java.nio.file.Path.of(System.getProperty("user.home"), ".pawcare", "pet_images").toAbsolutePath().normalize();
            java.nio.file.Path old = java.nio.file.Path.of(value).toAbsolutePath().normalize();
            if (old.startsWith(root) && java.nio.file.Files.isRegularFile(old)) java.nio.file.Files.deleteIfExists(old);
        } catch (Exception ignored) { }
    }

    private void doSave() {
        if (pet != null && (pet.getStatusId() == 2 || pet.getStatusId() == 3)) { Ui.msg(this, "Pending or Adopted pets cannot be updated.", "Update Blocked", javax.swing.JOptionPane.WARNING_MESSAGE); return; }
        if (pet == null && (txtImage.getText().isBlank() || !new java.io.File(txtImage.getText()).isFile())) { Ui.msg(this, "Please choose a pet photo (JPG, JPEG, PNG, or JFIF, maximum 2 MB).", "Photo Required", javax.swing.JOptionPane.WARNING_MESSAGE); return; }
        if (!Ui.confirm(this, pet == null ? "Add this pet directly to the gallery?" : "Save these pet information changes?") ) return;
        String err = Ui.validatePet(txtName.getText(), (String) cmbType.getSelectedItem(), txtBreed.getText(), txtAge.getText(),
                (String) cmbGender.getSelectedItem(), txtHealth.getText(), txtPersonality.getText(), txtCare.getText());
        if (err != null) {
            Ui.msg(this, err, "Pet", javax.swing.JOptionPane.WARNING_MESSAGE);
            return;
        }
        int sid = pet == null ? 1 : pet.getStatusId();
        PetAdditionalDetailsDialog.Details extra = PetAdditionalDetailsDialog.show(this, pet, pet == null ? String.valueOf(cmbVacc.getSelectedItem()) : pet.getVaccination(), pet == null ? String.valueOf(cmbDis.getSelectedItem()) : pet.getDisability());
        if (extra == null) return;
        PetManager m = Session.manager();
        if (pet == null) {
            m.addPet(txtName.getText().trim(), (String) cmbType.getSelectedItem(), txtBreed.getText().trim(), txtAge.getText().trim(),
                    (String) cmbGender.getSelectedItem(), txtHealth.getText().trim(), extra.vaccination, (String) cmbDew.getSelectedItem(),
                    extra.disability, txtPersonality.getText().trim(), txtCare.getText().trim(), txtImage.getText().trim(), sid, "", extra.spayedNeutered, extra.goodWithKids, extra.medicalHistory);
        } else {
            pet.setName(txtName.getText().trim());
            pet.setType((String) cmbType.getSelectedItem());
            pet.setBreed(txtBreed.getText().trim());
            pet.setAge(txtAge.getText().trim());
            pet.setGender((String) cmbGender.getSelectedItem());
            pet.setHealth(txtHealth.getText().trim());
            pet.setVaccination(extra.vaccination);
            pet.setDewormed((String) cmbDew.getSelectedItem());
            pet.setDisability(extra.disability);
            pet.setSpayedNeutered(extra.spayedNeutered); pet.setGoodWithKids(extra.goodWithKids); pet.setMedicalHistory(extra.medicalHistory);
            pet.setPersonality(txtPersonality.getText().trim());
            pet.setSpecialCare(txtCare.getText().trim());
            String previousImage = pet.getImageResource();
            String selectedImage = txtImage.getText().trim();
            pet.setImageResource(selectedImage);
            pet.setStatusId(sid);
            m.save();
            if (previousImage != null && !previousImage.equals(selectedImage)) deleteUploadedPhoto(previousImage);
        }
        dispose();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainPanel = new javax.swing.JPanel();
        lblTitle = new javax.swing.JLabel();
        scrollForm = new javax.swing.JScrollPane();
        pnlForm = new javax.swing.JPanel();
        lblName = new javax.swing.JLabel();
        txtName = new javax.swing.JTextField();
        lblType = new javax.swing.JLabel();
        cmbType = new javax.swing.JComboBox<>();
        lblBreed = new javax.swing.JLabel();
        txtBreed = new javax.swing.JTextField();
        lblAge = new javax.swing.JLabel();
        txtAge = new javax.swing.JTextField();
        lblGender = new javax.swing.JLabel();
        cmbGender = new javax.swing.JComboBox<>();
        lblHealth = new javax.swing.JLabel();
        txtHealth = new javax.swing.JTextField();
        lblVacc = new javax.swing.JLabel();
        cmbVacc = new javax.swing.JComboBox<>();
        lblDew = new javax.swing.JLabel();
        cmbDew = new javax.swing.JComboBox<>();
        lblDis = new javax.swing.JLabel();
        cmbDis = new javax.swing.JComboBox<>();
        lblPersonality = new javax.swing.JLabel();
        txtPersonality = new javax.swing.JTextField();
        lblCare = new javax.swing.JLabel();
        txtCare = new javax.swing.JTextField();
        lblImage = new javax.swing.JLabel();
        txtImage = new javax.swing.JTextField();
        lblStatus = new javax.swing.JLabel();
        cmbStatus = new javax.swing.JComboBox<>();
        pnlButtons = new javax.swing.JPanel();
        btnSave = new com.mycompany.pawcare.helpers.RoundedButton();
        btnCancel = new com.mycompany.pawcare.helpers.RoundedButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("UPDATE PET");

        mainPanel.setBackground(new java.awt.Color(255, 249, 241));
        mainPanel.setPreferredSize(new java.awt.Dimension(650, 700));

        lblTitle.setFont(new java.awt.Font("SansSerif", 1, 26)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(235, 154, 32));
        lblTitle.setText("UPDATE PET");

        pnlForm.setBackground(new java.awt.Color(255, 249, 241));
        pnlForm.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));

        lblName.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblName.setForeground(new java.awt.Color(38, 48, 80));
        lblName.setText("Pet Name");

        txtName.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtName.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));

        lblType.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblType.setForeground(new java.awt.Color(38, 48, 80));
        lblType.setText("Type");

        cmbType.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        cmbType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Dog", "Cat" }));

        lblBreed.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblBreed.setForeground(new java.awt.Color(38, 48, 80));
        lblBreed.setText("Breed");

        txtBreed.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtBreed.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));

        lblAge.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblAge.setForeground(new java.awt.Color(38, 48, 80));
        lblAge.setText("Age");

        txtAge.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtAge.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));

        lblGender.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblGender.setForeground(new java.awt.Color(38, 48, 80));
        lblGender.setText("Gender");

        cmbGender.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        cmbGender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female" }));

        lblHealth.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblHealth.setForeground(new java.awt.Color(38, 48, 80));
        lblHealth.setText("Health");

        txtHealth.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtHealth.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));

        lblVacc.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblVacc.setForeground(new java.awt.Color(38, 48, 80));
        lblVacc.setText("Vaccination");

        cmbVacc.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        cmbVacc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Up to date", "Not vaccinated", "To be assessed" }));

        lblDew.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblDew.setForeground(new java.awt.Color(38, 48, 80));
        lblDew.setText("Dewormed");

        cmbDew.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        cmbDew.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Yes", "No", "Due", "To be assessed" }));

        lblDis.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblDis.setForeground(new java.awt.Color(38, 48, 80));
        lblDis.setText("Disability");

        cmbDis.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        cmbDis.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "None", "Mobility issue", "Vision issue", "Hearing issue", "Other" }));

        lblPersonality.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblPersonality.setForeground(new java.awt.Color(38, 48, 80));
        lblPersonality.setText("Personality");

        txtPersonality.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtPersonality.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));

        lblCare.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblCare.setForeground(new java.awt.Color(38, 48, 80));
        lblCare.setText("Special Care");

        txtCare.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtCare.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));

        lblImage.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblImage.setForeground(new java.awt.Color(38, 48, 80));
        lblImage.setText("Image Resource");

        txtImage.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtImage.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));

        lblStatus.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblStatus.setForeground(new java.awt.Color(38, 48, 80));
        lblStatus.setText("Status");

        cmbStatus.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        cmbStatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Available", "Adopted", "Pending", "Rejected" }));

        pnlButtons.setOpaque(false);

        btnSave.setBackground(new java.awt.Color(235, 154, 32));
        btnSave.setForeground(new java.awt.Color(255, 255, 255));
        btnSave.setText("SAVE UPDATE");
        btnSave.addActionListener(this::btnSaveActionPerformed);

        btnCancel.setBackground(new java.awt.Color(38, 48, 80));
        btnCancel.setForeground(new java.awt.Color(255, 255, 255));
        btnCancel.setText("CANCEL");
        btnCancel.addActionListener(this::btnCancelActionPerformed);

        javax.swing.GroupLayout pnlButtonsLayout = new javax.swing.GroupLayout(pnlButtons);
        pnlButtons.setLayout(pnlButtonsLayout);
        pnlButtonsLayout.setHorizontalGroup(
            pnlButtonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlButtonsLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(btnSave, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(5, 5, 5)
                    .addComponent(btnCancel, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE))
        );
        pnlButtonsLayout.setVerticalGroup(
            pnlButtonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(btnSave, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(btnCancel, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pnlForm.setLayout(new java.awt.GridLayout(0, 2, 12, 12));
        pnlForm.add(lblName);
        pnlForm.add(txtName);
        pnlForm.add(lblType);
        pnlForm.add(cmbType);
        pnlForm.add(lblBreed);
        pnlForm.add(txtBreed);
        pnlForm.add(lblAge);
        pnlForm.add(txtAge);
        pnlForm.add(lblGender);
        pnlForm.add(cmbGender);
        pnlForm.add(lblHealth);
        pnlForm.add(txtHealth);
        pnlForm.add(lblVacc);
        pnlForm.add(cmbVacc);
        pnlForm.add(lblDew);
        pnlForm.add(cmbDew);
        pnlForm.add(lblDis);
        pnlForm.add(cmbDis);
        pnlForm.add(lblPersonality);
        pnlForm.add(txtPersonality);
        pnlForm.add(lblCare);
        pnlForm.add(txtCare);
        pnlForm.add(lblImage);
        pnlForm.add(txtImage);
        pnlForm.add(lblStatus);
        pnlForm.add(cmbStatus);

        scrollForm.setViewportView(pnlForm);

        javax.swing.GroupLayout mainPanelLayout = new javax.swing.GroupLayout(mainPanel);
        mainPanel.setLayout(mainPanelLayout);
        mainPanelLayout.setHorizontalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(mainPanelLayout.createSequentialGroup()
                    .addGap(18, 18, 18)
                    .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(lblTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(scrollForm, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(pnlButtons, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGap(18, 18, 18))
        );
        mainPanelLayout.setVerticalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(mainPanelLayout.createSequentialGroup()
                    .addGap(16, 16, 16)
                    .addComponent(lblTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(10, 10, 10)
                    .addComponent(scrollForm, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGap(10, 10, 10)
                    .addComponent(pnlButtons, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(16, 16, 16))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveActionPerformed
        doSave();
    }//GEN-LAST:event_btnSaveActionPerformed

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelActionPerformed
        dispose();
    }//GEN-LAST:event_btnCancelActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.mycompany.pawcare.helpers.RoundedButton btnCancel;
    private com.mycompany.pawcare.helpers.RoundedButton btnSave;
    private javax.swing.JComboBox<String> cmbDew;
    private javax.swing.JComboBox<String> cmbDis;
    private javax.swing.JComboBox<String> cmbGender;
    private javax.swing.JComboBox<String> cmbStatus;
    private javax.swing.JComboBox<String> cmbType;
    private javax.swing.JComboBox<String> cmbVacc;
    private javax.swing.JLabel lblAge;
    private javax.swing.JLabel lblBreed;
    private javax.swing.JLabel lblCare;
    private javax.swing.JLabel lblDew;
    private javax.swing.JLabel lblDis;
    private javax.swing.JLabel lblGender;
    private javax.swing.JLabel lblHealth;
    private javax.swing.JLabel lblImage;
    private javax.swing.JLabel lblName;
    private javax.swing.JLabel lblPersonality;
    private javax.swing.JLabel lblStatus;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JLabel lblType;
    private javax.swing.JLabel lblVacc;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JPanel pnlButtons;
    private javax.swing.JPanel pnlForm;
    private javax.swing.JScrollPane scrollForm;
    private javax.swing.JTextField txtAge;
    private javax.swing.JTextField txtBreed;
    private javax.swing.JTextField txtCare;
    private javax.swing.JTextField txtHealth;
    private javax.swing.JTextField txtImage;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextField txtPersonality;
    // End of variables declaration//GEN-END:variables
}
