/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package com.mycompany.pawcare.popups;

import com.mycompany.pawcare.screens.*;
import com.mycompany.pawcare.cards.*;
import com.mycompany.pawcare.helpers.*;

/**
 *
 * @author Student
 */
public class PetInfoDialog extends javax.swing.JDialog {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(PetInfoDialog.class.getName());

    public PetInfoDialog(java.awt.Frame parent, boolean modal, Pet p) {
        super(parent, modal);
        initComponents();
        getContentPane().setBackground(new java.awt.Color(255, 249, 241));
        setSize(650, 650);
        setMinimumSize(new java.awt.Dimension(590, 540));
        setLocationRelativeTo(parent);

        txtPetId.setText(val(p.getPetId()));
        txtName.setText(val(p.getName()));
        txtType.setText(val(p.getType()));
        txtBreed.setText(val(p.getBreed()));
        txtAge.setText(val(p.getAge()) + " years");
        txtGender.setText(val(p.getGender()));
        txtHealth.setText(val(p.getHealth()));
        txtVaccination.setText(val(p.getVaccination()));
        txtDewormed.setText(val(p.getDewormed()));
        txtDisability.setText(val(p.getDisability()));
        txtPersonality.setText(val(p.getPersonality()));
        txtCare.setText(val(p.getSpecialCare()));
        txtStatus.setText(val(p.getStatus()));

        // Use the compact row spacing from the Customer Dashboard's Adoption Info popup.
        // Keep this as a runtime layout so NetBeans-generated components stay intact.
        pnlForm.removeAll();
        pnlForm.setBackground(new java.awt.Color(255, 249, 241));
        pnlForm.setBorder(javax.swing.BorderFactory.createEmptyBorder(6, 10, 6, 10));
        pnlForm.setLayout(new java.awt.GridBagLayout());
        scrollForm.setViewportView(pnlForm);
        scrollForm.setBorder(null);
        scrollForm.setHorizontalScrollBarPolicy(javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollForm.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollForm.getVerticalScrollBar().setUnitIncrement(18);
        scrollForm.getViewport().setBackground(new java.awt.Color(255, 249, 241));

        int row = 0;
        addSectionRow(row++, "BASIC INFORMATION");
        addInfoRow(row++, lblPetId, txtPetId);
        addInfoRow(row++, lblName, txtName);
        addInfoRow(row++, lblType, txtType);
        addInfoRow(row++, lblBreed, txtBreed);
        addInfoRow(row++, lblAge, txtAge);
        addInfoRow(row++, lblGender, txtGender);
        addInfoRow(row++, lblStatus, txtStatus);
        addValueRow(row++, "Date Added", p.getDateAdded());
        addTextAreaRow(row++, "Pet Audit Timeline", Session.manager().getAuditTimeline("PET", p.getPetId()));

        addSectionRow(row++, "HEALTH & CARE");
        addInfoRow(row++, lblHealth, txtHealth);
        addInfoRow(row++, lblVaccination, txtVaccination);
        addInfoRow(row++, lblDewormed, txtDewormed);
        addInfoRow(row++, lblDisability, txtDisability);
        addInfoRow(row++, lblPersonality, txtPersonality);
        addValueRow(row++, "Spayed / Neutered", p.getSpayedNeutered());
        addValueRow(row++, "Good with Kids", p.getGoodWithKids());
        addTextAreaRow(row++, "Special Care", p.getSpecialCare());
        addTextAreaRow(row++, "Medical History", p.getMedicalHistory());
        pnlForm.revalidate();
        pnlForm.repaint();
    }

    private void addSectionRow(int row, String title) {
        javax.swing.JLabel section = new javax.swing.JLabel(title);
        section.setFont(new java.awt.Font("SansSerif", java.awt.Font.BOLD, 13));
        section.setForeground(new java.awt.Color(126, 79, 195));
        java.awt.GridBagConstraints c = new java.awt.GridBagConstraints();
        c.gridx = 0; c.gridy = row; c.gridwidth = 2;
        c.insets = new java.awt.Insets(7, 4, 1, 4);
        c.fill = java.awt.GridBagConstraints.HORIZONTAL;
        c.weightx = 1.0;
        c.anchor = java.awt.GridBagConstraints.WEST;
        pnlForm.add(section, c);
    }

    private void addInfoRow(int row, javax.swing.JLabel label, javax.swing.JTextField field) {
        styleLabel(label);
        styleValueField(field);
        addRowComponents(row, label, field);
    }

    private void addValueRow(int row, String labelText, String value) {
        javax.swing.JLabel label = new javax.swing.JLabel(labelText);
        javax.swing.JTextField field = new javax.swing.JTextField(val(value));
        styleLabel(label);
        styleValueField(field);
        addRowComponents(row, label, field);
    }

    private void addTextAreaRow(int row, String labelText, String value) {
        javax.swing.JLabel label = new javax.swing.JLabel(labelText);
        styleLabel(label);
        javax.swing.JTextArea area = new javax.swing.JTextArea(val(value), 2, 26);
        area.setFont(new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 14));
        area.setEditable(false);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setBackground(new java.awt.Color(245, 245, 245));
        area.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 8, 5, 8));
        javax.swing.JScrollPane areaScroll = new javax.swing.JScrollPane(area);
        areaScroll.setPreferredSize(new java.awt.Dimension(350, 55));
        areaScroll.setHorizontalScrollBarPolicy(javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        areaScroll.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        addRowComponents(row, label, areaScroll);
    }

    private void addRowComponents(int row, javax.swing.JLabel label, java.awt.Component value) {
        java.awt.GridBagConstraints left = new java.awt.GridBagConstraints();
        left.gridx = 0; left.gridy = row;
        left.insets = new java.awt.Insets(2, 4, 2, 12);
        left.anchor = java.awt.GridBagConstraints.WEST;
        left.fill = java.awt.GridBagConstraints.NONE;
        pnlForm.add(label, left);
        java.awt.GridBagConstraints right = new java.awt.GridBagConstraints();
        right.gridx = 1; right.gridy = row;
        right.insets = new java.awt.Insets(2, 4, 2, 4);
        right.anchor = java.awt.GridBagConstraints.WEST;
        right.fill = java.awt.GridBagConstraints.HORIZONTAL;
        right.weightx = 1.0;
        pnlForm.add(value, right);
    }

    private static void styleLabel(javax.swing.JLabel label) {
        label.setFont(new java.awt.Font("SansSerif", java.awt.Font.BOLD, 14));
        label.setForeground(new java.awt.Color(38, 48, 80));
        label.setPreferredSize(new java.awt.Dimension(150, 26));
    }

    private static void styleValueField(javax.swing.JTextField field) {
        field.setFont(new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 14));
        field.setEditable(false);
        field.setBackground(new java.awt.Color(245, 245, 245));
        field.setToolTipText(field.getText());
        field.setPreferredSize(new java.awt.Dimension(350, 29));
    }

    private static String val(String v) { return v == null || v.isBlank() ? "None" : v; }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainPanel = new javax.swing.JPanel();
        lblTitle = new javax.swing.JLabel();
        scrollForm = new javax.swing.JScrollPane();
        pnlForm = new javax.swing.JPanel();
        lblPetId = new javax.swing.JLabel();
        txtPetId = new javax.swing.JTextField();
        lblName = new javax.swing.JLabel();
        txtName = new javax.swing.JTextField();
        lblType = new javax.swing.JLabel();
        txtType = new javax.swing.JTextField();
        lblBreed = new javax.swing.JLabel();
        txtBreed = new javax.swing.JTextField();
        lblAge = new javax.swing.JLabel();
        txtAge = new javax.swing.JTextField();
        lblGender = new javax.swing.JLabel();
        txtGender = new javax.swing.JTextField();
        lblHealth = new javax.swing.JLabel();
        txtHealth = new javax.swing.JTextField();
        lblVaccination = new javax.swing.JLabel();
        txtVaccination = new javax.swing.JTextField();
        lblDewormed = new javax.swing.JLabel();
        txtDewormed = new javax.swing.JTextField();
        lblDisability = new javax.swing.JLabel();
        txtDisability = new javax.swing.JTextField();
        lblPersonality = new javax.swing.JLabel();
        txtPersonality = new javax.swing.JTextField();
        lblCare = new javax.swing.JLabel();
        txtCare = new javax.swing.JTextField();
        lblStatus = new javax.swing.JLabel();
        txtStatus = new javax.swing.JTextField();
        pnlButtons = new javax.swing.JPanel();
        btnClose = new com.mycompany.pawcare.helpers.RoundedButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("PET INFORMATION");

        mainPanel.setBackground(new java.awt.Color(255, 249, 241));
        mainPanel.setPreferredSize(new java.awt.Dimension(600, 560));

        lblTitle.setFont(new java.awt.Font("SansSerif", 1, 25)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(126, 79, 195));
        lblTitle.setText("PET INFORMATION");

        pnlForm.setBackground(new java.awt.Color(255, 249, 241));
        pnlForm.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));

        lblPetId.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblPetId.setForeground(new java.awt.Color(38, 48, 80));
        lblPetId.setText("Pet ID");

        txtPetId.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtPetId.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtPetId.setBackground(new java.awt.Color(245, 245, 245));
        txtPetId.setEditable(false);

        lblName.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblName.setForeground(new java.awt.Color(38, 48, 80));
        lblName.setText("Name");

        txtName.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtName.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtName.setBackground(new java.awt.Color(245, 245, 245));
        txtName.setEditable(false);

        lblType.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblType.setForeground(new java.awt.Color(38, 48, 80));
        lblType.setText("Type");

        txtType.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtType.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtType.setBackground(new java.awt.Color(245, 245, 245));
        txtType.setEditable(false);

        lblBreed.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblBreed.setForeground(new java.awt.Color(38, 48, 80));
        lblBreed.setText("Breed");

        txtBreed.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtBreed.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtBreed.setBackground(new java.awt.Color(245, 245, 245));
        txtBreed.setEditable(false);

        lblAge.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblAge.setForeground(new java.awt.Color(38, 48, 80));
        lblAge.setText("Age");

        txtAge.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtAge.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtAge.setBackground(new java.awt.Color(245, 245, 245));
        txtAge.setEditable(false);

        lblGender.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblGender.setForeground(new java.awt.Color(38, 48, 80));
        lblGender.setText("Gender");

        txtGender.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtGender.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtGender.setBackground(new java.awt.Color(245, 245, 245));
        txtGender.setEditable(false);

        lblHealth.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblHealth.setForeground(new java.awt.Color(38, 48, 80));
        lblHealth.setText("Health");

        txtHealth.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtHealth.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtHealth.setBackground(new java.awt.Color(245, 245, 245));
        txtHealth.setEditable(false);

        lblVaccination.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblVaccination.setForeground(new java.awt.Color(38, 48, 80));
        lblVaccination.setText("Vaccination");

        txtVaccination.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtVaccination.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtVaccination.setBackground(new java.awt.Color(245, 245, 245));
        txtVaccination.setEditable(false);

        lblDewormed.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblDewormed.setForeground(new java.awt.Color(38, 48, 80));
        lblDewormed.setText("Dewormed");

        txtDewormed.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtDewormed.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtDewormed.setBackground(new java.awt.Color(245, 245, 245));
        txtDewormed.setEditable(false);

        lblDisability.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblDisability.setForeground(new java.awt.Color(38, 48, 80));
        lblDisability.setText("Disability");

        txtDisability.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtDisability.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtDisability.setBackground(new java.awt.Color(245, 245, 245));
        txtDisability.setEditable(false);

        lblPersonality.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblPersonality.setForeground(new java.awt.Color(38, 48, 80));
        lblPersonality.setText("Personality");

        txtPersonality.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtPersonality.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtPersonality.setBackground(new java.awt.Color(245, 245, 245));
        txtPersonality.setEditable(false);

        lblCare.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblCare.setForeground(new java.awt.Color(38, 48, 80));
        lblCare.setText("Special Care");

        txtCare.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtCare.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtCare.setBackground(new java.awt.Color(245, 245, 245));
        txtCare.setEditable(false);

        lblStatus.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblStatus.setForeground(new java.awt.Color(38, 48, 80));
        lblStatus.setText("Status");

        txtStatus.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtStatus.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtStatus.setBackground(new java.awt.Color(245, 245, 245));
        txtStatus.setEditable(false);

        pnlButtons.setOpaque(false);

        btnClose.setBackground(new java.awt.Color(38, 48, 80));
        btnClose.setForeground(new java.awt.Color(255, 255, 255));
        btnClose.setText("CLOSE");
        btnClose.addActionListener(this::btnCloseActionPerformed);

        javax.swing.GroupLayout pnlButtonsLayout = new javax.swing.GroupLayout(pnlButtons);
        pnlButtons.setLayout(pnlButtonsLayout);
        pnlButtonsLayout.setHorizontalGroup(
            pnlButtonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlButtonsLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(btnClose, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE))
        );
        pnlButtonsLayout.setVerticalGroup(
            pnlButtonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(btnClose, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pnlForm.setLayout(new java.awt.GridLayout(0, 2, 12, 12));
        pnlForm.add(lblPetId);
        pnlForm.add(txtPetId);
        pnlForm.add(lblName);
        pnlForm.add(txtName);
        pnlForm.add(lblType);
        pnlForm.add(txtType);
        pnlForm.add(lblBreed);
        pnlForm.add(txtBreed);
        pnlForm.add(lblAge);
        pnlForm.add(txtAge);
        pnlForm.add(lblGender);
        pnlForm.add(txtGender);
        pnlForm.add(lblHealth);
        pnlForm.add(txtHealth);
        pnlForm.add(lblVaccination);
        pnlForm.add(txtVaccination);
        pnlForm.add(lblDewormed);
        pnlForm.add(txtDewormed);
        pnlForm.add(lblDisability);
        pnlForm.add(txtDisability);
        pnlForm.add(lblPersonality);
        pnlForm.add(txtPersonality);
        pnlForm.add(lblCare);
        pnlForm.add(txtCare);
        pnlForm.add(lblStatus);
        pnlForm.add(txtStatus);

        scrollForm.setViewportView(pnlForm);

        javax.swing.GroupLayout mainPanelLayout = new javax.swing.GroupLayout(mainPanel);
        mainPanel.setLayout(mainPanelLayout);
        mainPanelLayout.setHorizontalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(mainPanelLayout.createSequentialGroup()
                    .addGap(18, 18, 18)
                    .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(lblTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(scrollForm, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(pnlButtons, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGap(18, 18, 18))
        );
        mainPanelLayout.setVerticalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(mainPanelLayout.createSequentialGroup()
                    .addGap(16, 16, 16)
                    .addComponent(lblTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(10, 10, 10)
                    .addComponent(scrollForm, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGap(10, 10, 10)
                    .addComponent(pnlButtons, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(16, 16, 16))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCloseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCloseActionPerformed
        dispose();
    }//GEN-LAST:event_btnCloseActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.mycompany.pawcare.helpers.RoundedButton btnClose;
    private javax.swing.JLabel lblAge;
    private javax.swing.JLabel lblBreed;
    private javax.swing.JLabel lblCare;
    private javax.swing.JLabel lblDewormed;
    private javax.swing.JLabel lblDisability;
    private javax.swing.JLabel lblGender;
    private javax.swing.JLabel lblHealth;
    private javax.swing.JLabel lblName;
    private javax.swing.JLabel lblPersonality;
    private javax.swing.JLabel lblPetId;
    private javax.swing.JLabel lblStatus;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JLabel lblType;
    private javax.swing.JLabel lblVaccination;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JPanel pnlButtons;
    private javax.swing.JPanel pnlForm;
    private javax.swing.JScrollPane scrollForm;
    private javax.swing.JTextField txtAge;
    private javax.swing.JTextField txtBreed;
    private javax.swing.JTextField txtCare;
    private javax.swing.JTextField txtDewormed;
    private javax.swing.JTextField txtDisability;
    private javax.swing.JTextField txtGender;
    private javax.swing.JTextField txtHealth;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextField txtPersonality;
    private javax.swing.JTextField txtPetId;
    private javax.swing.JTextField txtStatus;
    private javax.swing.JTextField txtType;
    private javax.swing.JTextField txtVaccination;
    // End of variables declaration//GEN-END:variables
}
