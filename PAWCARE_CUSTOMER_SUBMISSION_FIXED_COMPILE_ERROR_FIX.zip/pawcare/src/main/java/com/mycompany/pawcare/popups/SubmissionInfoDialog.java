/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package com.mycompany.pawcare.popups;

import com.mycompany.pawcare.screens.*;
import com.mycompany.pawcare.cards.*;
import com.mycompany.pawcare.helpers.*;

/**
 *
 * @author Student
 */
public class SubmissionInfoDialog extends javax.swing.JDialog {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(SubmissionInfoDialog.class.getName());

    public SubmissionInfoDialog(java.awt.Frame parent, boolean modal, PetSubmission s) {
        super(parent, modal);
        initComponents();
        getContentPane().setBackground(new java.awt.Color(255, 249, 241));
        setSize(740, 690);
        setMinimumSize(new java.awt.Dimension(650, 600));
        setLocationRelativeTo(parent);

        User submitter = Session.manager().findUser(s.getUserId());
        Pet p = Session.manager().findPet(s.getPetId());
        txtSubId.setText(s.getSubmissionId());
        txtOwnerId.setText(s.getUserId());
        txtOwner.setText(submitter == null ? "None" : val(submitter.getFullName()));
        txtContact.setText(submitter == null ? "None" : val(submitter.getContact()));
        txtAddress.setText(submitter == null ? "None" : val(submitter.getAddress()));
        txtPet.setText(p == null ? "None" : val(p.getName()));
        txtBreed.setText(p == null ? "None" : val(p.getBreed()));
        txtHealth.setText(p == null ? "None" : val(p.getHealth()));
        txtVaccination.setText(p == null ? "None" : val(p.getVaccination()));
        txtDewormed.setText(p == null ? "None" : val(p.getDewormed()));
        txtStatus.setText(val(s.getStatus()));

        // Keep the generated NetBeans fields, but arrange the runtime details as compact
        // sections and wrapped text so long health/contact information never scrolls sideways.
        pnlForm.removeAll();
        pnlForm.setBackground(new java.awt.Color(255, 249, 241));
        pnlForm.setBorder(javax.swing.BorderFactory.createEmptyBorder(6, 10, 6, 10));
        pnlForm.setLayout(new java.awt.GridBagLayout());
        scrollForm.setViewportView(pnlForm);
        scrollForm.setBorder(null);
        scrollForm.setHorizontalScrollBarPolicy(javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollForm.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollForm.getVerticalScrollBar().setUnitIncrement(18);
        scrollForm.getViewport().setBackground(new java.awt.Color(255, 249, 241));

        com.mycompany.pawcare.helpers.PetPhoto photo = new com.mycompany.pawcare.helpers.PetPhoto();
        photo.setBoxWidth(220);
        photo.setBoxHeight(115);
        photo.setImagePath(submissionPhotoPath(p));
        javax.swing.JPanel photoRow = new javax.swing.JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 2));
        photoRow.setOpaque(false);
        photoRow.add(photo);
        addFullRow(0, photoRow);
        if (isSamplePhoto(p)) {
            javax.swing.JLabel sampleNotice = new javax.swing.JLabel("Sample Photo — Actual Photo Not Provided");
            sampleNotice.setFont(new java.awt.Font("SansSerif", java.awt.Font.ITALIC, 12));
            sampleNotice.setForeground(new java.awt.Color(120, 105, 90));
            sampleNotice.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
            addFullRow(1, sampleNotice);
        }

        int row = isSamplePhoto(p) ? 2 : 1;
        addSectionRow(row++, "SUBMISSION DETAILS");
        addInfoRow(row++, new javax.swing.JLabel("Submission ID"), txtSubId);
        addInfoRow(row++, lblStatus, txtStatus);
        addValueRow(row++, "Submission Date", s.getDate());
        addTextAreaRow(row++, "Submission Audit Timeline", Session.manager().getAuditTimeline("SUBMISSION", s.getSubmissionId()));
        addTextAreaRow(row++, "Account Audit Timeline", Session.manager().getAuditTimeline("USER", s.getUserId()));

        addSectionRow(row++, "SUBMITTER INFORMATION");
        addInfoRow(row++, lblOwnerId, txtOwnerId);
        addInfoRow(row++, lblOwner, txtOwner);
        addInfoRow(row++, lblContact, txtContact);
        addValueRow(row++, "Email", submitter == null ? "None" : submitter.getEmail());
        addValueRow(row++, "Age", submitter == null ? "None" : submitter.getAge());
        addTextAreaRow(row++, "Address", submitter == null ? "None" : submitter.getAddress());

        addSectionRow(row++, "PET INFORMATION");
        addValueRow(row++, "Pet ID", s.getPetId());
        addInfoRow(row++, lblPet, txtPet);
        addValueRow(row++, "Type", p == null ? "None" : p.getType());
        addInfoRow(row++, lblBreed, txtBreed);
        addValueRow(row++, "Age", p == null ? "None" : p.getAge());
        addValueRow(row++, "Gender", p == null ? "None" : p.getGender());
        addValueRow(row++, "Personality", p == null ? "None" : p.getPersonality());
        addValueRow(row++, "Good with Kids", p == null ? "None" : p.getGoodWithKids());

        addSectionRow(row++, "HEALTH & CARE DETAILS");
        addInfoRow(row++, lblHealth, txtHealth);
        addInfoRow(row++, lblVaccination, txtVaccination);
        addInfoRow(row++, lblDewormed, txtDewormed);
        addValueRow(row++, "Disability", p == null ? "None" : p.getDisability());
        addValueRow(row++, "Spayed / Neutered", p == null ? "None" : p.getSpayedNeutered());
        addTextAreaRow(row++, "Special Care", p == null ? "None" : p.getSpecialCare());
        addTextAreaRow(row++, "Medical History", p == null ? "None" : p.getMedicalHistory());

        pnlForm.revalidate();
        pnlForm.repaint();

        if (parent instanceof com.mycompany.pawcare.screens.PetSubmissionsForm) {
            com.mycompany.pawcare.helpers.RoundedButton approve = new com.mycompany.pawcare.helpers.RoundedButton();
            approve.setText("APPROVE"); approve.setBackground(Session.GREEN); approve.setForeground(java.awt.Color.WHITE);
            approve.addActionListener(e -> { if (Ui.confirm(this, "Approve this pet submission?")) { Session.manager().approveSubmission(s); ((com.mycompany.pawcare.screens.PetSubmissionsForm) parent).refreshCards(); dispose(); } });
            com.mycompany.pawcare.helpers.RoundedButton decline = new com.mycompany.pawcare.helpers.RoundedButton();
            decline.setText("DECLINE"); decline.setBackground(Session.RED); decline.setForeground(java.awt.Color.WHITE);
            decline.addActionListener(e -> { if (Ui.confirm(this, "Decline this pet submission?")) { Session.manager().declineSubmission(s); ((com.mycompany.pawcare.screens.PetSubmissionsForm) parent).refreshCards(); dispose(); } });
            pnlButtons.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 8, 4));
            pnlButtons.removeAll(); pnlButtons.add(approve); pnlButtons.add(decline); pnlButtons.add(btnClose);
        }
        setSize(740, 690);
        setLocationRelativeTo(parent);
    }

    private void addFullRow(int row, java.awt.Component component) {
        java.awt.GridBagConstraints c = new java.awt.GridBagConstraints();
        c.gridx = 0; c.gridy = row; c.gridwidth = 2;
        c.fill = java.awt.GridBagConstraints.HORIZONTAL; c.weightx = 1.0;
        c.insets = new java.awt.Insets(2, 4, 5, 4);
        pnlForm.add(component, c);
    }

    private void addSectionRow(int row, String title) {
        javax.swing.JLabel section = new javax.swing.JLabel(title);
        section.setFont(new java.awt.Font("SansSerif", java.awt.Font.BOLD, 13));
        section.setForeground(Session.GREEN);
        java.awt.GridBagConstraints c = new java.awt.GridBagConstraints();
        c.gridx = 0; c.gridy = row; c.gridwidth = 2;
        c.insets = new java.awt.Insets(7, 4, 1, 4);
        c.fill = java.awt.GridBagConstraints.HORIZONTAL; c.weightx = 1.0;
        pnlForm.add(section, c);
    }

    private void addInfoRow(int row, javax.swing.JLabel label, javax.swing.JTextField field) {
        styleLabel(label);
        styleValueField(field);
        addRowComponents(row, label, field);
    }

    private void addValueRow(int row, String labelText, String value) {
        javax.swing.JLabel label = new javax.swing.JLabel(labelText);
        javax.swing.JTextField field = new javax.swing.JTextField(val(value));
        styleLabel(label); styleValueField(field);
        addRowComponents(row, label, field);
    }

    private void addTextAreaRow(int row, String labelText, String value) {
        javax.swing.JLabel label = new javax.swing.JLabel(labelText);
        styleLabel(label);
        javax.swing.JTextArea area = new javax.swing.JTextArea(val(value), 2, 26);
        area.setFont(new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 14));
        area.setEditable(false); area.setLineWrap(true); area.setWrapStyleWord(true);
        area.setBackground(new java.awt.Color(245, 245, 245));
        area.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 8, 5, 8));
        javax.swing.JScrollPane areaScroll = new javax.swing.JScrollPane(area);
        areaScroll.setPreferredSize(new java.awt.Dimension(390, 55));
        areaScroll.setHorizontalScrollBarPolicy(javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        areaScroll.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        addRowComponents(row, label, areaScroll);
    }

    private void addRowComponents(int row, javax.swing.JLabel label, java.awt.Component value) {
        java.awt.GridBagConstraints left = new java.awt.GridBagConstraints();
        left.gridx = 0; left.gridy = row; left.insets = new java.awt.Insets(2, 4, 2, 12);
        left.anchor = java.awt.GridBagConstraints.WEST;
        pnlForm.add(label, left);
        java.awt.GridBagConstraints right = new java.awt.GridBagConstraints();
        right.gridx = 1; right.gridy = row; right.insets = new java.awt.Insets(2, 4, 2, 4);
        right.fill = java.awt.GridBagConstraints.HORIZONTAL; right.weightx = 1.0;
        right.anchor = java.awt.GridBagConstraints.WEST;
        pnlForm.add(value, right);
    }

    private static void styleLabel(javax.swing.JLabel label) {
        label.setFont(new java.awt.Font("SansSerif", java.awt.Font.BOLD, 14));
        label.setForeground(new java.awt.Color(38, 48, 80));
        label.setPreferredSize(new java.awt.Dimension(155, 26));
    }

    private static void styleValueField(javax.swing.JTextField field) {
        field.setFont(new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 14));
        field.setEditable(false); field.setBackground(new java.awt.Color(245, 245, 245));
        field.setToolTipText(field.getText()); field.setPreferredSize(new java.awt.Dimension(390, 29));
    }

    private static boolean isSamplePhoto(Pet pet) {
        if (pet == null || pet.getImageResource() == null) return true;
        String path = pet.getImageResource().toLowerCase(java.util.Locale.ROOT);
        return path.endsWith("/buddy.jfif") || path.endsWith("/bantay.jfif") || path.endsWith("/lucky.jfif")
                || path.endsWith("/oreo.jfif") || path.endsWith("/ming.jfif") || path.endsWith("/ash.jfif")
                || path.endsWith("pet_submission_dog_placeholder.png") || path.endsWith("pet_submission_cat_placeholder.png");
    }

    public static String submissionPhotoPath(Pet pet) {
        String path = pet == null ? null : pet.getImageResource();
        if (path != null && !path.isBlank()) {
            if (path.startsWith("/com/mycompany/pawcare/images/") && com.mycompany.pawcare.helpers.PetPhoto.class.getResource(path) != null) return path;
            if (new java.io.File(path).isFile()) return path;
        }
        if (pet != null && "Cat".equalsIgnoreCase(pet.getType())) {
            return "/com/mycompany/pawcare/images/pet_submission_cat_placeholder.png";
        }
        return "/com/mycompany/pawcare/images/pet_submission_dog_placeholder.png";
    }

    private static String val(String value) { return value == null || value.isBlank() ? "None" : value; }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainPanel = new javax.swing.JPanel();
        lblTitle = new javax.swing.JLabel();
        scrollForm = new javax.swing.JScrollPane();
        pnlForm = new javax.swing.JPanel();
        lblSubId = new javax.swing.JLabel();
        txtSubId = new javax.swing.JTextField();
        lblOwnerId = new javax.swing.JLabel();
        txtOwnerId = new javax.swing.JTextField();
        lblOwner = new javax.swing.JLabel();
        txtOwner = new javax.swing.JTextField();
        lblContact = new javax.swing.JLabel();
        txtContact = new javax.swing.JTextField();
        lblAddress = new javax.swing.JLabel();
        txtAddress = new javax.swing.JTextField();
        lblPet = new javax.swing.JLabel();
        txtPet = new javax.swing.JTextField();
        lblBreed = new javax.swing.JLabel();
        txtBreed = new javax.swing.JTextField();
        lblHealth = new javax.swing.JLabel();
        txtHealth = new javax.swing.JTextField();
        lblVaccination = new javax.swing.JLabel();
        txtVaccination = new javax.swing.JTextField();
        lblDewormed = new javax.swing.JLabel();
        txtDewormed = new javax.swing.JTextField();
        lblStatus = new javax.swing.JLabel();
        txtStatus = new javax.swing.JTextField();
        pnlButtons = new javax.swing.JPanel();
        btnClose = new com.mycompany.pawcare.helpers.RoundedButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("PET SUBMISSION INFORMATION");

        mainPanel.setBackground(new java.awt.Color(255, 249, 241));
        mainPanel.setPreferredSize(new java.awt.Dimension(600, 560));

        lblTitle.setFont(new java.awt.Font("SansSerif", 1, 25)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(52, 171, 83));
        lblTitle.setText("PET SUBMISSION INFORMATION");

        pnlForm.setBackground(new java.awt.Color(255, 249, 241));
        pnlForm.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));

        lblSubId.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblSubId.setForeground(new java.awt.Color(38, 48, 80));
        lblSubId.setText("Submission ID");

        txtSubId.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtSubId.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtSubId.setBackground(new java.awt.Color(245, 245, 245));
        txtSubId.setEditable(false);

        lblOwnerId.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblOwnerId.setForeground(new java.awt.Color(38, 48, 80));
        lblOwnerId.setText("User ID");

        txtOwnerId.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtOwnerId.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtOwnerId.setBackground(new java.awt.Color(245, 245, 245));
        txtOwnerId.setEditable(false);

        lblOwner.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblOwner.setForeground(new java.awt.Color(38, 48, 80));
        lblOwner.setText("User");

        txtOwner.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtOwner.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtOwner.setBackground(new java.awt.Color(245, 245, 245));
        txtOwner.setEditable(false);

        lblContact.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblContact.setForeground(new java.awt.Color(38, 48, 80));
        lblContact.setText("Contact");

        txtContact.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtContact.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtContact.setBackground(new java.awt.Color(245, 245, 245));
        txtContact.setEditable(false);

        lblAddress.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblAddress.setForeground(new java.awt.Color(38, 48, 80));
        lblAddress.setText("Address");

        txtAddress.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtAddress.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtAddress.setBackground(new java.awt.Color(245, 245, 245));
        txtAddress.setEditable(false);

        lblPet.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblPet.setForeground(new java.awt.Color(38, 48, 80));
        lblPet.setText("Pet");

        txtPet.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtPet.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtPet.setBackground(new java.awt.Color(245, 245, 245));
        txtPet.setEditable(false);

        lblBreed.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblBreed.setForeground(new java.awt.Color(38, 48, 80));
        lblBreed.setText("Breed");

        txtBreed.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtBreed.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtBreed.setBackground(new java.awt.Color(245, 245, 245));
        txtBreed.setEditable(false);

        lblHealth.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblHealth.setForeground(new java.awt.Color(38, 48, 80));
        lblHealth.setText("Health");

        txtHealth.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtHealth.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtHealth.setBackground(new java.awt.Color(245, 245, 245));
        txtHealth.setEditable(false);

        lblVaccination.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblVaccination.setForeground(new java.awt.Color(38, 48, 80));
        lblVaccination.setText("Vaccination");

        txtVaccination.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtVaccination.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtVaccination.setBackground(new java.awt.Color(245, 245, 245));
        txtVaccination.setEditable(false);

        lblDewormed.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblDewormed.setForeground(new java.awt.Color(38, 48, 80));
        lblDewormed.setText("Dewormed");

        txtDewormed.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtDewormed.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtDewormed.setBackground(new java.awt.Color(245, 245, 245));
        txtDewormed.setEditable(false);

        lblStatus.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblStatus.setForeground(new java.awt.Color(38, 48, 80));
        lblStatus.setText("Status");

        txtStatus.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtStatus.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtStatus.setBackground(new java.awt.Color(245, 245, 245));
        txtStatus.setEditable(false);

        pnlButtons.setOpaque(false);

        btnClose.setBackground(new java.awt.Color(38, 48, 80));
        btnClose.setForeground(new java.awt.Color(255, 255, 255));
        btnClose.setText("CLOSE");
        btnClose.addActionListener(this::btnCloseActionPerformed);

        javax.swing.GroupLayout pnlButtonsLayout = new javax.swing.GroupLayout(pnlButtons);
        pnlButtons.setLayout(pnlButtonsLayout);
        pnlButtonsLayout.setHorizontalGroup(
            pnlButtonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlButtonsLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(btnClose, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE))
        );
        pnlButtonsLayout.setVerticalGroup(
            pnlButtonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(btnClose, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pnlForm.setLayout(new java.awt.GridLayout(0, 2, 12, 12));
        pnlForm.add(lblSubId);
        pnlForm.add(txtSubId);
        pnlForm.add(lblOwnerId);
        pnlForm.add(txtOwnerId);
        pnlForm.add(lblOwner);
        pnlForm.add(txtOwner);
        pnlForm.add(lblContact);
        pnlForm.add(txtContact);
        pnlForm.add(lblAddress);
        pnlForm.add(txtAddress);
        pnlForm.add(lblPet);
        pnlForm.add(txtPet);
        pnlForm.add(lblBreed);
        pnlForm.add(txtBreed);
        pnlForm.add(lblHealth);
        pnlForm.add(txtHealth);
        pnlForm.add(lblVaccination);
        pnlForm.add(txtVaccination);
        pnlForm.add(lblDewormed);
        pnlForm.add(txtDewormed);
        pnlForm.add(lblStatus);
        pnlForm.add(txtStatus);

        scrollForm.setViewportView(pnlForm);

        javax.swing.GroupLayout mainPanelLayout = new javax.swing.GroupLayout(mainPanel);
        mainPanel.setLayout(mainPanelLayout);
        mainPanelLayout.setHorizontalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(mainPanelLayout.createSequentialGroup()
                    .addGap(18, 18, 18)
                    .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(lblTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(scrollForm, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(pnlButtons, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGap(18, 18, 18))
        );
        mainPanelLayout.setVerticalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(mainPanelLayout.createSequentialGroup()
                    .addGap(16, 16, 16)
                    .addComponent(lblTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(10, 10, 10)
                    .addComponent(scrollForm, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGap(10, 10, 10)
                    .addComponent(pnlButtons, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(16, 16, 16))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCloseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCloseActionPerformed
        dispose();
    }//GEN-LAST:event_btnCloseActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.mycompany.pawcare.helpers.RoundedButton btnClose;
    private javax.swing.JLabel lblAddress;
    private javax.swing.JLabel lblBreed;
    private javax.swing.JLabel lblContact;
    private javax.swing.JLabel lblDewormed;
    private javax.swing.JLabel lblHealth;
    private javax.swing.JLabel lblOwner;
    private javax.swing.JLabel lblOwnerId;
    private javax.swing.JLabel lblPet;
    private javax.swing.JLabel lblStatus;
    private javax.swing.JLabel lblSubId;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JLabel lblVaccination;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JPanel pnlButtons;
    private javax.swing.JPanel pnlForm;
    private javax.swing.JScrollPane scrollForm;
    private javax.swing.JTextField txtAddress;
    private javax.swing.JTextField txtBreed;
    private javax.swing.JTextField txtContact;
    private javax.swing.JTextField txtDewormed;
    private javax.swing.JTextField txtHealth;
    private javax.swing.JTextField txtOwner;
    private javax.swing.JTextField txtOwnerId;
    private javax.swing.JTextField txtPet;
    private javax.swing.JTextField txtStatus;
    private javax.swing.JTextField txtSubId;
    private javax.swing.JTextField txtVaccination;
    // End of variables declaration//GEN-END:variables
}
