/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.pawcare.screens;

import com.mycompany.pawcare.popups.*;
import com.mycompany.pawcare.cards.*;
import com.mycompany.pawcare.helpers.*;

/**
 *
 * @author Student
 */
public class MyAdoptionsForm extends javax.swing.JFrame {

    private final javax.swing.JTextField txtSearchAdoptions = new javax.swing.JTextField(18);
    private final javax.swing.JComboBox<String> cmbSearchAdoptions = new javax.swing.JComboBox<>(new String[]{"All Pets", "Dog", "Cat", "Breed"});

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(MyAdoptionsForm.class.getName());

    public MyAdoptionsForm() {
        initComponents();
        getContentPane().setBackground(new java.awt.Color(255, 249, 241));
        setSize(1240, 800);
        setMinimumSize(new java.awt.Dimension(1050, 700));
        setLocationRelativeTo(null);
        scrollCards.getViewport().setBackground(Session.CREAM);
        setupAdoptionSearch();
        if (Session.currentUser != null) {
            refresh();
        }
    }

    private void setupAdoptionSearch() {
        // Match the search styling used by the Paw Care Gallery.
        txtSearchAdoptions.setFont(new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 17));
        txtSearchAdoptions.setToolTipText("Search by pet name, breed, type or ID");
        txtSearchAdoptions.setBorder(null);
        txtSearchAdoptions.setPreferredSize(new java.awt.Dimension(300, 40));
        txtSearchAdoptions.setMinimumSize(new java.awt.Dimension(180, 40));

        cmbSearchAdoptions.setFont(new java.awt.Font("SansSerif", java.awt.Font.BOLD, 14));
        cmbSearchAdoptions.setPreferredSize(new java.awt.Dimension(125, 38));
        javax.swing.JLabel searchIcon = new javax.swing.JLabel("⌕");
        searchIcon.setFont(new java.awt.Font("SansSerif", java.awt.Font.BOLD, 28));
        searchIcon.setForeground(new java.awt.Color(126, 79, 195));

        javax.swing.JPanel searchBox = new javax.swing.JPanel(new java.awt.BorderLayout(7, 0));
        searchBox.setBackground(java.awt.Color.WHITE);
        searchBox.setBorder(javax.swing.BorderFactory.createCompoundBorder(
                javax.swing.BorderFactory.createLineBorder(new java.awt.Color(220, 210, 230), 2, true),
                javax.swing.BorderFactory.createEmptyBorder(0, 8, 0, 8)));
        searchBox.add(searchIcon, java.awt.BorderLayout.WEST);
        searchBox.add(txtSearchAdoptions, java.awt.BorderLayout.CENTER);
        searchBox.setPreferredSize(new java.awt.Dimension(370, 48));

        javax.swing.JPanel searchRow = new javax.swing.JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 10, 0));
        searchRow.setOpaque(false);
        searchRow.add(searchBox);
        searchRow.add(cmbSearchAdoptions);

        javax.swing.JPanel heading = new javax.swing.JPanel(new java.awt.BorderLayout(12, 6));
        heading.setOpaque(false);
        javax.swing.JPanel titlePanel = new javax.swing.JPanel();
        titlePanel.setOpaque(false);
        titlePanel.setLayout(new javax.swing.BoxLayout(titlePanel, javax.swing.BoxLayout.Y_AXIS));
        titlePanel.add(lblHeader);
        titlePanel.add(lblSub);
        heading.add(titlePanel, java.awt.BorderLayout.CENTER);
        heading.add(searchRow, java.awt.BorderLayout.EAST);

        pnlPage.removeAll();
        pnlPage.setLayout(new java.awt.BorderLayout(12, 12));
        heading.setBorder(javax.swing.BorderFactory.createEmptyBorder(20, 28, 4, 28));
        pnlPage.add(heading, java.awt.BorderLayout.NORTH);
        pnlPage.add(scrollCards, java.awt.BorderLayout.CENTER);

        scrollCards.setBorder(null);
        scrollCards.setHorizontalScrollBarPolicy(javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollCards.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollCards.getVerticalScrollBar().setUnitIncrement(20);
        scrollCards.getViewport().setBackground(Session.CREAM);

        txtSearchAdoptions.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) { refresh(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { refresh(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { refresh(); }
        });
        cmbSearchAdoptions.addActionListener(e -> refresh());
        pnlPage.revalidate();
        pnlPage.repaint();
    }

    private void refresh() {
        pnlCards.removeAll();
        pnlCards.setLayout(new java.awt.GridLayout(0, 2, 18, 18));
        if (Session.currentUser == null) {
            pnlCards.revalidate();
            pnlCards.repaint();
            return;
        }

        int count = 0;
        String term = txtSearchAdoptions.getText().trim().toLowerCase(java.util.Locale.ROOT);
        String filter = String.valueOf(cmbSearchAdoptions.getSelectedItem());
        for (Adoption a : Session.manager().getAdoptions()) {
            if (!a.getUserId().equals(Session.currentUser.getUserId())) continue;
            // Canceled records remain in the system/admin history, but must not
            // create stale cards in the customer's active My Adoptions page.
            if ("Cancelled".equalsIgnoreCase(a.getStatus())) continue;

            Pet pet = Session.manager().findPet(a.getPetId());
            if (pet == null) continue;
            String searchable = (safe(pet.getPetId()) + " " + safe(pet.getName()) + " "
                    + safe(pet.getBreed()) + " " + safe(pet.getType())).toLowerCase(java.util.Locale.ROOT);
            boolean categoryMatches = true;
            if ("Dog".equalsIgnoreCase(filter)) categoryMatches = "Dog".equalsIgnoreCase(pet.getType());
            else if ("Cat".equalsIgnoreCase(filter)) categoryMatches = "Cat".equalsIgnoreCase(pet.getType());
            else if ("Breed".equalsIgnoreCase(filter)) searchable = safe(pet.getBreed()).toLowerCase(java.util.Locale.ROOT);

            if (categoryMatches && (term.isEmpty() || searchable.contains(term))) {
                AdoptionCardPanel card = AdoptionCardPanel.of(a, false, this);
                javax.swing.JScrollPane cardScroll = new javax.swing.JScrollPane(card);
                cardScroll.setPreferredSize(new java.awt.Dimension(440, 470));
                cardScroll.setMinimumSize(new java.awt.Dimension(300, 470));
                cardScroll.setHorizontalScrollBarPolicy(javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
                cardScroll.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
                cardScroll.getVerticalScrollBar().setUnitIncrement(18);
                cardScroll.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(225, 215, 235), 1, true));
                cardScroll.getViewport().setBackground(java.awt.Color.WHITE);
                pnlCards.add(cardScroll);
                count++;
            }
        }
        if (count == 0) {
            javax.swing.JLabel none = new javax.swing.JLabel("No active adoption records match your search.");
            none.setFont(new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 16));
            none.setForeground(Session.GRAY);
            none.setBorder(javax.swing.BorderFactory.createEmptyBorder(15, 10, 15, 10));
            pnlCards.add(none);
        }
        pnlCards.revalidate();
        pnlCards.repaint();
        scrollCards.revalidate();
        scrollCards.repaint();
    }

    private static String safe(String value) {
        return value == null ? "" : value;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainPanel = new javax.swing.JPanel();
        pnlSide = new javax.swing.JPanel();
        lblBrand = new javax.swing.JLabel();
        lblRole = new javax.swing.JLabel();
        btnSideHome = new com.mycompany.pawcare.helpers.RoundedButton();
        btnSideGallery = new com.mycompany.pawcare.helpers.RoundedButton();
        btnSideAdoptions = new com.mycompany.pawcare.helpers.RoundedButton();
        btnSidePut = new com.mycompany.pawcare.helpers.RoundedButton();
        btnSideProfile = new com.mycompany.pawcare.helpers.RoundedButton();
        btnSideLogout = new com.mycompany.pawcare.helpers.RoundedButton();
        pnlPage = new javax.swing.JPanel();
        lblHeader = new javax.swing.JLabel();
        lblSub = new javax.swing.JLabel();
        scrollCards = new javax.swing.JScrollPane();
        pnlCards = new com.mycompany.pawcare.helpers.CardGrid();
        card1 = new com.mycompany.pawcare.cards.AdoptionCardPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("PAWCARE - Pet Adoption Management System");

        mainPanel.setBackground(new java.awt.Color(255, 249, 241));
        mainPanel.setPreferredSize(new java.awt.Dimension(1240, 800));

        pnlSide.setBackground(new java.awt.Color(38, 48, 80));
        pnlSide.setPreferredSize(new java.awt.Dimension(225, 700));

        lblBrand.setFont(new java.awt.Font("SansSerif", 1, 27)); // NOI18N
        lblBrand.setForeground(new java.awt.Color(255, 255, 255));
        lblBrand.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblBrand.setText("PAWCARE");

        lblRole.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        lblRole.setForeground(new java.awt.Color(215, 215, 230));
        lblRole.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblRole.setText("CUSTOMER");

        btnSideHome.setBackground(new java.awt.Color(43, 126, 224));
        btnSideHome.setForeground(new java.awt.Color(255, 255, 255));
        btnSideHome.setText("HOME");
        btnSideHome.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnSideHome.addActionListener(this::btnSideHomeActionPerformed);

        btnSideGallery.setBackground(new java.awt.Color(126, 79, 195));
        btnSideGallery.setForeground(new java.awt.Color(255, 255, 255));
        btnSideGallery.setText("PAW CARE GALLERY");
        btnSideGallery.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnSideGallery.addActionListener(this::btnSideGalleryActionPerformed);

        btnSideAdoptions.setBackground(new java.awt.Color(231, 65, 108));
        btnSideAdoptions.setForeground(new java.awt.Color(255, 255, 255));
        btnSideAdoptions.setText("MY ADOPTIONS");
        btnSideAdoptions.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnSideAdoptions.addActionListener(this::btnSideAdoptionsActionPerformed);

        btnSidePut.setBackground(new java.awt.Color(52, 171, 83));
        btnSidePut.setForeground(new java.awt.Color(255, 255, 255));
        btnSidePut.setText("PUT FOR ADOPTION");
        btnSidePut.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnSidePut.addActionListener(this::btnSidePutActionPerformed);

        btnSideProfile.setBackground(new java.awt.Color(235, 154, 32));
        btnSideProfile.setForeground(new java.awt.Color(255, 255, 255));
        btnSideProfile.setText("MY PROFILE");
        btnSideProfile.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnSideProfile.addActionListener(this::btnSideProfileActionPerformed);

        btnSideLogout.setBackground(new java.awt.Color(214, 65, 55));
        btnSideLogout.setForeground(new java.awt.Color(255, 255, 255));
        btnSideLogout.setText("LOG OUT");
        btnSideLogout.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnSideLogout.addActionListener(this::btnSideLogoutActionPerformed);

        pnlPage.setBackground(new java.awt.Color(255, 249, 241));

        lblHeader.setFont(new java.awt.Font("SansSerif", 1, 30)); // NOI18N
        lblHeader.setForeground(new java.awt.Color(231, 65, 108));
        lblHeader.setText("My Adoptions");

        lblSub.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        lblSub.setForeground(new java.awt.Color(38, 48, 80));
        lblSub.setText("Your adopted pets and adoption history are shown as profiles.");

        pnlCards.setBackground(new java.awt.Color(255, 249, 241));

        pnlCards.setLayout(new java.awt.GridLayout(0, 2, 18, 18));
        pnlCards.add(card1);

        scrollCards.setViewportView(pnlCards);

        javax.swing.GroupLayout pnlPageLayout = new javax.swing.GroupLayout(pnlPage);
        pnlPage.setLayout(pnlPageLayout);
        pnlPageLayout.setHorizontalGroup(
            pnlPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlPageLayout.createSequentialGroup()
                    .addGap(28, 28, 28)
                    .addGroup(pnlPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(lblHeader, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblSub, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(scrollCards, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGap(28, 28, 28))
        );
        pnlPageLayout.setVerticalGroup(
            pnlPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlPageLayout.createSequentialGroup()
                    .addGap(25, 25, 25)
                    .addComponent(lblHeader, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(4, 4, 4)
                    .addComponent(lblSub, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(12, 12, 12)
                    .addComponent(scrollCards, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGap(28, 28, 28))
        );

        javax.swing.GroupLayout pnlSideLayout = new javax.swing.GroupLayout(pnlSide);
        pnlSide.setLayout(pnlSideLayout);
        pnlSideLayout.setHorizontalGroup(
            pnlSideLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlSideLayout.createSequentialGroup()
                    .addGap(10, 10, 10)
                    .addGroup(pnlSideLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(lblBrand, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(pnlSideLayout.createSequentialGroup()
                            .addGap(0, 0, Short.MAX_VALUE)
                            .addComponent(lblRole, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(btnSideHome, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnSideGallery, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnSideAdoptions, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnSidePut, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnSideProfile, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnSideLogout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGap(10, 10, 10))
        );
        pnlSideLayout.setVerticalGroup(
            pnlSideLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlSideLayout.createSequentialGroup()
                    .addGap(18, 18, 18)
                    .addComponent(lblBrand, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblRole, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(25, 25, 25)
                    .addComponent(btnSideHome, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
                    .addGap(8, 8, 8)
                    .addComponent(btnSideGallery, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
                    .addGap(8, 8, 8)
                    .addComponent(btnSideAdoptions, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
                    .addGap(8, 8, 8)
                    .addComponent(btnSidePut, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
                    .addGap(8, 8, 8)
                    .addComponent(btnSideProfile, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
                    .addGap(8, 8, 8)
                    .addComponent(btnSideLogout, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
                    .addGap(18, 18, 18))
        );

        javax.swing.GroupLayout mainPanelLayout = new javax.swing.GroupLayout(mainPanel);
        mainPanel.setLayout(mainPanelLayout);
        mainPanelLayout.setHorizontalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(mainPanelLayout.createSequentialGroup()
                    .addComponent(pnlSide, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pnlPage, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        mainPanelLayout.setVerticalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(pnlSide, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(pnlPage, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSideHomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSideHomeActionPerformed
        Nav.show(this, new CustomerDashboardForm());
    }//GEN-LAST:event_btnSideHomeActionPerformed

    private void btnSideGalleryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSideGalleryActionPerformed
        Nav.show(this, new CustomerGalleryForm());
    }//GEN-LAST:event_btnSideGalleryActionPerformed

    private void btnSideAdoptionsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSideAdoptionsActionPerformed
        Nav.show(this, new MyAdoptionsForm());
    }//GEN-LAST:event_btnSideAdoptionsActionPerformed

    private void btnSidePutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSidePutActionPerformed
        Nav.show(this, new PutForAdoptionForm());
    }//GEN-LAST:event_btnSidePutActionPerformed

    private void btnSideProfileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSideProfileActionPerformed
        Nav.show(this, new ProfileForm());
    }//GEN-LAST:event_btnSideProfileActionPerformed

    private void btnSideLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSideLogoutActionPerformed
        Session.logout();
        Nav.home(this);
    }//GEN-LAST:event_btnSideLogoutActionPerformed
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.mycompany.pawcare.helpers.RoundedButton btnSideAdoptions;
    private com.mycompany.pawcare.helpers.RoundedButton btnSideGallery;
    private com.mycompany.pawcare.helpers.RoundedButton btnSideHome;
    private com.mycompany.pawcare.helpers.RoundedButton btnSideLogout;
    private com.mycompany.pawcare.helpers.RoundedButton btnSideProfile;
    private com.mycompany.pawcare.helpers.RoundedButton btnSidePut;
    private com.mycompany.pawcare.cards.AdoptionCardPanel card1;
    private javax.swing.JLabel lblBrand;
    private javax.swing.JLabel lblHeader;
    private javax.swing.JLabel lblRole;
    private javax.swing.JLabel lblSub;
    private javax.swing.JPanel mainPanel;
    private com.mycompany.pawcare.helpers.CardGrid pnlCards;
    private javax.swing.JPanel pnlPage;
    private javax.swing.JPanel pnlSide;
    private javax.swing.JScrollPane scrollCards;
    // End of variables declaration//GEN-END:variables
}
