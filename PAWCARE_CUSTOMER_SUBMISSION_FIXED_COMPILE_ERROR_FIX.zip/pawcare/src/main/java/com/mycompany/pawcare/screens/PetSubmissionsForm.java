/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.pawcare.screens;

import com.mycompany.pawcare.popups.*;
import com.mycompany.pawcare.cards.*;
import com.mycompany.pawcare.helpers.*;

/**
 *
 * @author Student
 */
public class PetSubmissionsForm extends javax.swing.JFrame {
    private final com.mycompany.pawcare.helpers.CardGrid submissionCards = new com.mycompany.pawcare.helpers.CardGrid();

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(PetSubmissionsForm.class.getName());

    public PetSubmissionsForm() {
        initComponents();
        getContentPane().setBackground(new java.awt.Color(255, 249, 241));
        setSize(1240, 800);
        setMinimumSize(new java.awt.Dimension(1050, 700));
        setLocationRelativeTo(null);
        submissionCards.setBackground(Session.CREAM);
        submissionCards.setLayout(new java.awt.GridLayout(0, 2, 18, 18));
        scrollTable.setViewportView(submissionCards);
        scrollTable.setHorizontalScrollBarPolicy(javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollTable.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollTable.getVerticalScrollBar().setUnitIncrement(18);
        scrollTable.getViewport().setBackground(Session.CREAM);
        pnlButtons.setVisible(false);
        refresh();
    }

    private PetSubmission selected() {
        String id = tblSubs.selectedId();
        if (id == null) {
            return null;
        }
        for (PetSubmission s : Session.manager().getSubmissions()) {
            if (s.getSubmissionId().equalsIgnoreCase(id)) {
                return s;
            }
        }
        return null;
    }

    private void refresh() {
        PetManager m = Session.manager();
        submissionCards.removeAll();
        int count = 0;
        for (PetSubmission submission : m.getSubmissions()) {
            if ("Archived".equalsIgnoreCase(submission.getStatus())) continue;
            Pet pet = m.findPet(submission.getPetId());
            User submitter = m.findUser(submission.getUserId());

            javax.swing.JPanel card = new javax.swing.JPanel(new java.awt.BorderLayout(6, 6));
            card.setBackground(java.awt.Color.WHITE);
            card.setBorder(javax.swing.BorderFactory.createCompoundBorder(
                    javax.swing.BorderFactory.createLineBorder("Pending".equalsIgnoreCase(submission.getStatus()) ? Session.ORANGE : Session.GREEN, 2, true),
                    javax.swing.BorderFactory.createEmptyBorder(12, 12, 12, 12)));

            com.mycompany.pawcare.helpers.PetPhoto photo = new com.mycompany.pawcare.helpers.PetPhoto();
            photo.setBoxWidth(250);
            photo.setBoxHeight(145);
            photo.setImagePath(SubmissionInfoDialog.submissionPhotoPath(pet));
            photo.setToolTipText(isSamplePhoto(pet)
                    ? "Sample Photo — Actual Photo Not Provided"
                    : "Submitted pet photo");

            javax.swing.JLabel title = new javax.swing.JLabel(pet == null ? "Pet details unavailable" : safe(pet.getName()));
            title.setFont(new java.awt.Font("SansSerif", java.awt.Font.BOLD, 20));
            title.setForeground(Session.NAVY);
            title.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
            title.setAlignmentX(java.awt.Component.CENTER_ALIGNMENT);

            String type = pet == null ? "Pet type unavailable" : safe(pet.getType());
            String breed = pet == null ? "Breed unavailable" : safe(pet.getBreed());
            javax.swing.JLabel typeBreed = new javax.swing.JLabel(type + "  •  " + breed);
            typeBreed.setFont(new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 14));
            typeBreed.setForeground(Session.GRAY);
            typeBreed.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
            typeBreed.setAlignmentX(java.awt.Component.CENTER_ALIGNMENT);

            javax.swing.JLabel submittedBy = new javax.swing.JLabel("Submitted by: " + (submitter == null ? "Unknown user" : safe(submitter.getFullName())));
            submittedBy.setFont(new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 14));
            submittedBy.setForeground(Session.NAVY);
            submittedBy.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
            submittedBy.setAlignmentX(java.awt.Component.CENTER_ALIGNMENT);

            javax.swing.JPanel text = new javax.swing.JPanel();
            text.setOpaque(false);
            text.setLayout(new javax.swing.BoxLayout(text, javax.swing.BoxLayout.Y_AXIS));
            text.add(title);
            text.add(javax.swing.Box.createVerticalStrut(4));
            text.add(typeBreed);
            text.add(javax.swing.Box.createVerticalStrut(4));
            text.add(submittedBy);

            javax.swing.JPanel actions = new javax.swing.JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 8, 2));
            actions.setOpaque(false);
            com.mycompany.pawcare.helpers.RoundedButton view = new com.mycompany.pawcare.helpers.RoundedButton();
            view.setText("VIEW INFO"); view.setBackground(Session.PURPLE); view.setForeground(java.awt.Color.WHITE);
            view.addActionListener(e -> new SubmissionInfoDialog(this, true, submission).setVisible(true));
            com.mycompany.pawcare.helpers.RoundedButton archive = new com.mycompany.pawcare.helpers.RoundedButton();
            archive.setText("ARCHIVE"); archive.setBackground(Session.NAVY); archive.setForeground(java.awt.Color.WHITE);
            archive.addActionListener(e -> { if (Ui.confirm(this, "Archive this submission?")) { m.archiveSubmission(submission); refresh(); } });
            actions.add(view); actions.add(archive);

            card.add(photo, java.awt.BorderLayout.NORTH);
            card.add(text, java.awt.BorderLayout.CENTER);
            card.add(actions, java.awt.BorderLayout.SOUTH);
            card.setPreferredSize(new java.awt.Dimension(430, 310));
            submissionCards.add(card);
            count++;
        }
        if (count == 0) {
            javax.swing.JLabel none = new javax.swing.JLabel("No active pet submissions.");
            none.setFont(new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 18));
            none.setForeground(Session.GRAY);
            none.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
            none.setVerticalAlignment(javax.swing.SwingConstants.CENTER);
            submissionCards.add(none);
        }
        submissionCards.revalidate();
        submissionCards.repaint();
    }

    private static boolean isSamplePhoto(Pet pet) {
        if (pet == null || pet.getImageResource() == null) return true;
        String path = pet.getImageResource().toLowerCase(java.util.Locale.ROOT);
        return path.endsWith("/buddy.jfif") || path.endsWith("/bantay.jfif") || path.endsWith("/lucky.jfif")
                || path.endsWith("/oreo.jfif") || path.endsWith("/ming.jfif") || path.endsWith("/ash.jfif")
                || path.endsWith("pet_submission_dog_placeholder.png") || path.endsWith("pet_submission_cat_placeholder.png");
    }

    private static String safe(String value) {
        return value == null || value.isBlank() ? "None" : value.trim();
    }

    public void refreshCards() { refresh(); }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainPanel = new javax.swing.JPanel();
        pnlSide = new javax.swing.JPanel();
        lblBrand = new javax.swing.JLabel();
        lblRole = new javax.swing.JLabel();
        btnSideHome = new com.mycompany.pawcare.helpers.RoundedButton();
        btnSidePets = new com.mycompany.pawcare.helpers.RoundedButton();
        btnSideAdoptions = new com.mycompany.pawcare.helpers.RoundedButton();
        btnSideUsers = new com.mycompany.pawcare.helpers.RoundedButton();
        btnSideSubs = new com.mycompany.pawcare.helpers.RoundedButton();
        btnSideArchived = new com.mycompany.pawcare.helpers.RoundedButton();
        btnSideLogout = new com.mycompany.pawcare.helpers.RoundedButton();
        pnlPage = new javax.swing.JPanel();
        lblHeader = new javax.swing.JLabel();
        lblSub = new javax.swing.JLabel();
        scrollTable = new javax.swing.JScrollPane();
        tblSubs = new com.mycompany.pawcare.helpers.StyledTable();
        pnlButtons = new javax.swing.JPanel();
        btnView = new com.mycompany.pawcare.helpers.RoundedButton();
        btnUpdate = new com.mycompany.pawcare.helpers.RoundedButton();
        btnApprove = new com.mycompany.pawcare.helpers.RoundedButton();
        btnDecline = new com.mycompany.pawcare.helpers.RoundedButton();
        btnArchive = new com.mycompany.pawcare.helpers.RoundedButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("PAWCARE - Pet Adoption Management System");

        mainPanel.setBackground(new java.awt.Color(255, 249, 241));
        mainPanel.setPreferredSize(new java.awt.Dimension(1240, 800));

        pnlSide.setBackground(new java.awt.Color(38, 48, 80));
        pnlSide.setPreferredSize(new java.awt.Dimension(235, 700));

        lblBrand.setFont(new java.awt.Font("SansSerif", 1, 28)); // NOI18N
        lblBrand.setForeground(new java.awt.Color(255, 255, 255));
        lblBrand.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblBrand.setText("PAWCARE");

        lblRole.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        lblRole.setForeground(new java.awt.Color(215, 215, 230));
        lblRole.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblRole.setText("ADMIN PANEL");

        btnSideHome.setBackground(new java.awt.Color(43, 126, 224));
        btnSideHome.setForeground(new java.awt.Color(255, 255, 255));
        btnSideHome.setText("HOME");
        btnSideHome.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnSideHome.addActionListener(this::btnSideHomeActionPerformed);

        btnSidePets.setBackground(new java.awt.Color(126, 79, 195));
        btnSidePets.setForeground(new java.awt.Color(255, 255, 255));
        btnSidePets.setText("PET MANAGEMENT");
        btnSidePets.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnSidePets.addActionListener(this::btnSidePetsActionPerformed);

        btnSideAdoptions.setBackground(new java.awt.Color(231, 65, 108));
        btnSideAdoptions.setForeground(new java.awt.Color(255, 255, 255));
        btnSideAdoptions.setText("ADOPTION RECORDS");
        btnSideAdoptions.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnSideAdoptions.addActionListener(this::btnSideAdoptionsActionPerformed);

        btnSideUsers.setBackground(new java.awt.Color(235, 154, 32));
        btnSideUsers.setForeground(new java.awt.Color(255, 255, 255));
        btnSideUsers.setText("MANAGE USERS");
        btnSideUsers.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnSideUsers.addActionListener(this::btnSideUsersActionPerformed);

        btnSideSubs.setBackground(new java.awt.Color(52, 171, 83));
        btnSideSubs.setForeground(new java.awt.Color(255, 255, 255));
        btnSideSubs.setText("PET SUBMISSIONS");
        btnSideSubs.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnSideSubs.addActionListener(this::btnSideSubsActionPerformed);

        btnSideArchived.setBackground(new java.awt.Color(235, 154, 32));
        btnSideArchived.setForeground(new java.awt.Color(255, 255, 255));
        btnSideArchived.setText("ARCHIVED");
        btnSideArchived.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnSideArchived.addActionListener(this::btnSideArchivedActionPerformed);

        btnSideLogout.setBackground(new java.awt.Color(214, 65, 55));
        btnSideLogout.setForeground(new java.awt.Color(255, 255, 255));
        btnSideLogout.setText("LOG OUT");
        btnSideLogout.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnSideLogout.addActionListener(this::btnSideLogoutActionPerformed);

        pnlPage.setBackground(new java.awt.Color(255, 249, 241));

        lblHeader.setFont(new java.awt.Font("SansSerif", 1, 30)); // NOI18N
        lblHeader.setForeground(new java.awt.Color(52, 171, 83));
        lblHeader.setText("Pet Submissions");

        lblSub.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        lblSub.setForeground(new java.awt.Color(38, 48, 80));
        lblSub.setText("Customer-submitted pets stay pending until admin approval.");

        tblSubs.setColumnTitles("Submission ID,User ID,User,Pet ID,Pet,Breed,Date,Status");

        pnlButtons.setOpaque(false);

        btnView.setBackground(new java.awt.Color(126, 79, 195));
        btnView.setForeground(new java.awt.Color(255, 255, 255));
        btnView.setText("VIEW INFO");
        btnView.addActionListener(this::btnViewActionPerformed);

        btnUpdate.setBackground(new java.awt.Color(235, 154, 32));
        btnUpdate.setForeground(new java.awt.Color(255, 255, 255));
        btnUpdate.setText("UPDATE");
        btnUpdate.addActionListener(this::btnUpdateActionPerformed);

        btnApprove.setBackground(new java.awt.Color(52, 171, 83));
        btnApprove.setForeground(new java.awt.Color(255, 255, 255));
        btnApprove.setText("APPROVE");
        btnApprove.addActionListener(this::btnApproveActionPerformed);

        btnDecline.setBackground(new java.awt.Color(214, 65, 55));
        btnDecline.setForeground(new java.awt.Color(255, 255, 255));
        btnDecline.setText("DECLINE");
        btnDecline.addActionListener(this::btnDeclineActionPerformed);

        btnArchive.setBackground(new java.awt.Color(38, 48, 80));
        btnArchive.setForeground(new java.awt.Color(255, 255, 255));
        btnArchive.setText("ARCHIVE");
        btnArchive.addActionListener(this::btnArchiveActionPerformed);

        javax.swing.GroupLayout pnlButtonsLayout = new javax.swing.GroupLayout(pnlButtons);
        pnlButtons.setLayout(pnlButtonsLayout);
        pnlButtonsLayout.setHorizontalGroup(
            pnlButtonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlButtonsLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(btnView, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(5, 5, 5)
                    .addComponent(btnUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(5, 5, 5)
                    .addComponent(btnApprove, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(5, 5, 5)
                    .addComponent(btnDecline, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(5, 5, 5)
                    .addComponent(btnArchive, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE))
        );
        pnlButtonsLayout.setVerticalGroup(
            pnlButtonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(btnView, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(btnUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(btnApprove, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(btnDecline, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(btnArchive, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        scrollTable.setViewportView(tblSubs);

        javax.swing.GroupLayout pnlPageLayout = new javax.swing.GroupLayout(pnlPage);
        pnlPage.setLayout(pnlPageLayout);
        pnlPageLayout.setHorizontalGroup(
            pnlPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlPageLayout.createSequentialGroup()
                    .addGap(28, 28, 28)
                    .addGroup(pnlPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(lblHeader, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblSub, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(scrollTable, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(pnlButtons, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGap(28, 28, 28))
        );
        pnlPageLayout.setVerticalGroup(
            pnlPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlPageLayout.createSequentialGroup()
                    .addGap(25, 25, 25)
                    .addComponent(lblHeader, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(4, 4, 4)
                    .addComponent(lblSub, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(12, 12, 12)
                    .addComponent(scrollTable, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGap(12, 12, 12)
                    .addComponent(pnlButtons, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(28, 28, 28))
        );

        javax.swing.GroupLayout pnlSideLayout = new javax.swing.GroupLayout(pnlSide);
        pnlSide.setLayout(pnlSideLayout);
        pnlSideLayout.setHorizontalGroup(
            pnlSideLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlSideLayout.createSequentialGroup()
                    .addGap(10, 10, 10)
                    .addGroup(pnlSideLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(lblBrand, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(pnlSideLayout.createSequentialGroup()
                            .addGap(0, 0, Short.MAX_VALUE)
                            .addComponent(lblRole, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(btnSideHome, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnSidePets, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnSideAdoptions, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnSideUsers, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnSideSubs, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnSideArchived, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnSideLogout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGap(10, 10, 10))
        );
        pnlSideLayout.setVerticalGroup(
            pnlSideLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlSideLayout.createSequentialGroup()
                    .addGap(18, 18, 18)
                    .addComponent(lblBrand, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblRole, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(25, 25, 25)
                    .addComponent(btnSideHome, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
                    .addGap(8, 8, 8)
                    .addComponent(btnSidePets, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
                    .addGap(8, 8, 8)
                    .addComponent(btnSideAdoptions, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
                    .addGap(8, 8, 8)
                    .addComponent(btnSideUsers, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
                    .addGap(8, 8, 8)
                    .addComponent(btnSideSubs, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
                    .addGap(8, 8, 8)
                    .addComponent(btnSideArchived, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
                    .addGap(8, 8, 8)
                    .addComponent(btnSideLogout, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
                    .addGap(18, 18, 18))
        );

        javax.swing.GroupLayout mainPanelLayout = new javax.swing.GroupLayout(mainPanel);
        mainPanel.setLayout(mainPanelLayout);
        mainPanelLayout.setHorizontalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(mainPanelLayout.createSequentialGroup()
                    .addComponent(pnlSide, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pnlPage, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        mainPanelLayout.setVerticalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(pnlSide, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(pnlPage, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSideHomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSideHomeActionPerformed
        Nav.show(this, new AdminDashboardForm());
    }//GEN-LAST:event_btnSideHomeActionPerformed

    private void btnSidePetsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSidePetsActionPerformed
        Nav.show(this, new PetManagementForm());
    }//GEN-LAST:event_btnSidePetsActionPerformed

    private void btnSideAdoptionsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSideAdoptionsActionPerformed
        Nav.show(this, new AdoptionRecordsForm());
    }//GEN-LAST:event_btnSideAdoptionsActionPerformed

    private void btnSideUsersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSideUsersActionPerformed
        Nav.show(this, new ManageUsersForm());
    }//GEN-LAST:event_btnSideUsersActionPerformed

    private void btnSideSubsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSideSubsActionPerformed
        Nav.show(this, new PetSubmissionsForm());
    }//GEN-LAST:event_btnSideSubsActionPerformed

    private void btnSideArchivedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSideArchivedActionPerformed
        Nav.show(this, new ArchivedPetsForm());
    }//GEN-LAST:event_btnSideArchivedActionPerformed

    private void btnSideLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSideLogoutActionPerformed
        Nav.home(this);
    }//GEN-LAST:event_btnSideLogoutActionPerformed

    private void btnViewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewActionPerformed
        PetSubmission s = selected();
        if (s != null) {
            new SubmissionInfoDialog(this, true, s).setVisible(true);
        }
    }//GEN-LAST:event_btnViewActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        PetSubmission s = selected();
        if (s != null) {
            Pet pet = Session.manager().findPet(s.getPetId());
            if (pet != null) {
                new PetEditDialog(this, true, pet).setVisible(true);
                Nav.show(this, new PetSubmissionsForm());
            }
        }
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnApproveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnApproveActionPerformed
        PetSubmission s = selected();
        if (s != null && s.getStatus().equals("Pending")) {
            Session.manager().approveSubmission(s);
            Nav.show(this, new PetSubmissionsForm());
        }
    }//GEN-LAST:event_btnApproveActionPerformed

    private void btnDeclineActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeclineActionPerformed
        PetSubmission s = selected();
        if (s != null && Ui.confirm(this, "Decline this pet submission? The pending pet will be removed from the gallery queue.")) {
            Session.manager().declineSubmission(s);
            Nav.show(this, new PetSubmissionsForm());
        }
    }//GEN-LAST:event_btnDeclineActionPerformed

    private void btnArchiveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnArchiveActionPerformed
        PetSubmission s = selected();
        if (s != null && Ui.confirm(this, "Archive this submission and preserve its record?")) {
            Session.manager().archiveSubmission(s);
            Nav.show(this, new PetSubmissionsForm());
        }
    }//GEN-LAST:event_btnArchiveActionPerformed
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.mycompany.pawcare.helpers.RoundedButton btnApprove;
    private com.mycompany.pawcare.helpers.RoundedButton btnArchive;
    private com.mycompany.pawcare.helpers.RoundedButton btnDecline;
    private com.mycompany.pawcare.helpers.RoundedButton btnSideAdoptions;
    private com.mycompany.pawcare.helpers.RoundedButton btnSideArchived;
    private com.mycompany.pawcare.helpers.RoundedButton btnSideHome;
    private com.mycompany.pawcare.helpers.RoundedButton btnSideLogout;
    private com.mycompany.pawcare.helpers.RoundedButton btnSidePets;
    private com.mycompany.pawcare.helpers.RoundedButton btnSideSubs;
    private com.mycompany.pawcare.helpers.RoundedButton btnSideUsers;
    private com.mycompany.pawcare.helpers.RoundedButton btnUpdate;
    private com.mycompany.pawcare.helpers.RoundedButton btnView;
    private javax.swing.JLabel lblBrand;
    private javax.swing.JLabel lblHeader;
    private javax.swing.JLabel lblRole;
    private javax.swing.JLabel lblSub;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JPanel pnlButtons;
    private javax.swing.JPanel pnlPage;
    private javax.swing.JPanel pnlSide;
    private javax.swing.JScrollPane scrollTable;
    private com.mycompany.pawcare.helpers.StyledTable tblSubs;
    // End of variables declaration//GEN-END:variables
}
