/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.pawcare.screens;

import com.mycompany.pawcare.popups.*;
import com.mycompany.pawcare.cards.*;
import com.mycompany.pawcare.helpers.*;

/**
 *
 * @author Student
 */
public class PutForAdoptionForm extends javax.swing.JFrame {
    private final com.mycompany.pawcare.helpers.MultiSelectCheckCombo vaccinationChoices = new com.mycompany.pawcare.helpers.MultiSelectCheckCombo(
            new String[] { "Anti-Rabies", "5-in-1 / DHPP", "Parvovirus", "Distemper", "Bordetella", "FVRCP", "Feline Leukemia", "Others", "Not vaccinated" });
    private final javax.swing.JTextField txtVaccOther = new javax.swing.JTextField();
    private final javax.swing.JTextField txtDisOther = new javax.swing.JTextField();
    private final com.mycompany.pawcare.helpers.MultiSelectCheckCombo disabilityChoices =
            new com.mycompany.pawcare.helpers.MultiSelectCheckCombo(
                    new String[] { "None", "Mobility issue", "Vision issue", "Hearing issue", "Other" });
    private final javax.swing.JComboBox<String> cmbSpayed = new javax.swing.JComboBox<>(new String[] { "Yes", "No", "Unknown" });
    private final javax.swing.JComboBox<String> cmbKids = new javax.swing.JComboBox<>(new String[] { "Yes", "No", "Unknown" });
    private final javax.swing.JTextArea txtMedicalHistory = new javax.swing.JTextArea(2, 20);
    private final com.mycompany.pawcare.helpers.PetPhoto previewPhoto = new com.mycompany.pawcare.helpers.PetPhoto();

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(PutForAdoptionForm.class.getName());

    public PutForAdoptionForm() {
        initComponents();
        // Put vaccination and disability choices directly on the customer submission form.
        // Keep these controls outside the generated layout definition so unrelated form layout stays intact.
        javax.swing.JPanel vaccinationPanel = new javax.swing.JPanel(new java.awt.BorderLayout(0, 5));
        vaccinationPanel.setOpaque(false);
        vaccinationChoices.setFont(new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 14));
        vaccinationChoices.setBackground(java.awt.Color.WHITE);
        txtVaccOther.setFont(new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 14));
        txtVaccOther.setToolTipText("Enter a vaccination not listed above");
        txtVaccOther.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtVaccOther.setVisible(false);
        vaccinationPanel.add(vaccinationChoices, java.awt.BorderLayout.NORTH);
        vaccinationPanel.add(txtVaccOther, java.awt.BorderLayout.CENTER);
        vaccinationChoices.setSelectionChanged(() -> txtVaccOther.setVisible(vaccinationChoices.getSelectedValues().contains("Others")));

        javax.swing.JPanel disabilityPanel = new javax.swing.JPanel(new java.awt.BorderLayout(0, 5));
        disabilityPanel.setOpaque(false);
        disabilityChoices.setFont(new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 14));
        disabilityChoices.setBackground(java.awt.Color.WHITE);
        txtDisOther.setFont(new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 14));
        txtDisOther.setToolTipText("Describe a disability not listed above");
        txtDisOther.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtDisOther.setVisible(false);
        disabilityPanel.add(disabilityChoices, java.awt.BorderLayout.NORTH);
        disabilityPanel.add(txtDisOther, java.awt.BorderLayout.CENTER);
        disabilityChoices.setSelectionChanged(() -> {
            txtDisOther.setVisible(disabilityChoices.getSelectedValues().contains("Other"));
            disabilityPanel.revalidate();
            disabilityPanel.repaint();
        });

        // Replace only the two original single-choice widgets with the new inline controls.
        int vaccinationIndex = pnlForm.getComponentZOrder(cmbVacc);
        pnlForm.remove(cmbVacc);
        pnlForm.add(vaccinationPanel, vaccinationIndex);
        int disabilityIndex = pnlForm.getComponentZOrder(cmbDis);
        pnlForm.remove(cmbDis);
        pnlForm.add(disabilityPanel, disabilityIndex);
        disabilityChoices.setSelectedValues(java.util.List.of("None"));
        pnlForm.revalidate();
        pnlForm.repaint();
        lblSub.setText("Complete the pet details below. PawCare assigns a sample picture; your submission stays Pending until admin review.");
        // Customer submissions do not require or expose photo upload controls.
        txtImage.setText("");
        getContentPane().setBackground(new java.awt.Color(255, 249, 241));
        setSize(1240, 800);
        setMinimumSize(new java.awt.Dimension(1050, 700));
        setLocationRelativeTo(null);
        // Personality and Special Care are JTextArea controls; validate all fields on submit.
        txtImage.setVisible(false); lblImage.setVisible(false);
        previewPhoto.setBoxWidth(130); previewPhoto.setBoxHeight(85); previewPhoto.setImagePath("");
        previewPhoto.setToolTipText("Photo is optional. Admin can review the pet details without an uploaded image.");
        pnlButtons.setOpaque(false);
        pnlButtons.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 10, 6)); pnlButtons.removeAll();
        btnSubmit.setVisible(true); btnClear.setVisible(true);
        btnSubmit.setOpaque(true); btnClear.setOpaque(true);
        btnSubmit.setBackground(Session.GREEN); btnSubmit.setForeground(java.awt.Color.WHITE);
        btnClear.setBackground(Session.PURPLE); btnClear.setForeground(java.awt.Color.WHITE);
        pnlButtons.add(btnSubmit); pnlButtons.add(btnClear);
        scrollForm.getVerticalScrollBar().setUnitIncrement(16);
    }

    private void doSubmit() {
        String err = Ui.validatePet(txtName.getText(), (String) cmbType.getSelectedItem(), txtBreed.getText(), txtAge.getText(),
                (String) cmbGender.getSelectedItem(), txtHealth.getText(), txtPersonality.getText(), txtCare.getText());
        if (err != null) {
            Ui.msg(this, err, "Pet Submission", javax.swing.JOptionPane.WARNING_MESSAGE);
            return;
        }
        java.util.List<String> vaccines = vaccinationChoices.getSelectedValues();
        if (vaccines.isEmpty()) { Ui.msg(this, "Select one or more vaccinations, or choose Not vaccinated.", "Pet Submission", javax.swing.JOptionPane.WARNING_MESSAGE); return; }
        if (vaccines.contains("Others") && txtVaccOther.getText().trim().isEmpty()) { Ui.msg(this, "Enter the vaccination name for Others.", "Pet Submission", javax.swing.JOptionPane.WARNING_MESSAGE); return; }
        String vaccination = String.join(", ", vaccines.stream().filter(v -> !"Others".equals(v)).toList());
        if (vaccines.contains("Others")) vaccination = (vaccination.isBlank() ? "" : vaccination + ", ") + "Others: " + txtVaccOther.getText().trim();
        java.util.List<String> disabilities = disabilityChoices.getSelectedValues();
        if (disabilities.isEmpty()) { Ui.msg(this, "Select None or one or more disability options.", "Pet Submission", javax.swing.JOptionPane.WARNING_MESSAGE); return; }
        if (disabilities.size() > 1 && disabilities.contains("None")) {
            Ui.msg(this, "Choose None by itself, or select the applicable disability options.", "Pet Submission", javax.swing.JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (disabilities.contains("Other") && txtDisOther.getText().trim().isEmpty()) {
            Ui.msg(this, "Describe the disability selected as Other.", "Pet Submission", javax.swing.JOptionPane.WARNING_MESSAGE);
            return;
        }
        String disability = String.join(", ", disabilities.stream().filter(v -> !"Other".equals(v)).toList());
        if (disabilities.contains("Other")) disability = (disability.isBlank() ? "" : disability + ", ") + "Other: " + txtDisOther.getText().trim();
        Session.manager().submitPet(Session.currentUser, txtName.getText().trim(), (String) cmbType.getSelectedItem(), txtBreed.getText().trim(),
                txtAge.getText().trim(), (String) cmbGender.getSelectedItem(), txtHealth.getText().trim(), vaccination,
                (String) cmbDew.getSelectedItem(), disability, txtPersonality.getText().trim(), txtCare.getText().trim(), "",
                String.valueOf(cmbSpayed.getSelectedItem()), String.valueOf(cmbKids.getSelectedItem()), txtMedicalHistory.getText().trim());
        Ui.msg(this, "Submitted successfully.\nYour pet is now Pending and will appear in the gallery only if the admin approves it.", "Submission Sent", javax.swing.JOptionPane.INFORMATION_MESSAGE);
        Nav.show(this, new PutForAdoptionForm());
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainPanel = new javax.swing.JPanel();
        pnlSide = new javax.swing.JPanel();
        lblBrand = new javax.swing.JLabel();
        lblRole = new javax.swing.JLabel();
        btnSideHome = new com.mycompany.pawcare.helpers.RoundedButton();
        btnSideGallery = new com.mycompany.pawcare.helpers.RoundedButton();
        btnSideAdoptions = new com.mycompany.pawcare.helpers.RoundedButton();
        btnSidePut = new com.mycompany.pawcare.helpers.RoundedButton();
        btnSideProfile = new com.mycompany.pawcare.helpers.RoundedButton();
        btnSideLogout = new com.mycompany.pawcare.helpers.RoundedButton();
        pnlPage = new javax.swing.JPanel();
        lblHeader = new javax.swing.JLabel();
        lblSub = new javax.swing.JLabel();
        scrollForm = new javax.swing.JScrollPane();
        pnlForm = new javax.swing.JPanel();
        lblName = new javax.swing.JLabel();
        txtName = new javax.swing.JTextField();
        lblType = new javax.swing.JLabel();
        cmbType = new javax.swing.JComboBox<>();
        lblBreed = new javax.swing.JLabel();
        txtBreed = new javax.swing.JTextField();
        lblAge = new javax.swing.JLabel();
        txtAge = new javax.swing.JTextField();
        lblGender = new javax.swing.JLabel();
        cmbGender = new javax.swing.JComboBox<>();
        lblHealth = new javax.swing.JLabel();
        txtHealth = new javax.swing.JTextField();
        lblVacc = new javax.swing.JLabel();
        cmbVacc = new javax.swing.JComboBox<>();
        lblDew = new javax.swing.JLabel();
        cmbDew = new javax.swing.JComboBox<>();
        lblDis = new javax.swing.JLabel();
        cmbDis = new javax.swing.JComboBox<>();
        lblPersonality = new javax.swing.JLabel();
        txtPersonality = new javax.swing.JTextArea(3, 20);
        lblCare = new javax.swing.JLabel();
        txtCare = new javax.swing.JTextArea(3, 20);
        lblImage = new javax.swing.JLabel();
        txtImage = new javax.swing.JTextField();
        pnlButtons = new javax.swing.JPanel();
        btnSubmit = new com.mycompany.pawcare.helpers.RoundedButton();
        btnClear = new com.mycompany.pawcare.helpers.RoundedButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("PAWCARE - Pet Adoption Management System");

        mainPanel.setBackground(new java.awt.Color(255, 249, 241));
        mainPanel.setPreferredSize(new java.awt.Dimension(1240, 800));

        pnlSide.setBackground(new java.awt.Color(38, 48, 80));
        pnlSide.setPreferredSize(new java.awt.Dimension(225, 700));

        lblBrand.setFont(new java.awt.Font("SansSerif", 1, 27)); // NOI18N
        lblBrand.setForeground(new java.awt.Color(255, 255, 255));
        lblBrand.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblBrand.setText("PAWCARE");

        lblRole.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        lblRole.setForeground(new java.awt.Color(215, 215, 230));
        lblRole.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblRole.setText("CUSTOMER");

        btnSideHome.setBackground(new java.awt.Color(43, 126, 224));
        btnSideHome.setForeground(new java.awt.Color(255, 255, 255));
        btnSideHome.setText("HOME");
        btnSideHome.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnSideHome.addActionListener(this::btnSideHomeActionPerformed);

        btnSideGallery.setBackground(new java.awt.Color(126, 79, 195));
        btnSideGallery.setForeground(new java.awt.Color(255, 255, 255));
        btnSideGallery.setText("PAW CARE GALLERY");
        btnSideGallery.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnSideGallery.addActionListener(this::btnSideGalleryActionPerformed);

        btnSideAdoptions.setBackground(new java.awt.Color(231, 65, 108));
        btnSideAdoptions.setForeground(new java.awt.Color(255, 255, 255));
        btnSideAdoptions.setText("MY ADOPTIONS");
        btnSideAdoptions.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnSideAdoptions.addActionListener(this::btnSideAdoptionsActionPerformed);

        btnSidePut.setBackground(new java.awt.Color(52, 171, 83));
        btnSidePut.setForeground(new java.awt.Color(255, 255, 255));
        btnSidePut.setText("PUT FOR ADOPTION");
        btnSidePut.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnSidePut.addActionListener(this::btnSidePutActionPerformed);

        btnSideProfile.setBackground(new java.awt.Color(235, 154, 32));
        btnSideProfile.setForeground(new java.awt.Color(255, 255, 255));
        btnSideProfile.setText("MY PROFILE");
        btnSideProfile.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnSideProfile.addActionListener(this::btnSideProfileActionPerformed);

        btnSideLogout.setBackground(new java.awt.Color(214, 65, 55));
        btnSideLogout.setForeground(new java.awt.Color(255, 255, 255));
        btnSideLogout.setText("LOG OUT");
        btnSideLogout.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnSideLogout.addActionListener(this::btnSideLogoutActionPerformed);

        pnlPage.setBackground(new java.awt.Color(255, 249, 241));

        lblHeader.setFont(new java.awt.Font("SansSerif", 1, 30)); // NOI18N
        lblHeader.setForeground(new java.awt.Color(52, 171, 83));
        lblHeader.setText("Put For Adoption");

        lblSub.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        lblSub.setForeground(new java.awt.Color(38, 48, 80));
        lblSub.setText("Submit your pet for admin review. It will not appear publicly until approved.");

        pnlForm.setBackground(new java.awt.Color(255, 249, 241));
        pnlForm.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));

        lblName.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblName.setForeground(new java.awt.Color(38, 48, 80));
        lblName.setText("Pet Name");

        txtName.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtName.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));

        lblType.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblType.setForeground(new java.awt.Color(38, 48, 80));
        lblType.setText("Type");

        cmbType.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        cmbType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Dog", "Cat" }));

        lblBreed.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblBreed.setForeground(new java.awt.Color(38, 48, 80));
        lblBreed.setText("Breed");

        txtBreed.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtBreed.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));

        lblAge.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblAge.setForeground(new java.awt.Color(38, 48, 80));
        lblAge.setText("Age");

        txtAge.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtAge.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));

        lblGender.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblGender.setForeground(new java.awt.Color(38, 48, 80));
        lblGender.setText("Gender");

        cmbGender.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        cmbGender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female" }));

        lblHealth.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblHealth.setForeground(new java.awt.Color(38, 48, 80));
        lblHealth.setText("Health");

        txtHealth.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtHealth.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));

        lblVacc.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblVacc.setForeground(new java.awt.Color(38, 48, 80));
        lblVacc.setText("Vaccination");

        cmbVacc.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        cmbVacc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Up to date", "Not vaccinated", "To be assessed" }));

        lblDew.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblDew.setForeground(new java.awt.Color(38, 48, 80));
        lblDew.setText("Dewormed");

        cmbDew.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        cmbDew.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Yes", "No", "Due", "To be assessed" }));

        lblDis.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblDis.setForeground(new java.awt.Color(38, 48, 80));
        lblDis.setText("Disability");

        cmbDis.setFont(new java.awt.Font("Dialog", 1, 15)); // NOI18N
        cmbDis.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "None", "Mobility issue", "Vision issue", "Hearing issue", "Other" }));

        lblPersonality.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblPersonality.setForeground(new java.awt.Color(38, 48, 80));
        lblPersonality.setText("Personality");

        txtPersonality.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtPersonality.setLineWrap(true);
        txtPersonality.setWrapStyleWord(true);
        txtPersonality.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));

        lblCare.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblCare.setForeground(new java.awt.Color(38, 48, 80));
        lblCare.setText("Special Care");

        txtCare.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtCare.setLineWrap(true);
        txtCare.setWrapStyleWord(true);
        txtCare.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));

        lblImage.setFont(new java.awt.Font("SansSerif", 1, 15)); // NOI18N
        lblImage.setForeground(new java.awt.Color(38, 48, 80));
        lblImage.setText("Image Resource");

        txtImage.setFont(new java.awt.Font("SansSerif", 0, 15)); // NOI18N
        txtImage.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 205, 215), 1, true), javax.swing.BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        txtImage.setText("/com/mycompany/pawcare/images/buddy.jfif");

        pnlButtons.setOpaque(false);

        btnSubmit.setBackground(new java.awt.Color(52, 171, 83));
        btnSubmit.setForeground(new java.awt.Color(255, 255, 255));
        btnSubmit.setText("SUBMIT FOR REVIEW");
        btnSubmit.addActionListener(this::btnSubmitActionPerformed);

        btnClear.setBackground(new java.awt.Color(38, 48, 80));
        btnClear.setForeground(new java.awt.Color(255, 255, 255));
        btnClear.setText("CLEAR");
        btnClear.addActionListener(this::btnClearActionPerformed);

        javax.swing.GroupLayout pnlButtonsLayout = new javax.swing.GroupLayout(pnlButtons);
        pnlButtons.setLayout(pnlButtonsLayout);
        pnlButtonsLayout.setHorizontalGroup(
            pnlButtonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlButtonsLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(btnSubmit, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(10, 10, 10)
                    .addComponent(btnClear, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE))
        );
        pnlButtonsLayout.setVerticalGroup(
            pnlButtonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(btnSubmit, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(btnClear, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pnlForm.setLayout(new java.awt.GridLayout(0, 2, 12, 12));
        pnlForm.add(lblName);
        pnlForm.add(txtName);
        pnlForm.add(lblType);
        pnlForm.add(cmbType);
        pnlForm.add(lblBreed);
        pnlForm.add(txtBreed);
        pnlForm.add(lblAge);
        pnlForm.add(txtAge);
        pnlForm.add(lblGender);
        pnlForm.add(cmbGender);
        pnlForm.add(lblHealth);
        pnlForm.add(txtHealth);
        pnlForm.add(lblVacc);
        pnlForm.add(cmbVacc);
        pnlForm.add(lblDew);
        pnlForm.add(cmbDew);
        pnlForm.add(lblDis);
        pnlForm.add(cmbDis);
        pnlForm.add(lblPersonality);
        javax.swing.JScrollPane personalityScroll = new javax.swing.JScrollPane(txtPersonality);
        personalityScroll.setPreferredSize(new java.awt.Dimension(240, 72));
        pnlForm.add(personalityScroll);
        pnlForm.add(lblCare);
        javax.swing.JScrollPane careScroll = new javax.swing.JScrollPane(txtCare);
        careScroll.setPreferredSize(new java.awt.Dimension(240, 72));
        pnlForm.add(careScroll);
        pnlForm.add(lblImage);
        pnlForm.add(txtImage);

        scrollForm.setViewportView(pnlForm);

        javax.swing.GroupLayout pnlPageLayout = new javax.swing.GroupLayout(pnlPage);
        pnlPage.setLayout(pnlPageLayout);
        pnlPageLayout.setHorizontalGroup(
            pnlPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlPageLayout.createSequentialGroup()
                    .addGap(28, 28, 28)
                    .addGroup(pnlPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(lblHeader, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblSub, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(scrollForm, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(pnlButtons, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGap(28, 28, 28))
        );
        pnlPageLayout.setVerticalGroup(
            pnlPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlPageLayout.createSequentialGroup()
                    .addGap(25, 25, 25)
                    .addComponent(lblHeader, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(4, 4, 4)
                    .addComponent(lblSub, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(12, 12, 12)
                    .addComponent(scrollForm, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGap(12, 12, 12)
                    .addComponent(pnlButtons, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(28, 28, 28))
        );

        javax.swing.GroupLayout pnlSideLayout = new javax.swing.GroupLayout(pnlSide);
        pnlSide.setLayout(pnlSideLayout);
        pnlSideLayout.setHorizontalGroup(
            pnlSideLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlSideLayout.createSequentialGroup()
                    .addGap(10, 10, 10)
                    .addGroup(pnlSideLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(lblBrand, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(pnlSideLayout.createSequentialGroup()
                            .addGap(0, 0, Short.MAX_VALUE)
                            .addComponent(lblRole, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(btnSideHome, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnSideGallery, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnSideAdoptions, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnSidePut, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnSideProfile, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnSideLogout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGap(10, 10, 10))
        );
        pnlSideLayout.setVerticalGroup(
            pnlSideLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlSideLayout.createSequentialGroup()
                    .addGap(18, 18, 18)
                    .addComponent(lblBrand, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblRole, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(25, 25, 25)
                    .addComponent(btnSideHome, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
                    .addGap(8, 8, 8)
                    .addComponent(btnSideGallery, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
                    .addGap(8, 8, 8)
                    .addComponent(btnSideAdoptions, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
                    .addGap(8, 8, 8)
                    .addComponent(btnSidePut, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
                    .addGap(8, 8, 8)
                    .addComponent(btnSideProfile, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
                    .addGap(8, 8, 8)
                    .addComponent(btnSideLogout, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
                    .addGap(18, 18, 18))
        );

        javax.swing.GroupLayout mainPanelLayout = new javax.swing.GroupLayout(mainPanel);
        mainPanel.setLayout(mainPanelLayout);
        mainPanelLayout.setHorizontalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(mainPanelLayout.createSequentialGroup()
                    .addComponent(pnlSide, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pnlPage, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        mainPanelLayout.setVerticalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(pnlSide, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(pnlPage, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSideHomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSideHomeActionPerformed
        Nav.show(this, new CustomerDashboardForm());
    }//GEN-LAST:event_btnSideHomeActionPerformed

    private void btnSideGalleryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSideGalleryActionPerformed
        Nav.show(this, new CustomerGalleryForm());
    }//GEN-LAST:event_btnSideGalleryActionPerformed

    private void btnSideAdoptionsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSideAdoptionsActionPerformed
        Nav.show(this, new MyAdoptionsForm());
    }//GEN-LAST:event_btnSideAdoptionsActionPerformed

    private void btnSidePutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSidePutActionPerformed
        Nav.show(this, new PutForAdoptionForm());
    }//GEN-LAST:event_btnSidePutActionPerformed

    private void btnSideProfileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSideProfileActionPerformed
        Nav.show(this, new ProfileForm());
    }//GEN-LAST:event_btnSideProfileActionPerformed

    private void btnSideLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSideLogoutActionPerformed
        Session.logout();
        Nav.home(this);
    }//GEN-LAST:event_btnSideLogoutActionPerformed

    private void btnSubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSubmitActionPerformed
        doSubmit();
    }//GEN-LAST:event_btnSubmitActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
        txtImage.setText(""); previewPhoto.setImagePath("");
        txtName.setText("");
        txtBreed.setText("");
        txtAge.setText("");
        txtHealth.setText("");
        vaccinationChoices.setSelectedValues(java.util.List.of());
        txtVaccOther.setText(""); txtVaccOther.setVisible(false);
        disabilityChoices.setSelectedValues(java.util.List.of("None")); txtDisOther.setText(""); txtDisOther.setVisible(false);
        txtPersonality.setText("");
        txtCare.setText("");
    }//GEN-LAST:event_btnClearActionPerformed
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.mycompany.pawcare.helpers.RoundedButton btnClear;
    private com.mycompany.pawcare.helpers.RoundedButton btnSideAdoptions;
    private com.mycompany.pawcare.helpers.RoundedButton btnSideGallery;
    private com.mycompany.pawcare.helpers.RoundedButton btnSideHome;
    private com.mycompany.pawcare.helpers.RoundedButton btnSideLogout;
    private com.mycompany.pawcare.helpers.RoundedButton btnSideProfile;
    private com.mycompany.pawcare.helpers.RoundedButton btnSidePut;
    private com.mycompany.pawcare.helpers.RoundedButton btnSubmit;
    private javax.swing.JComboBox<String> cmbDew;
    private javax.swing.JComboBox<String> cmbDis;
    private javax.swing.JComboBox<String> cmbGender;
    private javax.swing.JComboBox<String> cmbType;
    private javax.swing.JComboBox<String> cmbVacc;
    private javax.swing.JLabel lblAge;
    private javax.swing.JLabel lblBrand;
    private javax.swing.JLabel lblBreed;
    private javax.swing.JLabel lblCare;
    private javax.swing.JLabel lblDew;
    private javax.swing.JLabel lblDis;
    private javax.swing.JLabel lblGender;
    private javax.swing.JLabel lblHeader;
    private javax.swing.JLabel lblHealth;
    private javax.swing.JLabel lblImage;
    private javax.swing.JLabel lblName;
    private javax.swing.JLabel lblPersonality;
    private javax.swing.JLabel lblRole;
    private javax.swing.JLabel lblSub;
    private javax.swing.JLabel lblType;
    private javax.swing.JLabel lblVacc;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JPanel pnlButtons;
    private javax.swing.JPanel pnlForm;
    private javax.swing.JPanel pnlPage;
    private javax.swing.JPanel pnlSide;
    private javax.swing.JScrollPane scrollForm;
    private javax.swing.JTextField txtAge;
    private javax.swing.JTextField txtBreed;
    private javax.swing.JTextArea txtCare;
    private javax.swing.JTextField txtHealth;
    private javax.swing.JTextField txtImage;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextArea txtPersonality;
    // End of variables declaration//GEN-END:variables
}
